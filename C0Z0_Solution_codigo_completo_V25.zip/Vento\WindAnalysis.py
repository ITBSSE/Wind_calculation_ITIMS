r"""
WindAnalysis.py  --  parte de VENTO (separada do RugosidadeZ0.py)
================================================================

Le, de uma pasta  resultados/<ID>/  ja produzida pelo modulo Rugosidade:
    wk_by_main_sector.json   -> z0 / d por setor
    site_info.json           -> lat, lon, pais, altura_torre, n_sectors, raio

e produz:
    resultado_final.json     -> z0/d por setor + vento{vb,zona}  (+ cdir se Franca)
    imagens/Wind_Map.jpg     -> mapa da zona de vento do pais
    (so Franca) graficos  cdir / vb*cdir / qp

NAO toca em rasters. Corre em segundos sobre uma pasta ja feita.

USO:
    python WindAnalysis.py <ID>
        -> le  resultados/<ID>/site_info.json  +  wk_by_main_sector.json
    python WindAnalysis.py "ID,PAIS,LAT,LON,ALTURA,N_SECTORS,REGIAO"
        -> usa estes valores (fallback quando nao ha site_info.json)

Flags:
    --outdir PATH   base dos resultados (default: ./resultados)
"""

import os
import sys
import json
import math
import time
from datetime import datetime, timedelta

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import geopandas as gpd
import contextily as ctx


def _adicionar_mapa_base(ax, alpha=0.6, attribution=False, **kwargs):
    """Mapa de fundo -- SEMPRE a mesma fonte em todos os mapas da solucao
    (Esri.WorldGrayCanvas: a unica que nao pede API key nem bloqueia).
    Se a rede da maquina falhar (proxy da hosting, DNS filtrado, etc.),
    desiste em silencio -- o mapa sai sem fundo, mas o calculo
    (z0/co/pressao) nao e afetado."""
    try:
        ctx.add_basemap(ax, source=ctx.providers.Esri.WorldGrayCanvas,
                        alpha=alpha, attribution=attribution, **kwargs)
        return True
    except Exception as e:
        print(f"    [AVISO] mapa sem fundo (contextily): {e}")
        return False

import shapely.geometry as geom
from shapely.geometry import Point
from pyproj import Transformer

# permitir  'from GetWindValues import ...'  e  'from Velocidade_Media import ...'
# (o GetWindValues.py esta aqui;  Velocidade_Media/Iv_Calc estao em Wind/)
# Congelado (.exe onefile): os .geojson e o pacote Wind sao extraidos para
# sys._MEIPASS -- e la que os procuramos.
if getattr(sys, "frozen", False):
    _AQUI = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(sys.executable)))
else:
    _AQUI = os.path.dirname(os.path.abspath(__file__))
for _p in (_AQUI, os.path.join(_AQUI, "Wind")):
    if _p not in sys.path:
        sys.path.insert(0, _p)


# ==========================================================================
# FUNCOES DE VENTO  --  movidas tal-qual do LTBDataCollectorPixel6.py
#   gerar_grafico_cdir / gerar_grafico_vb_cdir / gerar_grafico_qp
#   obter_cdir_franca / gerar_resultado_final_json / gerar_mapa_ventos_jpeg
# ==========================================================================

def gerar_grafico_cdir(cdir_por_setor, pasta_saida, n_sectors, cdir_info=None, nome_arquivo=None):
    """
    Gera um gráfico circular mostrando as zonas de cdir em formato de pizza.
    Círculo uniforme com cores diferentes para indicar as zonas.
    
    Args:
        cdir_por_setor: Dicionário com valores de cdir para cada setor
        pasta_saida: Pasta onde salvar o gráfico
        n_sectors: Número de setores
        cdir_info: Dicionário com informações da região (ang_i, ang_f, cdir, etc)
        nome_arquivo: Nome customizado para o arquivo (opcional, padrão: 'cdir_continuo')
    """
    import matplotlib.pyplot as plt
    import numpy as np
    
    # Se cdir_info foi fornecido, usar diretamente
    if cdir_info:
        cdir_value = cdir_info['cdir']
        ang_i = cdir_info['ang_i']
        ang_f = cdir_info['ang_f']
        regiao = cdir_info.get('region', 'França')
    else:
        # Extrair informações dos setores
        cdir_value = None
        ang_i = None
        ang_f = None
        regiao = 'França'
        
        for setor_id in range(1, n_sectors + 1):
            val = cdir_por_setor.get(f'setor_{setor_id}', 0.0)
            if val > 0:
                cdir_value = val
                angle_per_sector = 360 / n_sectors
                setor_angulo = (setor_id - 1) * angle_per_sector + (angle_per_sector / 2)
                
                if ang_i is None:
                    ang_i = setor_angulo
                ang_f = setor_angulo
        
        if cdir_value is None or ang_i is None or ang_f is None:
            print("⚠ Nenhum valor de cdir encontrado nos setores")
            return None
        
        angle_per_sector = 360 / n_sectors
        ang_i = ang_i - angle_per_sector / 2
        ang_f = ang_f + angle_per_sector / 2
    
    # Criar ângulos de alta resolução para suavidade
    angles_deg = np.linspace(0, 360, 721, endpoint=True)
    angles_rad = np.deg2rad(angles_deg)
    
    # Calcular boundaries dos 8 pedaços visuais (fatias de pizza)
    num_visual_sectors = 8
    angle_per_visual_sector = 360 / num_visual_sectors  # 45°
    visual_sector_centers = np.arange(0, 360, angle_per_visual_sector)
    half_visual = angle_per_visual_sector / 2  # 22.5°
    visual_boundaries = visual_sector_centers + half_visual  # 22.5°, 67.5°, 112.5°, etc.
    
    # Função para calcular porcentagem de sobreposição entre o pedaço visual e a zona cdir
    def calcular_porcentagem_em_zona_cdir(boundary_start, boundary_end, ang_i, ang_f):
        """
        Calcula a porcentagem do pedaço visual que está dentro da zona cdir.
        Retorna um valor entre 0.0 e 1.0
        """
        # Normalizar ângulos para 0-360
        boundary_start = boundary_start % 360
        boundary_end = boundary_end % 360
        
        # Calcular amplitude do pedaço visual
        if boundary_end >= boundary_start:
            amplitude_pedaco = boundary_end - boundary_start
        else:
            # Pedaço cruza 0°
            amplitude_pedaco = (360 - boundary_start) + boundary_end
        
        # Calcular interseção com a zona cdir
        if ang_i <= ang_f:
            # Range cdir normal (não cruza 0°)
            if boundary_end >= boundary_start:
                # Pedaço normal
                intersecao_start = max(boundary_start, ang_i)
                intersecao_end = min(boundary_end, ang_f)
                if intersecao_start < intersecao_end:
                    amplitude_intersecao = intersecao_end - intersecao_start
                else:
                    amplitude_intersecao = 0
            else:
                # Pedaço cruza 0°, range cdir não cruza
                # Dividir em duas partes: [boundary_start, 360] e [0, boundary_end]
                parte1 = max(0, min(360, ang_f) - max(boundary_start, ang_i)) if ang_f >= boundary_start and ang_i < 360 else 0
                parte2 = max(0, min(boundary_end, ang_f) - max(0, ang_i)) if ang_f >= 0 and ang_i <= boundary_end else 0
                amplitude_intersecao = max(0, parte1) + max(0, parte2)
        else:
            # Range cdir cruza 0° (ang_i > ang_f)
            if boundary_end >= boundary_start:
                # Pedaço normal, range cdir cruza
                # Dividir: [ang_i, 360] e [0, ang_f]
                parte1 = max(0, min(boundary_end, 360) - max(boundary_start, ang_i)) if boundary_end >= ang_i else 0
                parte2 = max(0, min(boundary_end, ang_f) - boundary_start) if boundary_start <= ang_f else 0
                amplitude_intersecao = max(0, parte1) + max(0, parte2)
            else:
                # Ambos cruzam 0° - toda sobreposição é válida
                # Pedaço: [boundary_start, 360] + [0, boundary_end]
                # Zona: [ang_i, 360] + [0, ang_f]
                parte1 = min(360, max(boundary_start, ang_i)) - max(boundary_start, ang_i) if boundary_start <= 360 else 0
                parte2 = min(boundary_end, ang_f) if boundary_end <= ang_f else boundary_end if ang_f >= boundary_end else ang_f
                amplitude_intersecao = (360 - max(boundary_start, ang_i)) + min(boundary_end, ang_f)
        
        # Calcular porcentagem
        if amplitude_pedaco > 0:
            return amplitude_intersecao / amplitude_pedaco
        return 0.0
    
    # Criar array de cores baseado nos pedaços visuais
    colors = []
    for angle in angles_deg:
        # Determinar em qual pedaço visual este ângulo está
        # Encontrar o boundary anterior e posterior
        angle_norm = angle % 360
        
        # Encontrar qual pedaço (entre dois boundaries consecutivos)
        pedaco_index = None
        for i in range(len(visual_boundaries)):
            boundary_start = visual_boundaries[i]
            boundary_end = visual_boundaries[(i + 1) % len(visual_boundaries)]
            
            # Verificar se angle está neste pedaço
            if boundary_start < boundary_end:
                if boundary_start <= angle_norm < boundary_end:
                    pedaco_index = i
                    break
            else:
                # Pedaço cruza 0°
                if angle_norm >= boundary_start or angle_norm < boundary_end:
                    pedaco_index = i
                    break
        
        if pedaco_index is not None:
            boundary_start = visual_boundaries[pedaco_index]
            boundary_end = visual_boundaries[(pedaco_index + 1) % len(visual_boundaries)]
            
            # Calcular porcentagem do pedaço que está na zona cdir
            porcentagem_cdir = calcular_porcentagem_em_zona_cdir(boundary_start, boundary_end, ang_i, ang_f)
            
            # Se 80% ou mais está na zona cdir, colorir de azul, senão verde
            if porcentagem_cdir >= 0.8:
                colors.append('#2196F3')  # Azul - 80%+ na zona cdir
            else:
                colors.append('#66BB6A')  # Verde - menos de 80% na zona cdir
        else:
            # Fallback (não deveria acontecer)
            colors.append('#66BB6A')
    
    # Criar figura com fundo consistente
    fig = plt.figure(figsize=(12, 12), facecolor='white')
    ax = plt.subplot(111, projection='polar', facecolor='#f5f5f5')
    
    # Configurar para que 0° fique no norte (topo) - IGUAL AOS OUTROS GRÁFICOS
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    
    # Plotar círculo colorido por segmentos
    for i in range(len(angles_rad) - 1):
        theta = [angles_rad[i], angles_rad[i+1]]
        r = [1.0, 1.0]
        ax.fill_between(theta, 0, r, color=colors[i], alpha=0.8)
    
    # Adicionar linha de contorno
    circle_line = np.full_like(angles_rad, 1.0)
    ax.plot(angles_rad, circle_line, color='#1565C0', linewidth=3, zorder=10)
    
    # Configurar escala radial (oculta)
    ax.set_ylim(0, 1.0)
    ax.set_yticks([])  # Remover marcadores radiais
    
    # Configurar labels angulares - 8 DIVISÕES (a cada 45°)
    # Seguindo o padrão dos outros gráficos: pedaços centralizados, não começando do 0°
    # (visual_sector_centers e visual_boundaries já foram calculados acima)
    
    ax.set_xticks(np.deg2rad(visual_sector_centers))
    ax.set_xticklabels([f'{int(a)}°' for a in visual_sector_centers], 
                       fontsize=12, fontweight='bold', color='#333333')
    
    # Desabilitar grade radial automática (remover linhas em 0°, 45°, etc.)
    ax.grid(False)
    
    # Título
    ax.set_title(f'Directional Coefficient (cdir) - {regiao}\n',
                 fontsize=18, fontweight='bold', pad=25, color='#1a1a1a')
    
    # Adicionar linhas de separação das 8 fatias de pizza (nos boundaries)
    for boundary_angle in visual_boundaries:
        boundary_rad = np.deg2rad(boundary_angle)
        ax.plot([boundary_rad, boundary_rad], [0, 1.0], 'white', 
                linewidth=2.5, alpha=0.7, zorder=5)
    
    # Adicionar marcadores nos ângulos limites
    ang_i_rad = np.deg2rad(ang_i)
    ang_f_rad = np.deg2rad(ang_f)
    
    # Linhas vermelhas marcando início e fim
    ax.plot([ang_i_rad, ang_i_rad], [0, 1.0], 'r-', linewidth=3.5, alpha=0.9, zorder=15)
    ax.plot([ang_f_rad, ang_f_rad], [0, 1.0], 'r-', linewidth=3.5, alpha=0.9, zorder=15)
    
    # Adicionar pontos nos limites
    ax.plot(ang_i_rad, 1.0, 'ro', markersize=12, markeredgecolor='darkred', 
           markeredgewidth=2, zorder=20)
    ax.plot(ang_f_rad, 1.0, 'ro', markersize=12, markeredgecolor='darkred', 
           markeredgewidth=2, zorder=20)
    
    # Criar legenda customizada
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor='#2196F3', alpha=0.8, edgecolor='#1565C0', linewidth=2, 
              label=f'cdir = {cdir_value:.2f}'),
        Patch(facecolor='#66BB6A', alpha=0.8, edgecolor='#388E3C', linewidth=2, 
              label='cdir = 1.00')
    ]
    ax.legend(handles=legend_elements, loc='upper right', bbox_to_anchor=(1.12, 1.08), 
             fontsize=12, framealpha=0.95, edgecolor='black', fancybox=True, shadow=True)
    
    # Salvar gráfico
    pasta_imagens = os.path.join(pasta_saida, "imagens")
    os.makedirs(pasta_imagens, exist_ok=True)
    if nome_arquivo:
        filename = f"{nome_arquivo}.jpg"
    else:
        filename = "cdir_continuo.jpg"
    caminho_completo = os.path.join(pasta_imagens, filename)
    
    plt.tight_layout()
    plt.savefig(caminho_completo, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    print(f"\nGrafico de cdir continuo salvo: {caminho_completo}")
    
    return caminho_completo

def gerar_grafico_vb_cdir(cdir_por_setor, vb_value, pasta_saida, n_sectors, cdir_info=None, nome_arquivo=None,
                          lat=None, lon=None, radius_meters=None, altura_torre=None, resultado_final_data=None):
    """
    Gera um mapa com 8 fatias de pizza mostrando Vb * cdir por setor.
    Usa a mesma logica dos 80% do grafico cdir para decidir qual valor usar:
    - Se 80%+ da fatia esta na zona cdir -> Vb * cdir
    - Senao -> Vb * 1.0 (valor normal)
    """
    import matplotlib.pyplot as plt
    import numpy as np
    
    if not cdir_info:
        return None
    
    cdir_value = cdir_info['cdir']
    ang_i = cdir_info['ang_i']
    ang_f = cdir_info['ang_f']
    regiao = cdir_info.get('region', 'Franca')
    zona = cdir_info.get('zone', 'N/A')
    
    # 8 fatias visuais de 45 graus cada
    n_visual = 8
    angle_per_visual = 45.0
    half_visual = angle_per_visual / 2.0  # 22.5
    visual_sector_centers = [i * angle_per_visual for i in range(n_visual)]  # 0, 45, 90, ...
    visual_boundaries = [(c + half_visual) % 360 for c in visual_sector_centers]  # 22.5, 67.5, ...
    
    # Mesma funcao de calculo de porcentagem do grafico cdir
    def calcular_porcentagem_em_zona_cdir(boundary_start, boundary_end, ang_i, ang_f):
        boundary_start = boundary_start % 360
        boundary_end = boundary_end % 360
        
        if boundary_end >= boundary_start:
            amplitude_pedaco = boundary_end - boundary_start
        else:
            amplitude_pedaco = (360 - boundary_start) + boundary_end
        
        if ang_i <= ang_f:
            if boundary_end >= boundary_start:
                intersecao_start = max(boundary_start, ang_i)
                intersecao_end = min(boundary_end, ang_f)
                amplitude_intersecao = max(0, intersecao_end - intersecao_start)
            else:
                parte1 = max(0, min(360, ang_f) - max(boundary_start, ang_i)) if ang_f >= boundary_start and ang_i < 360 else 0
                parte2 = max(0, min(boundary_end, ang_f) - max(0, ang_i)) if ang_f >= 0 and ang_i <= boundary_end else 0
                amplitude_intersecao = max(0, parte1) + max(0, parte2)
        else:
            if boundary_end >= boundary_start:
                parte1 = max(0, min(boundary_end, 360) - max(boundary_start, ang_i)) if boundary_end >= ang_i else 0
                parte2 = max(0, min(boundary_end, ang_f) - boundary_start) if boundary_start <= ang_f else 0
                amplitude_intersecao = max(0, parte1) + max(0, parte2)
            else:
                amplitude_intersecao = (360 - max(boundary_start, ang_i)) + min(boundary_end, ang_f)
        
        if amplitude_pedaco > 0:
            return amplitude_intersecao / amplitude_pedaco
        return 0.0
    
    # Calcular Vb*cdir para cada fatia usando logica dos 80%
    vb_cdir_values = {}
    for vis_id in range(n_visual):
        # Setor vis_id (0=Norte, 1=NE, 2=E, ...) vai de boundary anterior ate boundary atual
        boundary_start = visual_boundaries[(vis_id - 1) % n_visual]
        boundary_end = visual_boundaries[vis_id]
        
        porcentagem = calcular_porcentagem_em_zona_cdir(boundary_start, boundary_end, ang_i, ang_f)
        
        # 80%+ na zona cdir -> usa cdir, senao usa 1.0
        if porcentagem >= 0.8:
            vb_cdir_values[vis_id + 1] = round(vb_value * cdir_value, 1)
        else:
            vb_cdir_values[vis_id + 1] = round(vb_value * 1.0, 1)
    
    # Calcular Pressure_wind para cada setor visual (8 fatias)
    pressure_results = []
    pressure_details = []
    if altura_torre is not None and resultado_final_data is not None:
        from Velocidade_Media import Velocidade_media
        from Iv_Calc import Iv_calc
        
        direcoes = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
        
        # Encontrar zmin global: o d do setor com menor z0 (unico para todo o mapa)
        menor_z0_global = float('inf')
        zmin_global = 0
        setor_menor_z0_key = None
        for sk, sd in resultado_final_data.items():
            if sk.startswith('setor_') and 'z0' in sd:
                if sd['z0'] < menor_z0_global:
                    menor_z0_global = sd['z0']
                    zmin_global = sd['d']
                    setor_menor_z0_key = sk
        
        # Constantes
        z02 = 0.05
        ki = 1.0
        rho = 1.225
        Alt = 0
        

        
        for vis_id in range(n_visual):
            vis_center = vis_id * angle_per_visual  # 0, 45, 90, ...
            vb_cdir_val = vb_cdir_values[vis_id + 1]
            
            # Limites angulares desta fatia visual
            boundary_start = visual_boundaries[(vis_id - 1) % n_visual]
            boundary_end = visual_boundaries[vis_id]
            
            # Calcular porcentagem de sobreposicao com zona cdir
            pct = calcular_porcentagem_em_zona_cdir(boundary_start, boundary_end, ang_i, ang_f)
            usa_cdir = pct >= 0.8
            cdir_aplicado = cdir_value if usa_cdir else 1.0
            
            # Encontrar setor de analise mais proximo do centro do setor visual
            melhor_setor = None
            melhor_setor_key = None
            menor_diff = 360
            for setor_key, setor_data in resultado_final_data.items():
                if not setor_key.startswith('setor_'):
                    continue
                ang = setor_data.get('angulo', None)
                if ang is None:
                    continue
                diff = abs(ang - vis_center)
                if diff > 180:
                    diff = 360 - diff
                if diff < menor_diff:
                    menor_diff = diff
                    melhor_setor = setor_data
                    melhor_setor_key = setor_key
            

            
            if melhor_setor:
                z0_sector = melhor_setor['z0']
                
                h = np.array([altura_torre])
                c0_arr = np.array([1])
                
                # PASSO 1: kr = 0.19 * (z0 / z0,II)^0.07
                kr = 0.19 * (z0_sector / z02) ** 0.07
                
                # PASSO 2: Cr (coeficiente de rugosidade)
                Cr = kr * math.log(altura_torre / z0_sector)
                
                # PASSO 3: vm = Cr * c0 * vb
                vm_val = Cr * 1 * vb_cdir_val
                
                # PASSO 4: Iv (intensidade de turbulencia)
                Iv_val = ki / (1 * math.log(altura_torre / z0_sector))
                
                # PASSO 5: qp = (1 + 7*Iv) * 0.5 * rho * vm^2
                qp_val = (1 + 7 * Iv_val) * 0.5 * rho * vm_val**2
                

                
                pressure_results.append(qp_val)
                
                # Verificacao cruzada com funcoes originais
                vm_check = Velocidade_media(h, vb_cdir_val, z0_sector, zmin_global, "France", c0_arr)
                IV_check = Iv_calc(h, z0_sector, zmin_global, 0, "France", c0_arr)
                pw_check = (1 + 7 * IV_check) * 0.5 * rho * vm_check**2
                
                pressure_details.append({
                    'direcao': direcoes[vis_id],
                    'angulo_centro': vis_center,
                    'ang_range': f"{boundary_start:.1f} - {boundary_end:.1f}",
                    'pct_cdir': pct * 100,
                    'usa_cdir': usa_cdir,
                    'cdir_aplicado': cdir_aplicado,
                    'vb': vb_value,
                    'vb_cdir': vb_cdir_val,
                    'z0': z0_sector,
                    'zmin': zmin_global,
                    'setor_analise': melhor_setor_key,
                    'vm': float(vm_check[0]),
                    'Iv': float(IV_check[0]),
                    'qp': float(pw_check[0])
                })
            else:
                pressure_results.append(0.0)
        

    
    # Obter lat/lon/radius
    if lat is None and cdir_info:
        lat = cdir_info.get('lat')
    if lon is None and cdir_info:
        lon = cdir_info.get('lon')
    if radius_meters is None:
        radius_meters = 300
    elif radius_meters < 300:
        radius_meters = 300
    
    if lat is None or lon is None:
        print("Aviso: Coordenadas nao disponiveis para mapa Vb x cdir")
        return None
    
    # Converter coordenadas para Web Mercator
    transformer_to_web = Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
    center_x, center_y = transformer_to_web.transform(lon, lat)
    
    # Corrigir raio para Web Mercator: em EPSG:3857 a escala longitudinal é 1/cos(lat)
    radius_wm = radius_meters / math.cos(math.radians(lat))
    
    fig, ax = plt.subplots(figsize=(10, 10), dpi=100)
    
    # Criar 8 fatias de pizza
    for vis_id in range(1, n_visual + 1):
        vb_cdir_val = vb_cdir_values[vis_id]
        
        # Angulo central (sistema matplotlib: Norte = 90)
        sector_center_angle = 90 - (vis_id - 1) * angle_per_visual
        half_sector = angle_per_visual / 2
        
        start_angle_deg = sector_center_angle + half_sector
        end_angle_deg = sector_center_angle - half_sector
        
        # Determinar cdir aplicado nesta fatia
        boundary_start = visual_boundaries[(vis_id - 2) % n_visual]
        boundary_end = visual_boundaries[vis_id - 1]
        pct = calcular_porcentagem_em_zona_cdir(boundary_start, boundary_end, ang_i, ang_f)
        cdir_fatia = cdir_value if pct >= 0.8 else 1.0
        
        # Cor: azul se cdir aplicado, verde se valor normal (1.0)
        if vb_cdir_val < vb_value:
            color = '#2196F3'  # Azul - zona cdir
        else:
            color = '#66BB6A'  # Verde - valor normal
        
        wedge = plt.matplotlib.patches.Wedge(
            center=(center_x, center_y),
            r=radius_wm,
            theta1=end_angle_deg,
            theta2=start_angle_deg,
            facecolor=color,
            edgecolor='black',
            linewidth=1,
            alpha=0.85
        )
        ax.add_patch(wedge)
        
        # Valor no centro da fatia
        mid_angle_deg = (start_angle_deg + end_angle_deg) / 2
        mid_angle_rad = math.radians(mid_angle_deg)
        
        text_radius = radius_wm * 0.7
        text_x = center_x + text_radius * math.cos(mid_angle_rad)
        text_y = center_y + text_radius * math.sin(mid_angle_rad)
        
        label_text = f"Cdir = {cdir_fatia}\nVb = {vb_cdir_val:.1f}m/s"
        ax.text(text_x, text_y, label_text,
                fontsize=11, fontweight='bold', ha='center', va='center',
                color='black',
                bbox=dict(boxstyle='round,pad=0.4', facecolor='white', alpha=0.9, edgecolor='black', linewidth=1))
    
    # Eixos
    buffer = radius_wm * 1.12
    ax.set_xlim(center_x - buffer, center_x + buffer)
    ax.set_ylim(center_y - buffer, center_y + buffer)
    ax.set_aspect('equal')
    
    # Mapa de fundo
    _adicionar_mapa_base(ax)
    
    ax.set_axis_off()
    
    # Salvar
    pasta_imagens = os.path.join(pasta_saida, "imagens")
    os.makedirs(pasta_imagens, exist_ok=True)
    if nome_arquivo:
        filename = f"{nome_arquivo}.jpg"
    else:
        filename = "vb_cdir.jpg"
    caminho_completo = os.path.join(pasta_imagens, filename)
    
    plt.tight_layout(pad=0.5)
    plt.savefig(caminho_completo, dpi=300, bbox_inches='tight', pad_inches=0.1, facecolor='white', edgecolor='none')
    plt.close()
    
    print(f"\nGrafico de Vb x cdir salvo: {caminho_completo}")
    
    if pressure_results:
        return pressure_results, pressure_details
    return caminho_completo, []


def obter_cdir_franca(lat, lon, n_sectors):
    """
    Obtém os valores de cdir (coeficiente direcional) para cada setor baseado na localização na França.
    
    Args:
        lat: Latitude da localização
        lon: Longitude da localização
        n_sectors: Número de setores (geralmente 12)
    
    Returns:
        dict: Dicionário com cdir para cada setor (setor_1 a setor_n)
              Retorna None se não for França continental ou se houver erro
    """
    CDIR_GEOJSON_PATH = os.path.join(_AQUI, 'wind_map_cdir_france.geojson')
    
    # Verificar se o arquivo existe
    if not os.path.exists(CDIR_GEOJSON_PATH):
        print(f"Arquivo {CDIR_GEOJSON_PATH} não encontrado")
        return None
    
    # Verificar se é França Metropolitana (continental)
    FRANCA_METROPOLITANA_BOUNDS = {
        'lat_min': 41.0, 
        'lat_max': 51.5, 
        'lon_min': -5.5, 
        'lon_max': 10.0
    }
    
    if not (FRANCA_METROPOLITANA_BOUNDS['lat_min'] <= lat <= FRANCA_METROPOLITANA_BOUNDS['lat_max'] and 
            FRANCA_METROPOLITANA_BOUNDS['lon_min'] <= lon <= FRANCA_METROPOLITANA_BOUNDS['lon_max']):
        print("Localização fora da França Metropolitana - cdir não aplicável")
        return None
    
    try:
        # Carregar o GeoJSON
        with open(CDIR_GEOJSON_PATH, 'r', encoding='utf-8') as f:
            geojson_data = json.load(f)
        
        point = Point(lon, lat)
        cdir_info = None
        
        # Procurar em qual região o ponto está
        for feature in geojson_data['features']:
            poly = geom.shape(feature['geometry'])
            if poly.contains(point):
                props = feature['properties']
                cdir_info = {
                    'cdir': props.get('cdir', 1.0),
                    'ang_i': props.get('ang_i', 0),
                    'ang_f': props.get('ang_f', 360),
                    'region': props.get('NAME_1', 'Desconhecida'),
                    'zone': props.get('Zone', 'N/A')
                }
                break
        
        if not cdir_info:
            print(f"Coordenada ({lat}, {lon}) não encontrada no mapa cdir da França")
            return None
        
        print(f"\n{'='*60}")
        print(f"CDIR FRANÇA - Informações da Região")
        print(f"{'='*60}")
        print(f"Região: {cdir_info['region']}")
        print(f"Zona: {cdir_info['zone']}")
        print(f"Valor cdir: {cdir_info['cdir']}")
        print(f"Ângulo inicial: {cdir_info['ang_i']}°")
        print(f"Ângulo final: {cdir_info['ang_f']}°")
        print(f"{'='*60}\n")
        
        # Calcular cdir para cada setor
        angle_per_sector = 360 / n_sectors
        cdir_por_setor = {}
        
        for setor_id in range(1, n_sectors + 1):
            # Ângulo central do setor
            setor_angulo_central = (setor_id - 1) * angle_per_sector + (angle_per_sector / 2)
            
            # Normalizar para 0-360
            setor_angulo_central = setor_angulo_central % 360
            
            # Verificar se o ângulo do setor está dentro do range ang_i até ang_f
            ang_i = cdir_info['ang_i']
            ang_f = cdir_info['ang_f']
            
            # Verificar se o ângulo está no intervalo (considerando que pode cruzar 0°)
            if ang_i <= ang_f:
                # Intervalo normal (ex: 10° a 150°)
                dentro_do_intervalo = ang_i <= setor_angulo_central <= ang_f
            else:
                # Intervalo que cruza 0° (ex: 330° a 30°)
                dentro_do_intervalo = setor_angulo_central >= ang_i or setor_angulo_central <= ang_f
            
            if dentro_do_intervalo:
                cdir_por_setor[f"setor_{setor_id}"] = cdir_info['cdir']
            else:
                cdir_por_setor[f"setor_{setor_id}"] = 0.0
        
        return {
            'cdir_por_setor': cdir_por_setor,
            'info_regiao': cdir_info
        }
        
    except Exception as e:
        print(f"Erro ao processar cdir da França: {e}")
        import traceback
        traceback.print_exc()
        return None

def gerar_resultado_final_json(wk_by_main_sector_path, pasta_saida, n_sectors, lat=None, lon=None, pais=None, radius_meters=None, altura_torre=None):    

    WIND_GEOJSON_FILES = {
        'Belgium': 'Wind_Map_Belgium_EC.geojson',
        'France': 'Wind_Map_France_EC.geojson',
        'Germany': 'Wind_Map_Germany_EC.geojson',
        'Italy': 'Wind_Map_Italy_EC.geojson',
        'Luxembourg': 'Wind_Map_Luxembourg_EC.geojson',
        'Netherlands': 'Wind_Map_Netherlands_EC.geojson',
        'Portugal': 'Wind_Map_Portugal_EC.geojson',
        'Spain': 'Wind_Map_Spain_EC.geojson'
    }

    try:
        with open(wk_by_main_sector_path, 'r', encoding='utf-8') as f:
            wk_data = json.load(f)
    except Exception as e:
        return None

    angle_per_sector = 360 / n_sectors

    resultado_final = {}

    setores_processados = 0
    z0_values = []

    for setor_name, setor_data in wk_data.items():
        if 'z0_setor_final' in setor_data:
            setor_id = int(setor_name.split('_')[1])
            z0_value = setor_data['z0_setor_final']
            d_value = setor_data.get('d_setor_final', 0.0)

            sector_center_angle_geo = (setor_id - 1) * angle_per_sector

            resultado_final[f"setor_{setor_id}"] = {
                "z0": round(z0_value, 6),
                "d": round(d_value, 2),
                "angulo": round(sector_center_angle_geo, 1)
            }

            z0_values.append(z0_value)
            setores_processados += 1

    # OBTER VALOR DE VENTO (vb)
    vb_value = None
    wind_data = None
    if lat is not None and lon is not None and pais is not None:
        # Determinar qual arquivo GeoJSON usar baseado no país
        geojson_file = os.path.join(_AQUI, WIND_GEOJSON_FILES[pais]) if pais in WIND_GEOJSON_FILES else None
        
        if geojson_file:
            try:
                from GetWindValues import get_wind_value
                wind_result = get_wind_value(lat, lon, geojson_path=geojson_file)
                if wind_result:
                    vb_value = wind_result['vb']
                    wind_data = {
                        'vb': wind_result['vb'],
                        'zona': wind_result['zona']
                    }
                    print(f"Valor de vento encontrado: vb = {vb_value} m/s (Zona {wind_result['zona']}) [{pais}]")
                else:
                    print(f"Coordenada ({lat}, {lon}) não encontrada no mapa de ventos de {pais}")
            except ImportError:
                print("Módulo GetWindValues não encontrado. Continuando sem dados de vento.")
            except Exception as e:
                print(f"Erro ao obter valor de vento: {e}")
        else:
            print(f"Mapa de ventos não disponível para o país: {pais}")
            print(f"   Países disponíveis: {', '.join(WIND_GEOJSON_FILES.keys())}")
    
    # Adicionar dados de vento ao resultado final
    if wind_data:
        resultado_final['vento'] = wind_data
    
    # PROCESSAR CDIR PARA FRANÇA CONTINENTAL
    cdir_data = None
    if pais == 'France' and lat is not None and lon is not None:
        cdir_result = obter_cdir_franca(lat, lon, n_sectors)
        if cdir_result:
            cdir_data = cdir_result
            
            # Aplicar cdir aos setores no resultado_final
            # cdir_por_setor usa 0.0 como sentinela interno de "fora da zona
            # reduzida" (ver gerar_grafico_cdir) -- mas cdir (EN 1991-1-4)
            # nunca e <= 0 na realidade: fora da zona reduzida o valor
            # correto e 1.0 (sem reducao), nao 0.0 (era isto que estava a
            # sair em resultado_final.json, dando pressao de vento zero
            # nesses setores caso alguem use este ficheiro diretamente).
            for setor_name in resultado_final:
                if setor_name.startswith('setor_'):
                    cdir_value = cdir_result['cdir_por_setor'].get(setor_name, 0.0)
                    resultado_final[setor_name]['cdir'] = round(cdir_value, 2) if cdir_value > 0 else 1.0
            
            # Adicionar informações da região
            resultado_final['cdir_info'] = {
                'regiao': cdir_result['info_regiao']['region'],
                'zona': cdir_result['info_regiao']['zone'],
                'cdir_base': cdir_result['info_regiao']['cdir'],
                'angulo_inicial': cdir_result['info_regiao']['ang_i'],
                'angulo_final': cdir_result['info_regiao']['ang_f']
            }
            
            # Gerar gráfico de cdir por setor
            try:
                gerar_grafico_cdir(cdir_result['cdir_por_setor'], pasta_saida, n_sectors, 
                                  cdir_info=cdir_result['info_regiao'])
            except Exception as e:
                print(f"Erro ao gerar gráfico de cdir: {e}")
            
            # Gerar gráfico de Vb * cdir (se vb_value estiver disponível)
            if vb_value is not None:
                try:
                    gerar_grafico_vb_cdir(cdir_result['cdir_por_setor'], vb_value, pasta_saida,
                                         n_sectors, cdir_info=cdir_result['info_regiao'],
                                         lat=lat, lon=lon, radius_meters=radius_meters,
                                         altura_torre=altura_torre, resultado_final_data=resultado_final)
                    # NOTA: o mapa de pressoes (qp_pressure.jpg) e o "pior
                    # caso" ficam so na etapa 4 (co_wind_analysis, baseado em
                    # resultados_direcoes.csv/resultados_maximos.csv -- a
                    # pressao real, com co e cdir). O que este grafico
                    # calcula (sem co) nao alimenta mais o cdir.json.
                except Exception as e:
                    print(f"Erro ao gerar gráfico de Vb × cdir: {e}")
            
            # Gerar JSON de cdir por fatia
            try:
                direcoes_8 = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
                angle_per_vis = 45.0
                half_vis = 22.5
                vis_centers = [i * angle_per_vis for i in range(8)]
                vis_bounds = [(c + half_vis) % 360 for c in vis_centers]
                
                cdir_json = {
                    "regiao": cdir_result['info_regiao'].get('region', ''),
                    "zona": cdir_result['info_regiao'].get('zone', ''),
                    "cdir": cdir_result['info_regiao'].get('cdir', 1.0),
                    "angulo_cdir_inicio": cdir_result['info_regiao'].get('ang_i', 0),
                    "angulo_cdir_fim": cdir_result['info_regiao'].get('ang_f', 0),
                    "setores": []
                }
                
                for vis_id in range(8):
                    b_start = vis_bounds[(vis_id - 1) % 8]
                    b_end = vis_bounds[vis_id]
                    
                    # Determinar cdir aplicado (mesma logica 80%)
                    ang_i_cdir = cdir_result['info_regiao'].get('ang_i', 0)
                    ang_f_cdir = cdir_result['info_regiao'].get('ang_f', 0)
                    cdir_base = cdir_result['info_regiao'].get('cdir', 1.0)
                    
                    # Calcular sobreposicao
                    if b_end >= b_start:
                        amp = b_end - b_start
                    else:
                        amp = (360 - b_start) + b_end
                    
                    if ang_i_cdir <= ang_f_cdir:
                        if b_end >= b_start:
                            inter = max(0, min(b_end, ang_f_cdir) - max(b_start, ang_i_cdir))
                        else:
                            p1 = max(0, min(360, ang_f_cdir) - max(b_start, ang_i_cdir)) if ang_f_cdir >= b_start else 0
                            p2 = max(0, min(b_end, ang_f_cdir) - max(0, ang_i_cdir)) if ang_i_cdir <= b_end else 0
                            inter = p1 + p2
                    else:
                        if b_end >= b_start:
                            p1 = max(0, min(b_end, 360) - max(b_start, ang_i_cdir)) if b_end >= ang_i_cdir else 0
                            p2 = max(0, min(b_end, ang_f_cdir) - b_start) if b_start <= ang_f_cdir else 0
                            inter = p1 + p2
                        else:
                            inter = (360 - max(b_start, ang_i_cdir)) + min(b_end, ang_f_cdir)
                    
                    pct = inter / amp if amp > 0 else 0
                    cdir_aplicado = cdir_base if pct >= 0.8 else 1.0
                    
                    cdir_json["setores"].append({
                        "angulo_inicio": b_start,
                        "angulo_fim": b_end,
                        "cdir": cdir_aplicado,
                    })

                # "qp" por setor (e "pior_pressão") foram removidos -- eram
                # calculados aqui (etapa 2, ANTES da orografia/co existir)
                # com uma divisao de 8 direcoes (N/NE/E/SE/S/SW/W/NW)
                # diferente da usada no calculo final (Direcao 0/45/90/135
                # x lado ESQ/DIR, vindo do perfil de terreno) -- por isso
                # esses valores quase nunca batiam com o relatorio final
                # (resultados_direcoes.csv/resultados_maximos.csv, que ja
                # incluem co e sao sempre a fonte correta da pressao real).

                cdir_json_path = os.path.join(pasta_saida, "cdir.json")
                with open(cdir_json_path, 'w', encoding='utf-8') as f:
                    json.dump(cdir_json, f, ensure_ascii=False, indent=4)
                print(f"JSON de cdir salvo: {cdir_json_path}")
            except Exception as e:
                print(f"Erro ao gerar JSON de cdir: {e}")
    
    # GERAR MAPA DE VENTOS (JPEG)
    if lat is not None and lon is not None and pais is not None and wind_data is not None:
        geojson_file = os.path.join(_AQUI, WIND_GEOJSON_FILES[pais]) if pais in WIND_GEOJSON_FILES else None
        if geojson_file and os.path.exists(geojson_file):
            try:
                gerar_mapa_ventos_jpeg(lat, lon, geojson_file, pasta_saida, wind_data)
            except Exception as e:
                print(f"Erro ao gerar mapa de ventos: {e}")
    
    # Salvar arquivo JSON
    resultado_final_path = os.path.join(pasta_saida, "resultado_final.json")
    try:
        with open(resultado_final_path, 'w', encoding='utf-8') as f:
            json.dump(resultado_final, f, ensure_ascii=False, indent=4)
        
        return {
            'filename': resultado_final_path,
            'sectors_processed': setores_processados,
            'z0_range': {
                'min': min(z0_values) if z0_values else 0,
                'max': max(z0_values) if z0_values else 0
            },
            'wind_data': wind_data
        }
        
    except Exception as e:
        return None

def gerar_mapa_ventos_jpeg(lat, lon, geojson_path, pasta_saida, wind_data):
    """
    Gera um mapa JPEG mostrando APENAS a região específica (Continental, Açores ou Madeira para Portugal,
    Continental ou Canárias para Espanha, ou Metropolitana e territórios ultramarinos para França).
    """
    try:
        from shapely.geometry import box
        
        # Definir limites geográficos RESTRITOS das regiões de Portugal
        REGIOES_PORTUGAL = {
            'Portugal Continental': {
                'bounds': {'lat_min': 36.8, 'lat_max': 42.2, 'lon_min': -9.75, 'lon_max': -5.6}
            },
            'Açores': {
                'bounds': {'lat_min': 36.9, 'lat_max': 39.75, 'lon_min': -31.3, 'lon_max': -24.8}
            },
            'Madeira': {
                'bounds': {'lat_min': 32.3, 'lat_max': 33.15, 'lon_min': -17.3, 'lon_max': -16.2}
            }
        }
        
        REGIOES_ESPANHA = {
            'Espanha Continental': {
                'bounds': {'lat_min': 33.0, 'lat_max': 45.3, 'lon_min': -9.8, 'lon_max': 4.8}
            },
            'Ilhas Canárias': {
                'bounds': {'lat_min': 27.3, 'lat_max': 29.8, 'lon_min': -18.2, 'lon_max': -13.4}
            }
        }
        
        REGIOES_FRANCA = {
            'França Metropolitana': {
                'bounds': {'lat_min': 41.0, 'lat_max': 51.5, 'lon_min': -5.5, 'lon_max': 10.0}
            },
            'Guadalupe': {
                'bounds': {'lat_min': 15.8, 'lat_max': 16.6, 'lon_min': -61.9, 'lon_max': -61.0}
            },
            'Martinica': {
                'bounds': {'lat_min': 14.3, 'lat_max': 14.9, 'lon_min': -61.3, 'lon_max': -60.7}
            },
            'Guiana Francesa': {
                'bounds': {'lat_min': 2.0, 'lat_max': 6.0, 'lon_min': -55.0, 'lon_max': -51.0}
            },
            'Reunião': {
                'bounds': {'lat_min': -21.5, 'lat_max': -20.8, 'lon_min': 55.2, 'lon_max': 55.9}
            },
            'Mayotte': {
                'bounds': {'lat_min': -13.1, 'lat_max': -12.5, 'lon_min': 44.9, 'lon_max': 45.4}
            }
        }
        
        REGIOES_LUXEMBURGO = {
            'Luxembourg': {
                'bounds': {'lat_min': 49.4, 'lat_max': 50.2, 'lon_min': 5.7, 'lon_max': 6.6}
            }
        }
        
        # Detectar região baseada na latitude/longitude
        regiao_detectada = None
        bounds_regiao = None
        
        if 'Luxembourg' in geojson_path:
            for regiao, dados in REGIOES_LUXEMBURGO.items():
                b = dados['bounds']
                if (b['lat_min'] <= lat <= b['lat_max'] and 
                    b['lon_min'] <= lon <= b['lon_max']):
                    regiao_detectada = regiao
                    bounds_regiao = b
                    print(f"Região detectada: {regiao}")
                    break
        
        elif 'Portugal' in geojson_path:
            for regiao, dados in REGIOES_PORTUGAL.items():
                b = dados['bounds']
                if (b['lat_min'] <= lat <= b['lat_max'] and 
                    b['lon_min'] <= lon <= b['lon_max']):
                    regiao_detectada = regiao
                    bounds_regiao = b
                    print(f"Região detectada: {regiao}")
                    break
        
        elif 'Spain' in geojson_path:
            for regiao, dados in REGIOES_ESPANHA.items():
                b = dados['bounds']
                if (b['lat_min'] <= lat <= b['lat_max'] and 
                    b['lon_min'] <= lon <= b['lon_max']):
                    regiao_detectada = regiao
                    bounds_regiao = b
                    print(f"Região detectada: {regiao}")
                    break
        
        elif 'France' in geojson_path:
            for regiao, dados in REGIOES_FRANCA.items():
                b = dados['bounds']
                if (b['lat_min'] <= lat <= b['lat_max'] and 
                    b['lon_min'] <= lon <= b['lon_max']):
                    regiao_detectada = regiao
                    bounds_regiao = b
                    print(f"Região detectada: {regiao}")
                    break
        
        # Ler GeoJSON
        gdf = gpd.read_file(geojson_path)
        
        # CORTAR GEOMETRIAS se for Portugal, Espanha ou França
        if bounds_regiao:
            print(f"Cortando geometrias para mostrar apenas {regiao_detectada}")
            
            # Criar polígono de corte (bbox da região)
            bbox = box(bounds_regiao['lon_min'], bounds_regiao['lat_min'], 
                      bounds_regiao['lon_max'], bounds_regiao['lat_max'])
            
            # Filtrar apenas geometrias que intersectam o bbox
            gdf = gdf[gdf.intersects(bbox)]
            
            # Cortar as geometrias no limite exato do bbox
            gdf['geometry'] = gdf['geometry'].intersection(bbox)
            
            print(f"{len(gdf)} polígonos na região")
            
            if len(gdf) == 0:
                print(f"Nenhuma geometria encontrada para {regiao_detectada}")
                return None
        
        # Converter para Web Mercator
        gdf = gdf.to_crs(epsg=3857)
        
        # Converter coordenadas do ponto para Web Mercator
        transformer = Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
        lon_web, lat_web = transformer.transform(lon, lat)
        
        # Criar figura
        fig, ax = plt.subplots(figsize=(12, 10))
        
        # Obter valores únicos de vb e ordenar
        vb_valores_unicos = sorted(gdf['vb'].unique())
        
        # Criar colormap
        from matplotlib.cm import ScalarMappable
        from matplotlib.colors import Normalize
        
        cmap = plt.get_cmap('YlOrRd')
        norm = Normalize(vmin=min(vb_valores_unicos), vmax=max(vb_valores_unicos))
        
        # Plotar polígonos de vento (sem legenda automática)
        gdf.plot(ax=ax, column='vb', cmap='YlOrRd', edgecolor='black', 
                 linewidth=0.5, alpha=0.5, legend=False)
        
        # Criar legenda customizada com apenas os valores encontrados
        legend_patches = []
        for vb_value in vb_valores_unicos:
            color = cmap(norm(vb_value))
            patch = Patch(facecolor=color, edgecolor='black', label=f'{vb_value:.1f}')
            legend_patches.append(patch)
        
        # Adicionar legenda no canto superior direito dentro do mapa
        ax.legend(handles=legend_patches, title='Vb (m/s)', 
                 loc='upper right', 
                 frameon=True, fontsize=10, facecolor='white', edgecolor='black', framealpha=0.9)
        
        # Adicionar bloco de "Zona de vento" no canto inferior direito
        if wind_data and 'vb' in wind_data:
            vb_vento = wind_data['vb']
            # Criar texto com box
            textstr = f'Basic Wind Speed: {vb_vento} m/s'
            props = dict(boxstyle='round', facecolor='white', edgecolor='black', alpha=0.9)
            ax.text(0.98, 0.02, textstr, transform=ax.transAxes, fontsize=11,
                   verticalalignment='bottom', horizontalalignment='right', bbox=props, zorder=10)
        
        # Adicionar marcador de imagem no ponto
        try:
            from matplotlib.offsetbox import OffsetImage, AnnotationBbox
            import matplotlib.image as mpimg
            
            # Carregar imagem do marcador
            icon_path = 'map-pointer.png'
            if os.path.exists(icon_path):
                icon = mpimg.imread(icon_path)
                imagebox = OffsetImage(icon, zoom=0.15)  # Ajustar zoom conforme necessário
                # box_alignment ajusta o ponto de ancoragem: (0.5, 0) significa centro horizontal e base da imagem
                # xybox com offset negativo em y move a imagem para cima, compensando os 15px da base
                ab = AnnotationBbox(imagebox, (lon_web, lat_web), 
                                  frameon=False, 
                                  box_alignment=(0.5, 0.15),  # Centro horizontal, 15% da altura (aproximadamente 15px)
                                  zorder=10)
                ax.add_artist(ab)
            else:
                print(f"Imagem 'map-pointer.png' não encontrada. Usando marcador padrão.")
                ax.plot(lon_web, lat_web, marker='o', color='red', markersize=8, 
                        markeredgecolor='white', markeredgewidth=2, zorder=5)
        except Exception as e:
            print(f"Erro ao carregar imagem do marcador: {e}. Usando marcador padrão.")
            ax.plot(lon_web, lat_web, marker='o', color='red', markersize=8, 
                    markeredgecolor='white', markeredgewidth=2, zorder=5)
        
        # Ajustar limites para focar na área de interesse
        if bounds_regiao:
            # Converter bounds da região para Web Mercator
            lon_min_web, lat_min_web = transformer.transform(bounds_regiao['lon_min'], bounds_regiao['lat_min'])
            lon_max_web, lat_max_web = transformer.transform(bounds_regiao['lon_max'], bounds_regiao['lat_max'])
            
            ax.set_xlim(lon_min_web, lon_max_web)
            ax.set_ylim(lat_min_web, lat_max_web)
        else:
            # Zoom padrão ao redor do ponto
            delta_x = 120000  # ~1 grau em metros (Web Mercator)
            delta_y = 80000   # ~0.7 graus em metros
            ax.set_xlim(lon_web - delta_x, lon_web + delta_x)
            ax.set_ylim(lat_web - delta_y, lat_web + delta_y)
        
        # Adicionar basemap
        _adicionar_mapa_base(ax)
        
        # Configurar título
        ax.set_aspect("equal")
        ax.set_axis_off()
        plt.tight_layout()
        
        # Criar pasta 'imagens' se não existir
        pasta_imagens = os.path.join(pasta_saida, 'imagens')
        os.makedirs(pasta_imagens, exist_ok=True)
        
        # Salvar como JPEG
        output_path = os.path.join(pasta_imagens, "Wind_Map.jpg")
        plt.savefig(output_path, dpi=300, format='jpeg', bbox_inches='tight')
        plt.close()
        
        print(f"Mapa de ventos gerado: {output_path}")
        return output_path
        
    except Exception as e:
        print(f"Erro ao gerar mapa de ventos: {e}")
        import traceback
        traceback.print_exc()
        return None

# Para compatibilidade com execução direta


# ==========================================================================
# ENTRADA
# ==========================================================================
def analisar_vento(pasta_saida, lat=None, lon=None, pais=None, altura_torre=None,
                   n_sectors=None, radius_meters=None, regiao="N/A"):
    """Corre a analise de vento sobre uma pasta  resultados/<ID>/  ja feita pelo
    modulo Rugosidade. Se os parametros nao forem dados, le-os de site_info.json."""
    info_path = os.path.join(pasta_saida, "site_info.json")
    if os.path.isfile(info_path):
        with open(info_path, "r", encoding="utf-8") as f:
            info = json.load(f)
        lat           = lat           if lat           is not None else info.get("lat")
        lon           = lon           if lon           is not None else info.get("lon")
        pais          = pais          or info.get("pais")
        altura_torre  = altura_torre  if altura_torre  is not None else info.get("altura_torre")
        n_sectors     = n_sectors     if n_sectors     is not None else info.get("n_sectors")
        radius_meters = radius_meters if radius_meters is not None else info.get("radius_meters")
        if (not regiao or regiao == "N/A"):
            regiao = info.get("regiao", "N/A")

    if None in (lat, lon, pais, n_sectors):
        raise SystemExit(
            "ERRO: faltam dados (lat/lon/pais/n_sectors) e nao ha site_info.json. "
            'Passa o argumento completo: "ID,PAIS,LAT,LON,ALTURA,N_SECTORS,REGIAO".')

    if radius_meters is None and altura_torre is not None:
        radius_meters = max(23.0 * (float(altura_torre) ** 1.2), 300.0)

    wk_path = os.path.join(pasta_saida, "wk_by_main_sector.json")
    if not os.path.isfile(wk_path):
        raise SystemExit(f"ERRO: nao encontrei {wk_path} -- corre primeiro o modulo Rugosidade.")

    print(f"Vento: {pais} | {lat:.5f}, {lon:.5f} | n_sectors={n_sectors} | pasta={pasta_saida}")
    return gerar_resultado_final_json(
        wk_by_main_sector_path=wk_path,
        pasta_saida=pasta_saida,
        n_sectors=int(n_sectors),
        lat=float(lat),
        lon=float(lon),
        pais=pais,
        radius_meters=(float(radius_meters) if radius_meters is not None else None),
        altura_torre=(float(altura_torre) if altura_torre is not None else None),
    )


if __name__ == "__main__":
    argv = sys.argv[1:]
    outdir = os.path.join(os.getcwd(), "resultados")
    if "--outdir" in argv:
        _i = argv.index("--outdir")
        outdir = argv[_i + 1]
        del argv[_i:_i + 2]
    if not argv:
        print(__doc__)
        sys.exit(1)

    spec = argv[0]
    if "," in spec:
        p = [x.strip() for x in spec.split(",")]
        _id = p[0]
        _pais = p[1]
        _lat = float(p[2])
        _lon = float(p[3])
        _alt = float(p[4]) if len(p) > 4 and p[4] else None
        _ns = int(p[5]) if len(p) > 5 and p[5] else None
        _reg = p[6] if len(p) > 6 and p[6] else "N/A"
        _pasta = os.path.join(outdir, _id)
        os.makedirs(_pasta, exist_ok=True)
        analisar_vento(_pasta, _lat, _lon, _pais, _alt, _ns, None, _reg)
    else:
        _pasta = os.path.join(outdir, spec)
        if not os.path.isdir(_pasta):
            raise SystemExit(f"ERRO: pasta nao existe: {_pasta}")
        analisar_vento(_pasta)
    print("Vento: concluido.")
