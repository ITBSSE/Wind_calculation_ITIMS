import numpy as np
import matplotlib
matplotlib.use("Agg")   # servidor Linux sem display / .exe onefile
import matplotlib.pyplot as plt
import rasterio
from math import cos, sin, radians
from scipy.interpolate import RectBivariateSpline
from scipy.optimize import least_squares
from shapely.geometry import Point
import geopandas as gpd
import os
import sys
from openpyxl import Workbook
from openpyxl.styles import Font

# --- C0Z0_Solution: rasters de elevacao (output_hh.tif / acores_hh.tif) em
#     dados/ ao lado do .exe / do codigo. Caminho vem do config.py. ---
try:
    _RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _RAIZ not in sys.path:
        sys.path.insert(0, _RAIZ)
    from config import DADOS as _DADOS
except Exception:
    _b = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else _RAIZ
    _DADOS = os.environ.get("C0Z0_DADOS") or os.path.join(_b, "dados")

_DEM_DEFAULT = os.path.join(_DADOS, "output_hh.tif")

# Rasters locais ja prontos (continente PT + Acores) -- cobrem o pais todo de
# uma vez. Fora deles baixa-se o tile Copernicus GLO-30 sob demanda.
_RASTER_MAINLAND = os.path.join(_DADOS, "output_hh.tif")
_RASTER_ACORES   = os.path.join(_DADOS, "acores_hh.tif")


def escolher_raster(lat, lon, raio_m=1500):
    """Devolve o caminho do raster de elevacao a usar para (lat, lon):
    - raster local do continente ou dos Acores quando o ponto cai dentro;
    - senao, baixa/cacheia o(s) tile(s) Copernicus GLO-30 que cobrem o ponto
      (qualquer lugar do mundo: Madeira, Franca, Espanha, etc.)."""
    for caminho in (_RASTER_MAINLAND, _RASTER_ACORES):
        try:
            with rasterio.open(caminho) as ds:
                b = ds.bounds
            if b.left <= lon <= b.right and b.bottom <= lat <= b.top:
                return caminho
        except Exception:
            pass
    from dem_download import obter_raster_para_ponto
    return obter_raster_para_ponto(lat, lon, raio_m)


def criar_interpolador(lat_centro, lon_centro, raio_m, arquivo=None):
    if arquivo is None:
        arquivo = _DEM_DEFAULT

    print(f"Carregando região específica do raster: {arquivo}")
    print(f"Centro: {lat_centro:.6f}, {lon_centro:.6f}")
    print(f"Raio: {raio_m}m")

    with rasterio.open(arquivo) as dataset:
        dlat = raio_m / 111320
        dlon = raio_m / (111320 * cos(radians(lat_centro)))

        margem = 1.2
        dlat *= margem
        dlon *= margem

        lat_min = lat_centro - dlat
        lat_max = lat_centro + dlat
        lon_min = lon_centro - dlon
        lon_max = lon_centro + dlon

        print(f"Bounding box calculado:")
        print(f"  Lat: [{lat_min:.6f}, {lat_max:.6f}]")
        print(f"  Lon: [{lon_min:.6f}, {lon_max:.6f}]")

        transform = dataset.transform

        col_min, row_max = ~transform * (lon_min, lat_min)
        col_max, row_min = ~transform * (lon_max, lat_max)

        row_min = max(0, int(row_min))
        row_max = min(dataset.height, int(row_max) + 1)
        col_min = max(0, int(col_min))
        col_max = min(dataset.width, int(col_max) + 1)

        height_region = row_max - row_min
        width_region = col_max - col_min
        total_pixels_region = height_region * width_region
        total_pixels_original = dataset.height * dataset.width

        print(f"Dimensões da região: {width_region} x {height_region} = {total_pixels_region:,} pixels")
        print(f"Redução: {total_pixels_original / total_pixels_region:.1f}x menos pixels")

        window = rasterio.windows.Window(col_min, row_min, width_region, height_region)
        data_region = dataset.read(1, window=window).astype(float)

        if dataset.nodata is not None:
            pixels_nodata = data_region == dataset.nodata
            if pixels_nodata.any():
                # Substitui nodata (tipicamente mar/agua, fora da cobertura
                # de DTMs so-terra) por 0m (nivel do mar) em vez de deixar
                # o valor de nodata contaminar a interpolacao do perfil.
                print(f"  Aviso: {pixels_nodata.sum()} pixels de nodata na regiao "
                      f"(substituidos por 0m, provavelmente mar/agua)")
                data_region[pixels_nodata] = 0

        transform_region = rasterio.windows.transform(window, transform)

        x_coords = np.arange(width_region) * transform_region.a + transform_region.c
        y_coords = np.arange(height_region) * transform_region.e + transform_region.f

        lons_region = x_coords
        lats_region = y_coords

        print(f"Coordenadas da região extraída:")
        print(f"  Lons: [{lons_region[0]:.6f}, {lons_region[-1]:.6f}]")
        print(f"  Lats: [{lats_region[0]:.6f}, {lats_region[-1]:.6f}]")

        print("Criando interpolador para a região específica...")
        f = RectBivariateSpline(lats_region[::-1], lons_region, data_region[::-1, :])

        print("Interpolador criado com sucesso!")

    return f

def obter_elevacao_interpolada(latitudes, longitudes, interpolador):
    return interpolador(latitudes, longitudes, grid=False)

def calcular_altitude_torre(lat, lon, raio_m=300.0, arquivo_glo30=None):
    """Altitude (m acima do nivel do mar) = elevacao do DEM no ponto exato da
    torre, sem gerar perfis nem imagens. Usada quando a Orografia esta
    desligada (a etapa de perfil nao corre, mas a altitude continua a sair)."""
    if arquivo_glo30 is None:
        arquivo_glo30 = escolher_raster(lat, lon, raio_m)
    interpolador = criar_interpolador(lat, lon, raio_m, arquivo_glo30)
    return float(obter_elevacao_interpolada(np.array([lat]), np.array([lon]), interpolador)[0])


def gerar_pontos_linha_diametral(lat1, lon1, lat2, lon2, lat_centro, lon_centro, raio_m, num_pontos=200):

    ponto1 = Point(lon1, lat1)
    ponto2 = Point(lon2, lat2)
    centro = Point(lon_centro, lat_centro)

    gdf_ponto1 = gpd.GeoDataFrame(geometry=[ponto1], crs="EPSG:4326").to_crs(epsg=32629)
    gdf_ponto2 = gpd.GeoDataFrame(geometry=[ponto2], crs="EPSG:4326").to_crs(epsg=32629)
    gdf_centro = gpd.GeoDataFrame(geometry=[centro], crs="EPSG:4326").to_crs(epsg=32629)

    ponto1_m = gdf_ponto1.geometry.iloc[0]
    ponto2_m = gdf_ponto2.geometry.iloc[0]
    centro_m = gdf_centro.geometry.iloc[0]

    pontos_m = []
    distancias_m = np.linspace(-raio_m, raio_m, num_pontos)

    dx = ponto2_m.x - ponto1_m.x
    dy = ponto2_m.y - ponto1_m.y
    comprimento = np.sqrt(dx**2 + dy**2)
    dx_norm = dx / comprimento
    dy_norm = dy / comprimento

    for dist in distancias_m:
        x = centro_m.x + dist * dx_norm
        y = centro_m.y + dist * dy_norm
        pontos_m.append(Point(x, y))

    gdf_pontos = gpd.GeoDataFrame(geometry=pontos_m, crs="EPSG:32629").to_crs(epsg=4326)

    lats = np.array([p.y for p in gdf_pontos.geometry])
    lons = np.array([p.x for p in gdf_pontos.geometry])

    return lats, lons, distancias_m

def gerar_linhas_diametrais(lat, lon, raio_m):

    centro = Point(lon, lat)
    gdf_centro = gpd.GeoDataFrame(geometry=[centro], crs="EPSG:4326").to_crs(epsg=32629)
    centro_m = gdf_centro.geometry.iloc[0]

    linhas = []

    angulos = [0, 45, 90, 315]
    nomes = ["Sul-Norte", "Sudoeste-Nordeste", "Oeste-Leste", "Sudeste-Noroeste"]

    for i, ang_deg in enumerate(angulos):
        ang_rad = radians(ang_deg)

        dx = raio_m * sin(ang_rad)
        dy = raio_m * cos(ang_rad)

        ponto_inicio_m = Point(centro_m.x + dx, centro_m.y + dy)
        ponto_fim_m = Point(centro_m.x - dx, centro_m.y - dy)

        gdf_inicio = gpd.GeoDataFrame(geometry=[ponto_inicio_m], crs="EPSG:32629").to_crs(epsg=4326)
        gdf_fim = gpd.GeoDataFrame(geometry=[ponto_fim_m], crs="EPSG:32629").to_crs(epsg=4326)

        ponto_inicio = gdf_inicio.geometry.iloc[0]
        ponto_fim = gdf_fim.geometry.iloc[0]

        lat_inicio = ponto_inicio.y
        lon_inicio = ponto_inicio.x
        lat_fim = ponto_fim.y
        lon_fim = ponto_fim.x

        linhas.append((lat_inicio, lon_inicio, lat_fim, lon_fim, ang_deg, nomes[i]))

    return linhas

def analyze_height_profiles(lat, lon, raio_m, arquivo_glo30=None, z_ref=10.0, pasta_saida=None):

    if arquivo_glo30 is None:
        arquivo_glo30 = _DEM_DEFAULT
    print("=== INICIANDO ANÁLISE DE ELEVAÇÃO COM LINHAS DIAMETRAIS ===")
    print(f"Centro: {lat:.6f}, {lon:.6f}")
    print(f"Raio: {raio_m}m (Diâmetro: {2*raio_m}m)")
    print(f"Arquivo GLO-30: {arquivo_glo30}")

    if pasta_saida is None:
        pasta_saida = f"{lat}_{lon}"
    os.makedirs(pasta_saida, exist_ok=True)
    print(f"\nPasta de saída criada: {pasta_saida}")

    print("\n1. Carregando dados de elevação...")
    interpolador = criar_interpolador(lat, lon, raio_m, arquivo_glo30)

    # Altitude da torre (m acima do nivel do mar) = elevacao do DEM no ponto
    # exato da torre -- o ponto vermelho dos perfis.
    altitude_torre = float(obter_elevacao_interpolada(np.array([lat]), np.array([lon]), interpolador)[0])
    print(f"Altitude da torre (DEM): {altitude_torre:.2f} m")

    print("2. Gerando linhas diametrais...")
    linhas = gerar_linhas_diametrais(lat, lon, raio_m)

    print("3. Extraindo perfis de elevação e calculando modelo/Co por direção...")

    pontos_por_direcao = {}  # ang_deg (template: 0/45/90/135) -> 6 pontos do modelo pico/colina + co
    _ANG_TEMPLATE = {0: 0, 45: 45, 90: 90, 315: 135}

    for i, (lat_inicio, lon_inicio, lat_fim, lon_fim, ang_deg, nome_linha) in enumerate(linhas):
        lats, lons, distancias_m = gerar_pontos_linha_diametral(lat_inicio, lon_inicio, lat_fim, lon_fim, lat, lon, raio_m, num_pontos=200)

        dados_elev = obter_elevacao_interpolada(lats, lons, interpolador)

        print(f"\n=== Linha {i+1}: {nome_linha} ===")
        print(f"Ângulo de referência: {ang_deg:.1f}°")
        print(f"Elevação - Min: {np.min(dados_elev):.1f}m, Max: {np.max(dados_elev):.1f}m, Média: {np.mean(dados_elev):.1f}m")

        # Nome do ficheiro do perfil, na ordem esquerda→direita do gráfico
        if ang_deg == 0:
            nome_arquivo_formatado = "sul_norte"
        elif ang_deg == 45:
            nome_arquivo_formatado = "sudoeste_nordeste"
        elif ang_deg == 90:
            nome_arquivo_formatado = "oeste_leste"
        elif ang_deg == 315:
            nome_arquivo_formatado = "sudeste_noroeste"
        else:
            nome_arquivo_formatado = nome_linha.replace('-', '_').replace(' ', '_').lower()
        nome_arquivo = f"perfil_{i+1:02d}_{nome_arquivo_formatado}"

        _pontos_6 = gerar_tipo_sintetico(pasta_saida, nome_arquivo, dados_elev, distancias_m, z_ref=z_ref)
        pontos_por_direcao[_ANG_TEMPLATE.get(ang_deg, ang_deg)] = _pontos_6

    print(f"\n=== ANÁLISE CONCLUÍDA ===")

    return {
        'codigo_site': os.path.basename(os.path.normpath(pasta_saida)),
        'h_torre': z_ref,
        'altitude_torre': round(altitude_torre, 2),
        'longitude': lon,
        'latitude': lat,
        'direcoes': pontos_por_direcao,
    }

_DIRECOES_TEMPLATE = [0, 45, 90, 135]
_PONTOS_TEMPLATE    = ['x1', 'y1', 'x2', 'y2', 'x3', 'y3', 'x4', 'y4', 'x5', 'y5', 'x6', 'y6']

def gerar_output_geral_xlsx(caminho_xlsx, sites):
    """Gera o Excel de output geral (layout Output_Layout_Reconhecimento_Terreno.xlsx),
    uma linha por site, com os 6 pontos do modelo Pico/Colina em cada direção
    (0°, 45°, 90°, 135°)."""
    headers = ['Codigo SITE', 'h_torre', 'vb', 'Longitude', 'Latitude']
    for ang in _DIRECOES_TEMPLATE:
        headers.append(f'Direcao {ang}')
        for p in _PONTOS_TEMPLATE:
            headers.append(f'{p} (m)' if p in ('x1', 'y1') else p)
        headers += ['z0_esq', 'z_min_esq', 'z0_dir', 'zmin_dir']

    wb = Workbook()
    ws = wb.active
    ws.title = 'Sheet1'
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True)

    for site in sites:
        row = [site['codigo_site'], site['h_torre'], site.get('vb'), site['longitude'], site['latitude']]
        for ang in _DIRECOES_TEMPLATE:
            row.append('-')
            pontos = site['direcoes'].get(ang, {})
            for p in _PONTOS_TEMPLATE:
                row.append(pontos.get(p))
            row += [pontos.get('z0_esq'), pontos.get('z_min_esq'), pontos.get('z0_dir'), pontos.get('zmin_dir')]
        ws.append(row)

    for col_cells in ws.columns:
        largura = max((len(str(c.value)) for c in col_cells if c.value is not None), default=8)
        ws.column_dimensions[col_cells[0].column_letter].width = max(10, largura + 2)

    try:
        wb.save(caminho_xlsx)
        print(f"Output geral salvo: {caminho_xlsx}")
    except PermissionError:
        raise PermissionError(
            f"'{caminho_xlsx}' está aberto/bloqueado (provavelmente no Excel). "
            f"Feche o ficheiro e corra novamente — o output geral sobrescreve sempre o mesmo ficheiro."
        )

def calcular_co_orografia(tipo_terr, H, Lu, Ld, x_rel, z_ref=10.0):
    """
    Fator de orografia co(z) conforme EN 1991-1-4:2005+A1:2010, Anexo A.3.
    Devolve também todos os valores intermediários para geração de relatório.
    """
    inter = {}   # valores intermediários para o relatório

    if Lu <= 0 or H <= 0:
        return {'co': 1.0, 's': 0.0, 'phi': 0.0, 'Le': 0.0, 'u': 0.0,
                'nota': 'Dados insuficientes', 'valido': False, 'inter': inter}

    phi = H / Lu
    inter['phi'] = phi

    # Tabela A.2
    Le = Lu if phi < 0.3 else H / 0.3
    inter['Le_regra'] = 'Le = Lu (φ < 0,3)' if phi < 0.3 else 'Le = H/0,3 (φ ≥ 0,3)'
    inter['Le'] = Le

    u = z_ref / Le if Le > 0 else 0.0
    inter['u'] = u
    inter['x_rel'] = x_rel

    if phi < 0.05:
        return {'co': 1.0, 's': 0.0, 'phi': phi, 'Le': Le, 'u': u,
                'nota': 'φ<0,05 → co=1,0 (sem efeito)', 'valido': True, 'inter': inter}

    s = 0.0
    nota = 'fora do intervalo de aplicação → s=0'
    inter['A'] = inter['B'] = inter['C'] = None
    inter['formula_s'] = 'N/A'

    def _A(uu):
        return (0.1552*uu**4 - 0.8575*uu**3 + 1.8133*uu**2 - 1.9115*uu + 1.0124)

    def _B_upwind(uu):
        return 0.3542*uu**2 - 1.0577*uu + 2.6456

    if x_rel <= 0:
        # Barlavento — Exp. A.4–A.6
        if (x_rel / Lu) >= -1.5 and u <= 2.0:
            A = _A(u)
            B = _B_upwind(u)
            arg = B * x_rel / Le
            s = A * float(np.exp(arg))
            s = float(np.clip(s, 0.0, 1.0))
            inter.update({'A': A, 'B': B, 'arg_exp': arg,
                          'formula_s': f's = A·exp(B·x/Le) = {A:.4f}·exp({B:.4f}·{x_rel:.1f}/{Le:.1f})'})
            nota = 'barlavento (Exp. A.4–A.6)'

    elif tipo_terr == 'falesia':
        # Sotavento falésia — Exp. A.8–A.10
        x_Le = x_rel / Le
        if x_Le <= 3.5 and u <= 2.0:
            u_eff = max(0.1, u)
            v = float(np.log10(u_eff))
            A = _A(u)
            B = -1.0196*v**3 - 0.8910*v**2 + 0.5343*v - 0.1156
            C =  0.8030*v**3 + 0.4236*v**2 - 0.5738*v + 0.1606
            if x_Le < 0.1:
                s_01 = A * float(np.exp(B*0.1 + C*0.01))
                s = A + (s_01 - A) * (x_Le / 0.1)
                inter['formula_s'] = (f's = interpolação linear (0 ≤ x/Le={x_Le:.3f} < 0,1): '
                                      f's(0)={A:.4f} → s(0.1)={s_01:.4f}')
            else:
                arg = B*x_Le + C*x_Le**2
                s = A * float(np.exp(arg))
                inter['formula_s'] = (f's = A·exp(B·x/Le + C·(x/Le)²) = '
                                      f'{A:.4f}·exp({B:.4f}·{x_Le:.3f} + {C:.4f}·{x_Le:.3f}²)')
            s = float(np.clip(s, 0.0, 1.0))
            inter.update({'A': A, 'B': B, 'C': C, 'v': v, 'u_eff': u_eff})
            nota = 'sotavento falésia (Exp. A.8–A.10)'

    else:
        # Sotavento colina — Exp. A.11 (aprox. espelho)
        x_Ld = x_rel / Ld if Ld > 0 else 0.0
        if x_Ld <= 2.0 and u <= 2.0:
            A = _A(u)
            B = _B_upwind(u)
            arg = -B * x_rel / Le
            s = A * float(np.exp(arg))
            s = float(np.clip(s, 0.0, 1.0))
            inter.update({'A': A, 'B': B, 'arg_exp': arg,
                          'formula_s': (f's = A·exp(-B·x/Le) = '
                                        f'{A:.4f}·exp(-{B:.4f}·{x_rel:.1f}/{Le:.1f})')})
            nota = 'sotavento colina (Exp. A.11 aprox.)'

    if phi <= 0.3:
        co = 1.0 + 2.0 * s * phi
        inter['formula_co'] = f'co = 1 + 2·s·φ = 1 + 2·{s:.4f}·{phi:.4f}'
        inter['exp_co'] = 'A.2'
    else:
        co = 1.0 + 0.6 * s
        inter['formula_co'] = f'co = 1 + 0,6·s = 1 + 0,6·{s:.4f}'
        inter['exp_co'] = 'A.3'

    return {'co': co, 's': s, 'phi': phi, 'Le': Le, 'u': u,
            'nota': nota, 'valido': True, 'inter': inter}


def _modelo_5_segmentos(L, x1, x2, x3, x4, x5, x6, y_esq, y_pico, y_dir):
    """Modelo piecewise de 5 segmentos (pico/colina), igual à fórmula da coluna T
    (dados_perfis_elevacao.xlsx, ajustado com o Solver do Excel):
      [x1,x2) -> y_esq (constante)
      [x2,x3) -> reta entre (x2,y_esq) e (x3,y_pico)
      [x3,x4) -> y_pico (constante)
      [x4,x5) -> reta entre (x4,y_pico) e (x5,y_dir)
      [x5,x6] -> y_dir (constante)
    """
    m1 = (y_pico - y_esq) / (x3 - x2)
    b1 = y_pico - m1 * x3
    m2 = (y_dir - y_pico) / (x5 - x4)
    b2 = y_dir - m2 * x5
    return np.where(L < x2, y_esq,
           np.where(L < x3, m1 * L + b1,
           np.where(L < x4, y_pico,
           np.where(L < x5, m2 * L + b2, y_dir))))


def _fracoes_para_pontos(params, x1, x6):
    """Converte [f2,f3,f4,f5,y_esq,y_pico,y_dir] (f em [0,1], fração do espaço
    restante até x6) em x2,x3,x4,x5 absolutos, garantindo sempre
    x1 <= x2 <= x3 <= x4 <= x5 <= x6 (evita x5 "escapar" para além de x6)."""
    f2, f3, f4, f5, y_esq, y_pico, y_dir = params
    x2 = x1 + f2 * (x6 - x1)
    x3 = x2 + f3 * (x6 - x2)
    x4 = x3 + f4 * (x6 - x3)
    x5 = x4 + f5 * (x6 - x4)
    return x2, x3, x4, x5, y_esq, y_pico, y_dir


def _residuos_5_segmentos(params, xr, yr, x1, x6):
    x2, x3, x4, x5, y_esq, y_pico, y_dir = _fracoes_para_pontos(params, x1, x6)
    modelo = _modelo_5_segmentos(xr, x1, x2, x3, x4, x5, x6, y_esq, y_pico, y_dir)
    return modelo - yr


def gerar_tipo_sintetico(pasta_saida, nome_arquivo, dados_elevacao, distancias_m, z_ref=10.0):
    """Ajusta dois modelos ao perfil real e fica com o de menor SSE (soma dos
    quadrados dos resíduos):
      - Pico/Colina (5 segmentos): ajustado por otimização numérica
        (scipy.optimize.least_squares), equivalente ao Solver do Excel usado em
        dados_perfis_elevacao.xlsx (coluna T);
      - Ladeira (reta única): regressão linear (mínimos quadrados, solução exata).
    Calcula a orografia EN 1991-1-4 Anexo A.3 com o modelo vencedor e gera o
    gráfico do perfil (vencedor a azul, perdedor a laranja)."""

    distancias_inv_full = -distancias_m

    _sort_r  = np.argsort(distancias_inv_full)
    _xr      = distancias_inv_full[_sort_r]
    _yr      = dados_elevacao[_sort_r].astype(float)
    _ww_g    = max(3, len(_xr) // 20)
    _yr_sm_g = np.convolve(_yr, np.ones(_ww_g) / _ww_g, mode='same')

    # ── Modelo Pico/Colina: 5 segmentos piecewise ────────────────────────
    # O modelo pode representar tanto uma colina (cume acima da base) como um
    # vale (cume abaixo da base) — por isso testamos os dois candidatos de
    # "cume" (argmax e argmin do perfil suavizado) e refinamos cada um por
    # otimização numérica (least_squares), ficando com o de menor SSE. Isto
    # evita ficar preso num mínimo local errado quando o relevo é um vale.
    _n10_w = max(1, len(_xr) // 10)
    _y_base_esq = float(np.mean(_yr[:_n10_w]))
    _y_base_dir = float(np.mean(_yr[-_n10_w:]))
    _x1_fix = float(_xr[0])
    _x6_fix = float(_xr[-1])
    _brd_e  = max(1, len(_yr_sm_g) // 20)

    def _heuristica_a_partir_do_indice(pk_idx):
        """Estima x2,x3(=x4),x5,y1(=y2),y3(=y4),y5(=y6) a partir de um candidato
        a posição de cume/vale (pk_idx), para servir de ponto de partida (x0)."""
        pw1, pw5 = _y_base_esq, _y_base_dir
        pwx1, pwx6 = _x1_fix, _x6_fix
        pwx3 = pwx4 = float(_xr[pk_idx])
        pw3  = float(_yr[pk_idx])

        # Pé esquerdo
        Hw_l  = max(0.1, abs(pw3 - pw1))
        thr_l = max(0.5, 0.10 * Hw_l)
        lmask = (_xr < pwx3) & (_yr <= pw1 + thr_l)
        pwx2  = float(_xr[lmask][-1]) if lmask.any() else pwx1
        if pwx2 >= 0.0:
            lm2 = (_xr < 0.0) & (_yr <= pw1 + thr_l)
            if lm2.any():
                pwx2 = float(_xr[lm2][-1])
            else:
                lm2b = (_xr < 0.0) & (_yr <= pw1 + 0.50 * Hw_l)
                pwx2 = float(_xr[lm2b][-1]) if lm2b.any() else 0.0
            pwx1 = min(_x1_fix, pwx2)
        if pwx2 >= pwx3:
            pw1 = pw3;  pwx2 = pwx3;  pwx1 = pwx3

        # Pé direito
        Hw_r  = max(0.1, abs(pw3 - pw5))
        thr_r = max(0.5, 0.10 * Hw_r)
        rmask = (_xr > pwx4) & (_yr <= pw5 + thr_r)
        pwx5  = float(_xr[rmask][0]) if rmask.any() else pwx6
        if pwx5 <= 0.0:
            rm2 = (_xr > 0.0) & (_yr <= pw5 + thr_r)
            if rm2.any():
                pwx5 = float(_xr[rm2][0])
            else:
                rm2b = (_xr > 0.0) & (_yr <= pw5 + 0.50 * Hw_r)
                pwx5 = float(_xr[rm2b][0]) if rm2b.any() else 0.0
            pwx6 = max(_x6_fix, pwx5)
        if pwx5 <= pwx4:
            pw5 = pw3;  pwx5 = pwx4;  pwx6 = pwx4

        # Converter x2,x3,x4,x5 em fracões do espaço restante até x6
        # (garante x1<=x2<=x3<=x4<=x5<=x6 seja qual for o resultado da otimização)
        _eps = 1e-3
        w1 = max(1e-6, _x6_fix - pwx1)
        f2 = float(np.clip((pwx2 - pwx1) / w1, _eps, 1 - _eps))
        w2 = max(1e-6, _x6_fix - pwx2)
        f3 = float(np.clip((pwx3 - pwx2) / w2, _eps, 1 - _eps))
        w3 = max(1e-6, _x6_fix - pwx3)
        f4 = float(np.clip((pwx4 - pwx3) / w3, _eps, 1 - _eps))
        w4 = max(1e-6, _x6_fix - pwx4)
        f5 = float(np.clip((pwx5 - pwx4) / w4, _eps, 1 - _eps))
        return [f2, f3, f4, f5, pw1, pw3, pw5]

    def _ajustar(pk_idx):
        x0 = _heuristica_a_partir_do_indice(pk_idx)
        resultado = least_squares(
            _residuos_5_segmentos, x0=x0, args=(_xr, _yr, _x1_fix, _x6_fix),
            bounds=(
                [1e-3, 1e-3, 1e-3, 1e-3, -np.inf, -np.inf, -np.inf],
                [1 - 1e-3, 1 - 1e-3, 1 - 1e-3, 1 - 1e-3, np.inf, np.inf, np.inf],
            ),
        )
        sse = float(np.sum(resultado.fun ** 2))
        return resultado, sse

    if len(_yr_sm_g) > 2 * _brd_e:
        _idx_max = _brd_e + int(np.argmax(_yr_sm_g[_brd_e:-_brd_e]))
        _idx_min = _brd_e + int(np.argmin(_yr_sm_g[_brd_e:-_brd_e]))
    else:
        _idx_max = int(np.argmax(_yr_sm_g))
        _idx_min = int(np.argmin(_yr_sm_g))

    _resultado_max, _sse_max = _ajustar(_idx_max)
    _resultado_min, _sse_min = _ajustar(_idx_min)
    _resultado_opt = _resultado_max if _sse_max <= _sse_min else _resultado_min

    _pwx2, _pwx3, _pwx4, _pwx5, _pw1, _pw3, _pw5 = _fracoes_para_pontos(
        _resultado_opt.x, _x1_fix, _x6_fix
    )
    _pwx1 = _x1_fix
    _pwx6 = _x6_fix
    _sse_pico = min(_sse_max, _sse_min)

    # ── Ladeira: regressão linear (mínimos quadrados — solução ótima exata) ──
    _wm_l, _wb_l = np.polyfit(_xr, _yr, 1)
    _yp_lad = _wm_l * _xr + _wb_l
    _sse_lad = float(np.sum((_yr - _yp_lad) ** 2))

    # ── Escolha: menor SSE define o modelo (pico/colina vs. ladeira) ─────
    _tipo_word = 'ladeira' if _sse_lad <= _sse_pico else 'pico'
    if _tipo_word == 'ladeira':
        _wy1 = float(np.mean(_yr[:_n10_w]))
        _wy2 = float(np.mean(_yr[-_n10_w:]))
        if _wy2 >= _wy1:   # sobe esq->dir: cume = extremo dir
            real_x_cb = float(_xr[0]);   real_y_cb = _wy1
            real_x_ct = float(_xr[-1]);  real_y_ct = _wy2
            real_x_cume_esq = real_x_cume_dir = float(_xr[-1])
            real_y_cume_esq = real_y_cume_dir = _wy2
        else:              # desce esq->dir: cume = extremo esq
            real_x_cb = float(_xr[-1]);  real_y_cb = _wy2
            real_x_ct = float(_xr[0]);   real_y_ct = _wy1
            real_x_cume_esq = real_x_cume_dir = float(_xr[0])
            real_y_cume_esq = real_y_cume_dir = _wy1
    else:
        real_x_cb = _pwx2;  real_y_cb = _pw1
        real_x_ct = _pwx5;  real_y_ct = _pw5
        real_x_cume_esq = _pwx3;  real_y_cume_esq = _pw3
        real_x_cume_dir = _pwx4;  real_y_cume_dir = _pw3

    # ── Coeficiente de Orografia — EN 1991-1-4:2005 Anexo A.3 ───────────
    real_x_torre = 0.0
    _tipo_terr = 'colina' if _tipo_word == 'pico' else 'falesia'
    _H_oreg = float(abs(real_y_cume_esq - real_y_cb))
    _z_ref  = float(z_ref)

    # Vento da esquerda (→): encosta esq = barlavento, encosta dir = sotavento
    _Lu_ve  = max(1.0, real_x_cume_esq - real_x_cb)
    _Ld_ve  = max(1.0, real_x_ct - real_x_cume_dir)
    _x_ve   = real_x_torre - real_x_cume_esq
    _co_ve  = calcular_co_orografia(_tipo_terr, _H_oreg, _Lu_ve, _Ld_ve, _x_ve, _z_ref)

    # Vento da direita (←): encosta dir = barlavento, encosta esq = sotavento
    _Lu_vd  = max(1.0, real_x_ct - real_x_cume_dir)
    _Ld_vd  = max(1.0, real_x_cume_esq - real_x_cb)
    _x_vd   = real_x_cume_dir - real_x_torre
    _co_vd  = calcular_co_orografia(_tipo_terr, _H_oreg, _Lu_vd, _Ld_vd, _x_vd, _z_ref)

    # ── Perfil: terreno real + os 2 modelos (vencedor e perdedor) ──
    _elev_min   = float(np.min(dados_elevacao))
    _elev_max   = float(np.max(dados_elevacao))
    _elev_range = _elev_max - _elev_min
    _piso       = _elev_min - _elev_range * 0.15

    # Eixo de altura mostra a elevação REAL do terreno (metros acima do
    # nível do mar -- a mesma usada no cálculo do co); o preenchimento
    # castanho só desce até um piso perto do mínimo real (não até 0), para
    # o desenho não ficar achatado no topo do gráfico.
    fig, ax = plt.subplots(figsize=(16, 8))
    ax.fill_between(distancias_inv_full, dados_elevacao, _piso,
                     color='saddlebrown', alpha=0.65)
    ax.plot(distancias_inv_full, dados_elevacao, linewidth=2.5, color='black')

    _pico_vence = (_tipo_word == 'pico')

    # So o modelo VENCEDOR (menor SSE, o que e realmente usado no calculo do
    # co) e desenhado -- sempre a azul. O modelo perdedor deixou de ser
    # desenhado (era a laranja, so para comparacao visual).
    if _pico_vence:
        # Pico/Colina (5 segmentos piecewise, ajustado por least_squares)
        _dp_px = [_pwx1, _pwx2, _pwx3, _pwx4, _pwx5, _pwx6]
        _dp_py = [_pw1, _pw1, _pw3, _pw3, _pw5, _pw5]
        ax.plot(_dp_px, _dp_py, color='deepskyblue', linewidth=2.2,
                linestyle='--', alpha=0.90, zorder=10)
    else:
        # Ladeira (regressão linear)
        _dl_x = np.linspace(float(_xr[0]), float(_xr[-1]), 300)
        _dl_y = _wm_l * _dl_x + _wb_l
        ax.plot(_dl_x, _dl_y, color='deepskyblue', linewidth=2.2,
                linestyle='--', alpha=0.90, zorder=10)

    # Torre (vermelho ●) — sempre em x=0
    _torre_elev = float(np.interp(0.0, _xr, _yr))
    ax.scatter([0.0], [_torre_elev], color='red', marker='o', s=220,
               edgecolors='darkred', linewidths=2.2, zorder=13)

    _plot_x0, _plot_x1 = float(_xr[0]), float(_xr[-1])
    ax.set_xlim(_plot_x0, _plot_x1)
    ax.set_ylim(_piso, _elev_max + _elev_range * 0.15)

    # ── Eixo de comprimento (em baixo): -X … 0 (centro) … X metros ────────
    _x_abs = max(abs(_plot_x0), abs(_plot_x1))
    _x_ticks = np.linspace(-_x_abs, _x_abs, 7)
    ax.set_xticks(_x_ticks)
    ax.set_xticklabels([f'{v:.0f}' for v in _x_ticks], fontsize=9)

    # Linhas verticais pontilhadas nos ticks do eixo X (grid vertical)
    for _xt in _x_ticks:
        ax.axvline(x=_xt, color='gray', linewidth=1.0, linestyle=':', alpha=0.6, zorder=2)

    # ── Eixo de altura (à esquerda): 0 no início da imagem até ao topo ────
    ax.yaxis.tick_left()
    ax.yaxis.set_label_position('left')
    ax.set_ylabel('Height (m)', fontsize=10, fontweight='bold')

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    caminho_pts = os.path.join(pasta_saida, f'{nome_arquivo}_pontos_inclinacao.png')
    plt.savefig(caminho_pts, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    print(f"    Perfil com pontos salvo: {caminho_pts}")

    if _tipo_word == 'ladeira':
        # Ladeira: só ponto inicial (1) e ponto final (2) da reta ajustada; os restantes ficam a 0
        return {
            'x1': float(_xr[0]), 'y1': float(_wm_l * _xr[0] + _wb_l),
            'x2': float(_xr[-1]), 'y2': float(_wm_l * _xr[-1] + _wb_l),
            'x3': 0, 'y3': 0, 'x4': 0, 'y4': 0, 'x5': 0, 'y5': 0, 'x6': 0, 'y6': 0,
            'co_esq': round(_co_ve['co'], 4), 'co_dir': round(_co_vd['co'], 4),
        }

    # 6 pontos do modelo Pico/Colina (ajustado por least_squares, caso vença a SSE) + co (orografia)
    return {
        'x1': _pwx1, 'y1': _pw1, 'x2': _pwx2, 'y2': _pw1,
        'x3': _pwx3, 'y3': _pw3, 'x4': _pwx4, 'y4': _pw3,
        'x5': _pwx5, 'y5': _pw5, 'x6': _pwx6, 'y6': _pw5,
        'co_esq': round(_co_ve['co'], 4), 'co_dir': round(_co_vd['co'], 4),
    }

def _normalizar_direcoes(resultado_site):
    """JSON transforma as chaves inteiras (0/45/90/135) de 'direcoes' em str.
    Repoe-as como int para o resto do pipeline (analisar_site / xlsx)."""
    d = resultado_site.get("direcoes") or {}
    resultado_site["direcoes"] = {int(k): v for k, v in d.items()}
    return resultado_site


def _cli(argv):
    """
    Dois modos:

    1) Analise de perfil de terreno (etapa 3 do pipeline):
         LandHeightDataCollector "ID,LAT,LON,ALTURA,RAIO" --outdir <dir> [--raster <tif>]
       -> gera os perfis em  <dir>/<ID>/  e escreve  <dir>/<ID>/resultado_site.json

    2) Geracao do Excel de output geral (a partir do resultado_site.json ja
       consolidado pelo run_site, com z0/zmin por direcao):
         LandHeightDataCollector --xlsx <resultado_site.json> <saida.xlsx>
    """
    import json

    if argv and argv[0] == "--altitude":
        # LandHeightDataCollector --altitude "ID,LAT,LON" --outdir <dir>
        # -> escreve <dir>/<ID>/altitude_torre.json  {"altitude_torre": <m>}
        outdir = os.path.join(os.getcwd(), "resultados")
        alvo = None
        i = 1
        while i < len(argv):
            if argv[i] == "--outdir" and i + 1 < len(argv):
                outdir = argv[i + 1]; i += 2
            else:
                alvo = argv[i]; i += 1
        if not alvo or "," not in alvo:
            raise SystemExit('Uso: LandHeightDataCollector --altitude "ID,LAT,LON" --outdir <dir>')
        p = [x.strip() for x in alvo.split(",")]
        id_torre, lat, lon = p[0], float(p[1]), float(p[2])
        altitude = calcular_altitude_torre(lat, lon)
        pasta = os.path.join(outdir, id_torre)
        os.makedirs(pasta, exist_ok=True)
        destino = os.path.join(pasta, "altitude_torre.json")
        with open(destino, "w", encoding="utf-8") as f:
            json.dump({"altitude_torre": round(altitude, 2)}, f)
        print(f"Altitude da torre (DEM): {altitude:.2f} m")
        return

    if argv and argv[0] == "--xlsx":
        if len(argv) < 3:
            raise SystemExit('Uso: LandHeightDataCollector --xlsx <resultado_site.json> <saida.xlsx>')
        with open(argv[1], "r", encoding="utf-8") as f:
            rs = _normalizar_direcoes(json.load(f))
        gerar_output_geral_xlsx(argv[2], [rs])
        return

    outdir = os.path.join(os.getcwd(), "resultados")
    raster = None
    rest = []
    i = 0
    while i < len(argv):
        if argv[i] == "--outdir" and i + 1 < len(argv):
            outdir = argv[i + 1]; i += 2
        elif argv[i] == "--raster" and i + 1 < len(argv):
            raster = argv[i + 1]; i += 2
        else:
            rest.append(argv[i]); i += 1

    if not rest or "," not in rest[0]:
        raise SystemExit('Uso: LandHeightDataCollector "ID,LAT,LON,ALTURA,RAIO" --outdir <dir> [--raster <tif>]')

    p = [x.strip() for x in rest[0].split(",")]
    id_torre = p[0]
    lat = float(p[1]); lon = float(p[2])
    altura = float(p[3]) if len(p) > 3 and p[3] else 10.0
    raio_m = float(p[4]) if len(p) > 4 and p[4] else 1500.0

    pasta_saida = os.path.join(outdir, id_torre)
    os.makedirs(pasta_saida, exist_ok=True)

    if raster is None:
        raster = escolher_raster(lat, lon, raio_m)
    print(f"Raster de elevacao: {os.path.basename(raster)}")

    resultado_site = analyze_height_profiles(
        lat, lon, raio_m, arquivo_glo30=raster, z_ref=altura, pasta_saida=pasta_saida)
    resultado_site["codigo_site"] = id_torre

    destino = os.path.join(pasta_saida, "resultado_site.json")
    with open(destino, "w", encoding="utf-8") as f:
        json.dump(resultado_site, f, ensure_ascii=False, indent=2)
    print(f"resultado_site.json escrito: {destino}")


if __name__ == "__main__":
    _cli(sys.argv[1:])
