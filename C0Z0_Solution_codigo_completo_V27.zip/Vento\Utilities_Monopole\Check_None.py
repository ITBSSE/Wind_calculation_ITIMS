def check_not_none(values, names):
    #Validar Se as variaveis obrigatorias não são none
    for value, name in zip(values, names):
        if value is None:
            raise ValueError(f"Variável '{name}' é None e é obrigatória.")