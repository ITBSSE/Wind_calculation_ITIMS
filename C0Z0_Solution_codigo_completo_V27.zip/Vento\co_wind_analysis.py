r"""
Coeficiente orografico (co), pressao de vento e geracao dos ficheiros
wind_config -- adaptado de "Analise co Victor" (analise_terreno.py +
gerar_wind_config.py) para rodar em memoria sobre o resultado que o
run_site.py ja calculou, sem precisar de um CSV intermedio.

A logica de calculo (classificacao do relevo, co, pressao de vento, formato
dos .txt) e uma copia fiel dos scripts originais -- so a forma de obter os
dados de entrada muda (dict em memoria em vez de linha de CSV).
"""

import csv
import json
import math
import os
import sys

import numpy as np

from Wind.Velocidade_Media import Velocidade_media
from Wind.Iv_Calc import Iv_calc

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WIND_CONFIG_DIR = os.path.join(BASE_DIR, "wind_config")

# mapas_circulares.py vive na raiz da solution (ao lado do config.py) --
# e a UNICA funcao que desenha mapas circulares (fatias); qp_pressure.jpg
# e co_map.jpg passam por ela para saírem sempre com o mesmo layout/escala
# dos outros mapas circulares (ex.: final_z0_map_by_sector.jpg).
_RAIZ = os.path.dirname(BASE_DIR)
if _RAIZ not in sys.path:
    sys.path.insert(0, _RAIZ)
from mapas_circulares import desenhar_mapa_circular

_DIRECOES_TEMPLATE = [0, 45, 90, 135]
_PONTOS_TEMPLATE = ['x1', 'y1', 'x2', 'y2', 'x3', 'y3', 'x4', 'y4', 'x5', 'y5', 'x6', 'y6']

# Cada "Direcao" do perfil tem lado ESQ e lado DIR -> par de rumos cardeais.
_DIR_ESQ_DIR = {0: ('S', 'N'), 45: ('SW', 'NE'), 90: ('W', 'E'), 135: ('SE', 'NW')}
_COMPASS_ORDER = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
RAIO_MAPA_PRESSAO_M = 1000

# Colunas dos CSV de resumo -- formato identico ao analise_terreno.py do v2.
CSV_HEADER = [
    "codigo", "longitude", "latitude", "direcao", "lado",
    "wind_pressure_Pa", "co", "Tipo", "Alt_colina", "Lu", "Ld", "Xtorre",
    "h_torre", "vb", "z0", "zmin", "cdir", "pais", "colina_cadeia",
]


# ── Pressao de vento (copia de analise_terreno.py, com Franca/Espanha) ─────
# Pressure_wind_Portugal e generica por dentro: so o ramo "Portugal-RSA"
# (formula legada, nao-Eurocodigo) e realmente especifico de Portugal. O
# ramo normal so repassa Pais para Velocidade_media/Iv_calc, que ja sabem
# calcular para France/Spain (alem de Portugal e Italy).
def Pressure_wind(Pais, h_vector=None, vb=None, z0=None, zmin=None,
                   Alt=None, rho_ar=None, c0=None):
    if Pais in ["Portugal", "Portugal-RSA", "France", "Spain"]:
        return Pressure_wind_Portugal(h_vector, vb, z0, zmin, Alt, Pais, rho_ar, c0)


def Pressure_wind_Portugal(h_vector, vb, z0, zmin, Alt, Pais, rho_ar, c0):
    Wind_Pressure = np.zeros(len(h_vector))
    vm = Velocidade_media(h_vector, vb, z0, zmin, Pais, c0)
    if Pais != "Portugal-RSA":
        IV = Iv_calc(h_vector, z0, zmin, Alt, Pais, c0)
        Wind_Pressure = (1 + 7 * IV) * 0.5 * rho_ar * vm ** 2
    else:
        if vb == 30:
            vraj = (vm / 1.1 + 14) * 1.1
        else:
            vraj = vm + 14
        Wind_Pressure = 0.613 * vraj ** 2
    return Wind_Pressure


def inverter_perfil(x, y):
    """
    Inverte a ordem do perfil para a leitura na direcao oposta (DIR).
    Quando so existem 2 pontos reais (P1, P2) e o resto do perfil esta a
    zero, troca apenas esses dois pontos -- mantendo-os nas posicoes 1/2 --
    em vez de fazer o reverse total do array de 6 posicoes.
    """
    so_dois_pontos = (
        x[2] == 0 and y[2] == 0 and x[3] == 0 and y[3] == 0 and
        x[4] == 0 and y[4] == 0 and x[5] == 0 and y[5] == 0
    )
    if so_dois_pontos:
        x_inv = [-x[1], -x[0], 0, 0, 0, 0]
        y_inv = [y[1], y[0], 0, 0, 0, 0]
    else:
        x_inv = [-v if v is not None else None for v in x[::-1]]
        y_inv = y[::-1]
    return x_inv, y_inv


# ── Analise do perfil de terreno (copia fiel de analise_terreno.py) ────────
def analise_perfil(x, y, z0, zmin, h_torre, vb, cdir=1.0, pais="Portugal",
                   colina_cadeia="No", ignorar_orografia=False):
    """
    Recebe o perfil de terreno (listas x, y com 6 pontos), os parametros de
    rugosidade (z0, zmin), as caracteristicas da torre (h_torre, vb), o
    coeficiente direcional cdir, o pais usado no calculo da pressao de vento
    e (para Franca) se a colina isolada faz parte de uma cadeia
    (colina_cadeia = "Yes"/"No").
    Se ignorar_orografia=True (botao Orografia), salta toda a classificacao
    do relevo: co = 1, Tipo = "Zona Plana", Lu = Ld = Alt_colina = Xtorre = 0.
    Devolve dict com: wind_pressure, co, Lu, Ld, Tipo, Alt_colina, Xtorre.
    """
    co = 1
    Tipo = "Zona Plana"
    Lu = 0
    Ld = 0
    Alt_colina = 0
    Xtorre = 0
    phi = 0.0

    if ignorar_orografia:
        pass  # co=1 / terreno plano -- sem analise de perfil
    elif x[2] == 0 and y[2] == 0 and x[3] == 0 and y[3] == 0 and x[4] == 0 and y[4] == 0 and x[5] == 0 and y[5] == 0:
        if y[1] >= y[0]:  # Colina - Subida com topo no ponto 2
            Lu = x[1] - x[0]
            H = y[1] - y[0]
            Xtorre = -x[1]
            phi = H / Lu if Lu != 0 else 0
            if phi >= 0.05:
                Le = Lu if phi < 0.3 else H / 0.3
                if Xtorre / Lu >= -1.5 and Xtorre / Lu < 0 and h_torre / Le >= 0 and h_torre / Le <= 2.0:
                    A = 0.1552 * (h_torre / Le) ** 4 - 0.8575 * (h_torre / Le) ** 3 + 1.8133 * (h_torre / Le) ** 2 - 1.9115 * (h_torre / Le) + 1.0124
                    B = 0.3542 * (h_torre / Le) ** 2 - 1.0577 * (h_torre / Le) + 2.6456
                    s = A * np.exp(B * Xtorre / Lu)
                else:
                    s = 0
                co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
            Tipo = "Colina isolada"
            Alt_colina = H
            Ld = 0

        else:  # Colina - Descida com topo no ponto 1
            Ld = x[1] - x[0]
            H = y[0] - y[1]
            Xtorre = -x[1]
            phi = H / Ld if Ld != 0 else 0
            if phi >= 0.05:
                Le = Ld if phi < 0.3 else H / 0.3
                if Xtorre / Ld >= 0 and Xtorre / Ld <= 2.0 and h_torre / Le >= 0 and h_torre / Le < 2.0:
                    A = 0.1552 * (h_torre / Le) ** 4 - 0.8575 * (h_torre / Le) ** 3 + 1.8133 * (h_torre / Le) ** 2 - 1.9115 * (h_torre / Le) + 1.0124
                    B = -0.3056 * (h_torre / Le) ** 2 + 1.0212 * (h_torre / Le) - 1.7637
                    s = A * np.exp(B * Xtorre / Ld)
                else:
                    s = 0
                co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
            Tipo = "Colina isolada"
            Alt_colina = H
            Lu = Ld  # simula descida

    else:
        if y[2] >= y[1] and y[2] >= y[4]:
            if x[1] > 0 or x[4] < 0:
                co = 1
                Tipo = "Zona Plana"

            elif x[1] < 0 and x[2] > 0:  # Subida com torre entre 2 e 3
                Lu = x[2] - x[1]
                H = y[2] - y[1]
                Xtorre = -x[2]
                phi = H / Lu if Lu != 0 else 0
                if phi >= 0.05:
                    Le = Lu if phi < 0.3 else H / 0.3
                    if Xtorre / Lu >= -1.5 and Xtorre / Lu < 0 and h_torre / Le >= 0 and h_torre / Le <= 2.0:
                        A = 0.1552 * (h_torre / Le) ** 4 - 0.8575 * (h_torre / Le) ** 3 + 1.8133 * (h_torre / Le) ** 2 - 1.9115 * (h_torre / Le) + 1.0124
                        B = 0.3542 * (h_torre / Le) ** 2 - 1.0577 * (h_torre / Le) + 2.6456
                        s = A * np.exp(B * Xtorre / Lu)
                    else:
                        s = 0
                    co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                Tipo = "Colina isolada"
                Alt_colina = H
                Ld = 0

            elif x[2] < 0 and x[3] > 0:  # Falesia
                Lu = x[2] - x[1]
                H = y[2] - y[1]
                Xtorre = -x[2]
                phi = H / Lu if Lu != 0 else 0
                if phi >= 0.05:
                    Le = Lu if phi < 0.3 else H / 0.3
                    ratio = h_torre / Le
                    if ratio < 0.1:
                        ratio = 0.1
                    if Xtorre / Le >= 0.1 and Xtorre / Le <= 3.5 and ratio <= 2.0:
                        A = -1.342 * (np.log10(ratio)) ** 3 - 0.8222 * (np.log10(ratio)) ** 2 + 0.4609 * np.log10(ratio) - 0.0791
                        B = -1.0196 * (np.log10(ratio)) ** 3 - 0.8910 * (np.log10(ratio)) ** 2 + 0.5343 * np.log10(ratio) - 0.1156
                        C = 0.8030 * (np.log10(ratio)) ** 3 + 0.4236 * (np.log10(ratio)) ** 2 - 0.5738 * np.log10(ratio) + 0.1606
                        s = A * (np.log10(Xtorre / Le)) ** 2 + B * np.log10(Xtorre / Le) + C
                    elif Xtorre / Le < 0.1 and ratio < 2.0:
                        saux1 = 0.1552 * (ratio) ** 4 - 0.8575 * (ratio) ** 3 + 1.8133 * (ratio) ** 2 - 1.9115 * (ratio) + 1.0124
                        A = -1.342 * (np.log10(ratio)) ** 3 - 0.8222 * (np.log10(ratio)) ** 2 + 0.4609 * np.log10(ratio) - 0.0791
                        B = -1.0196 * (np.log10(ratio)) ** 3 - 0.8910 * (np.log10(ratio)) ** 2 + 0.5343 * np.log10(ratio) - 0.1156
                        C = 0.8030 * (np.log10(ratio)) ** 3 + 0.4236 * (np.log10(ratio)) ** 2 - 0.5738 * np.log10(ratio) + 0.1606
                        saux2 = A * (np.log10(Xtorre / Le)) ** 2 + B * np.log10(Xtorre / Le) + C
                        s = saux2 + (Xtorre / Le - 0.1) * (saux1 - saux2) / (0 - 0.1)
                    else:
                        s = 0
                    co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                Tipo = "Falésia e escarpas"
                Alt_colina = H
                Ld = 0

            elif x[3] < 0 and x[4] > 0:  # Descida entre 4 e 5
                Lu = x[2] - x[1]
                Ld = x[4] - x[3]
                H = y[2] - y[1]
                Lplano = x[3] - x[2]
                Lanalise = x[5] - x[0]
                Xtorre = -x[3]
                if Lplano >= 0.5 * Lanalise:
                    co = 1
                    Tipo = "Planalto"
                else:
                    phi = H / Lu if Lu != 0 else 0
                    if phi >= 0.05:
                        Le = Lu if phi < 0.3 else H / 0.3
                        if Xtorre / Ld >= 0 and Xtorre / Ld <= 2.0 and h_torre / Le >= 0 and h_torre / Le < 2.0:
                            A = 0.1552 * (h_torre / Le) ** 4 - 0.8575 * (h_torre / Le) ** 3 + 1.8133 * (h_torre / Le) ** 2 - 1.9115 * (h_torre / Le) + 1.0124
                            B = -0.3056 * (h_torre / Le) ** 2 + 1.0212 * (h_torre / Le) - 1.7637
                            s = A * np.exp(B * Xtorre / Ld)
                        else:
                            s = 0
                        co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                    Tipo = "Colina isolada"
                    Alt_colina = H

        elif y[2] < y[1] and y[2] < y[4]:  # especie de vale
            if x[1] >= 0 or (x[3] <= 0 and x[4] >= 0):
                co = 1
                Tipo = "Zona Plana"

            elif x[1] < 0 and x[2] >= 0:
                Ld = x[2] - x[1]
                H = y[1] - y[2]
                Lplano = x[1] - x[0]
                Lanalise = x[5] - x[0]
                Xtorre = -x[1]
                if Lplano >= 0.5 * Lanalise:
                    co = 1
                    Tipo = "Planalto"
                else:
                    phi = H / Ld if Ld != 0 else 0
                    if phi >= 0.05:
                        Le = Ld if phi < 0.3 else H / 0.3
                        if Xtorre / Ld >= 0 and Xtorre / Ld <= 2.0 and h_torre / Le >= 0 and h_torre / Le < 2.0:
                            A = 0.1552 * (h_torre / Le) ** 4 - 0.8575 * (h_torre / Le) ** 3 + 1.8133 * (h_torre / Le) ** 2 - 1.9115 * (h_torre / Le) + 1.0124
                            B = -0.3056 * (h_torre / Le) ** 2 + 1.0212 * (h_torre / Le) - 1.7637
                            s = A * np.exp(B * Xtorre / Ld)
                        else:
                            s = 0
                        co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                    Tipo = "Colina isolada"
                    Alt_colina = H
                    Lu = Ld
            elif x[3] < 0 and x[4] >= 0:  # Colina Subida
                Lu = x[4] - x[3]
                H = y[4] - y[3]
                Xtorre = -x[4]
                phi = H / Lu if Lu != 0 else 0
                if phi >= 0.05:
                    Le = Lu if phi < 0.3 else H / 0.3
                    if Xtorre / Lu >= -1.5 and Xtorre / Lu < 0 and h_torre / Le >= 0 and h_torre / Le <= 2.0:
                        A = 0.1552 * (h_torre / Le) ** 4 - 0.8575 * (h_torre / Le) ** 3 + 1.8133 * (h_torre / Le) ** 2 - 1.9115 * (h_torre / Le) + 1.0124
                        B = 0.3542 * (h_torre / Le) ** 2 - 1.0577 * (h_torre / Le) + 2.6456
                        s = A * np.exp(B * Xtorre / Lu)
                    else:
                        s = 0
                    co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                Tipo = "Colina isolada"
                Alt_colina = H
                Ld = 0

            elif x[4] < 0 and x[5] <= 0:  # Falesia
                Lu = x[4] - x[3]
                H = y[4] - y[3]
                Xtorre = -x[4]
                phi = H / Lu if Lu != 0 else 0
                if phi >= 0.05:
                    Le = Lu if phi < 0.3 else H / 0.3
                    ratio = h_torre / Le
                    if ratio < 0.1:
                        ratio = 0.1
                    if Xtorre / Le >= 0.1 and Xtorre / Le <= 3.5 and ratio <= 2.0:
                        A = -1.342 * (np.log10(ratio)) ** 3 - 0.8222 * (np.log10(ratio)) ** 2 + 0.4609 * np.log10(ratio) - 0.0791
                        B = -1.0196 * (np.log10(ratio)) ** 3 - 0.8910 * (np.log10(ratio)) ** 2 + 0.5343 * np.log10(ratio) - 0.1156
                        C = 0.8030 * (np.log10(ratio)) ** 3 + 0.4236 * (np.log10(ratio)) ** 2 - 0.5738 * np.log10(ratio) + 0.1606
                        s = A * (np.log10(Xtorre / Le)) ** 2 + B * np.log10(Xtorre / Le) + C
                    elif Xtorre / Le < 0.1 and ratio < 2.0:
                        saux1 = 0.1552 * (ratio) ** 4 - 0.8575 * (ratio) ** 3 + 1.8133 * (ratio) ** 2 - 1.9115 * (ratio) + 1.0124
                        A = -1.342 * (np.log10(ratio)) ** 3 - 0.8222 * (np.log10(ratio)) ** 2 + 0.4609 * np.log10(ratio) - 0.0791
                        B = -1.0196 * (np.log10(ratio)) ** 3 - 0.8910 * (np.log10(ratio)) ** 2 + 0.5343 * np.log10(ratio) - 0.1156
                        C = 0.8030 * (np.log10(ratio)) ** 3 + 0.4236 * (np.log10(ratio)) ** 2 - 0.5738 * np.log10(ratio) + 0.1606
                        saux2 = A * (np.log10(Xtorre / Le)) ** 2 + B * np.log10(Xtorre / Le) + C
                        s = saux2 + (Xtorre / Le - 0.1) * (saux1 - saux2) / (0 - 0.1)
                    else:
                        s = 0
                    co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                Tipo = "Falésia e escarpas"
                Alt_colina = H
                Ld = 0
        elif y[1] < y[2] and y[2] < y[4]:  # Subida com patamares
            if x[1] >= 0:
                Tipo = "Zona Plana"
                co = 1
                Lu = 0
                Alt_colina = 0
                Ld = 0
            if x[1] < 0 and x[2] > 0:
                Lu = x[2] - x[1]
                H = y[2] - y[1]
                Xtorre = -x[2]
                phi = H / Lu if Lu != 0 else 0
                if phi >= 0.05:
                    Le = Lu if phi < 0.3 else H / 0.3
                    if Xtorre / Lu >= -1.5 and Xtorre / Lu < 0 and h_torre / Le >= 0 and h_torre / Le <= 2.0:
                        A = 0.1552 * (h_torre / Le) ** 4 - 0.8575 * (h_torre / Le) ** 3 + 1.8133 * (h_torre / Le) ** 2 - 1.9115 * (h_torre / Le) + 1.0124
                        B = 0.3542 * (h_torre / Le) ** 2 - 1.0577 * (h_torre / Le) + 2.6456
                        s = A * np.exp(B * Xtorre / Lu)
                    else:
                        s = 0
                    co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                Tipo = "Colina isolada"
                Alt_colina = H
                Ld = 0

            elif x[2] < 0 and x[3] > 0:  # Falesia
                Lu = x[2] - x[1]
                H = y[2] - y[1]
                Xtorre = -x[2]
                phi = H / Lu if Lu != 0 else 0
                if phi >= 0.05:
                    Le = Lu if phi < 0.3 else H / 0.3
                    ratio = h_torre / Le
                    if ratio < 0.1:
                        ratio = 0.1
                    if Xtorre / Le >= 0.1 and Xtorre / Le <= 3.5 and ratio <= 2.0:
                        A = -1.342 * (np.log10(ratio)) ** 3 - 0.8222 * (np.log10(ratio)) ** 2 + 0.4609 * np.log10(ratio) - 0.0791
                        B = -1.0196 * (np.log10(ratio)) ** 3 - 0.8910 * (np.log10(ratio)) ** 2 + 0.5343 * np.log10(ratio) - 0.1156
                        C = 0.8030 * (np.log10(ratio)) ** 3 + 0.4236 * (np.log10(ratio)) ** 2 - 0.5738 * np.log10(ratio) + 0.1606
                        s = A * (np.log10(Xtorre / Le)) ** 2 + B * np.log10(Xtorre / Le) + C
                    elif Xtorre / Le < 0.1 and ratio < 2.0:
                        saux1 = 0.1552 * (ratio) ** 4 - 0.8575 * (ratio) ** 3 + 1.8133 * (ratio) ** 2 - 1.9115 * (ratio) + 1.0124
                        A = -1.342 * (np.log10(ratio)) ** 3 - 0.8222 * (np.log10(ratio)) ** 2 + 0.4609 * np.log10(ratio) - 0.0791
                        B = -1.0196 * (np.log10(ratio)) ** 3 - 0.8910 * (np.log10(ratio)) ** 2 + 0.5343 * np.log10(ratio) - 0.1156
                        C = 0.8030 * (np.log10(ratio)) ** 3 + 0.4236 * (np.log10(ratio)) ** 2 - 0.5738 * np.log10(ratio) + 0.1606
                        saux2 = A * (np.log10(Xtorre / Le)) ** 2 + B * np.log10(Xtorre / Le) + C
                        s = saux2 + (Xtorre / Le - 0.1) * (saux1 - saux2) / (0 - 0.1)
                    else:
                        s = 0
                    co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                Tipo = "Falésia e escarpas"
                Alt_colina = H
                Ld = 0
            elif x[3] < 0 and x[4] >= 0:  # Considero a subida global
                Lu = x[4] - x[1]
                H = y[4] - y[1]
                Xtorre = -x[4]
                phi = H / Lu if Lu != 0 else 0
                if phi >= 0.05:
                    Le = Lu if phi < 0.3 else H / 0.3
                    if Xtorre / Lu >= -1.5 and Xtorre / Lu < 0 and h_torre / Le >= 0 and h_torre / Le <= 2.0:
                        A = 0.1552 * (h_torre / Le) ** 4 - 0.8575 * (h_torre / Le) ** 3 + 1.8133 * (h_torre / Le) ** 2 - 1.9115 * (h_torre / Le) + 1.0124
                        B = 0.3542 * (h_torre / Le) ** 2 - 1.0577 * (h_torre / Le) + 2.6456
                        s = A * np.exp(B * Xtorre / Lu)
                    else:
                        s = 0
                    co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                Tipo = "Colina isolada"
                Alt_colina = H
                Ld = 0
            elif x[4] < 0 and x[5] >= 0:  # Considera uma falesia
                Lu = x[4] - x[1]
                H = y[4] - y[1]
                Xtorre = -x[4]
                phi = H / Lu if Lu != 0 else 0
                if phi >= 0.05:
                    Le = Lu if phi < 0.3 else H / 0.3
                    ratio = h_torre / Le
                    if ratio < 0.1:
                        ratio = 0.1
                    if Xtorre / Le >= 0.1 and Xtorre / Le <= 3.5 and ratio <= 2.0:
                        A = -1.342 * (np.log10(ratio)) ** 3 - 0.8222 * (np.log10(ratio)) ** 2 + 0.4609 * np.log10(ratio) - 0.0791
                        B = -1.0196 * (np.log10(ratio)) ** 3 - 0.8910 * (np.log10(ratio)) ** 2 + 0.5343 * np.log10(ratio) - 0.1156
                        C = 0.8030 * (np.log10(ratio)) ** 3 + 0.4236 * (np.log10(ratio)) ** 2 - 0.5738 * np.log10(ratio) + 0.1606
                        s = A * (np.log10(Xtorre / Le)) ** 2 + B * np.log10(Xtorre / Le) + C
                    elif Xtorre / Le < 0.1 and ratio < 2.0:
                        saux1 = 0.1552 * (ratio) ** 4 - 0.8575 * (ratio) ** 3 + 1.8133 * (ratio) ** 2 - 1.9115 * (ratio) + 1.0124
                        A = -1.342 * (np.log10(ratio)) ** 3 - 0.8222 * (np.log10(ratio)) ** 2 + 0.4609 * np.log10(ratio) - 0.0791
                        B = -1.0196 * (np.log10(ratio)) ** 3 - 0.8910 * (np.log10(ratio)) ** 2 + 0.5343 * np.log10(ratio) - 0.1156
                        C = 0.8030 * (np.log10(ratio)) ** 3 + 0.4236 * (np.log10(ratio)) ** 2 - 0.5738 * np.log10(ratio) + 0.1606
                        saux2 = A * (np.log10(Xtorre / Le)) ** 2 + B * np.log10(Xtorre / Le) + C
                        s = saux2 + (Xtorre / Le - 0.1) * (saux1 - saux2) / (0 - 0.1)
                    else:
                        s = 0
                    co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                Tipo = "Falésia e escarpas"
                Alt_colina = H
                Ld = 0
        elif y[1] > y[2] and y[2] > y[4]:  # Descida com patamares
            if x[1] >= 0 or (x[2] < 0 and x[3] >= 0) or (x[4] < 0 and x[5] >= 0):
                Tipo = "Zona Plana"
                co = 1
                Lu = 0
                Alt_colina = 0
                Ld = 0
            elif x[1] < 0 and x[2] >= 0:  # torre primeira descida
                Ld = x[2] - x[1]
                H = y[1] - y[2]
                Lplano = x[1] - x[0]
                Lanalise = x[5] - x[0]
                Xtorre = -x[1]
                if Lplano >= 0.5 * Lanalise:
                    co = 1
                    Tipo = "Planalto"
                else:
                    phi = H / Ld if Ld != 0 else 0
                    if phi >= 0.05:
                        Le = Ld if phi < 0.3 else H / 0.3
                        if Xtorre / Ld >= 0 and Xtorre / Ld <= 2.0 and h_torre / Le >= 0 and h_torre / Le < 2.0:
                            A = 0.1552 * (h_torre / Le) ** 4 - 0.8575 * (h_torre / Le) ** 3 + 1.8133 * (h_torre / Le) ** 2 - 1.9115 * (h_torre / Le) + 1.0124
                            B = -0.3056 * (h_torre / Le) ** 2 + 1.0212 * (h_torre / Le) - 1.7637
                            s = A * np.exp(B * Xtorre / Ld)
                        else:
                            s = 0
                        co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                    Tipo = "Colina isolada"
                    Alt_colina = H
                    Lu = Ld
            elif x[3] < 0 and x[4] >= 0:  # Descida global
                Ld = x[4] - x[1]
                H = y[1] - y[4]
                Lplano = x[3] - x[2]
                Lanalise = x[5] - x[0]
                Xtorre = -x[3]
                if Lplano >= 0.5 * Lanalise:
                    co = 1
                    Tipo = "Planalto"
                else:
                    phi = H / Ld if Ld != 0 else 0
                    if phi >= 0.05:
                        Le = Ld if phi < 0.3 else H / 0.3
                        if Xtorre / Ld >= 0 and Xtorre / Ld <= 2.0 and h_torre / Le >= 0 and h_torre / Le < 2.0:
                            A = 0.1552 * (h_torre / Le) ** 4 - 0.8575 * (h_torre / Le) ** 3 + 1.8133 * (h_torre / Le) ** 2 - 1.9115 * (h_torre / Le) + 1.0124
                            B = -0.3056 * (h_torre / Le) ** 2 + 1.0212 * (h_torre / Le) - 1.7637
                            s = A * np.exp(B * Xtorre / Ld)
                        else:
                            s = 0
                        co = 1 + 2 * s * phi if phi < 0.3 else 1 + 0.6 * s
                    Tipo = "Colina isolada"
                    Alt_colina = H
                    Lu = Ld

    # ── Ajuste especifico de Franca -- CODIGO enviado pelo utilizador.
    #    Guarda  Tipo != "Zona Plana"/"Planalto"  +  a formula final movida
    #    para DENTRO de cada  else  (onde Smax/Le/kred/alphaco existem).
    if pais=="France" and not ignorar_orografia:
        if Tipo!="Zona Plana" and Tipo!="Planalto":
            if Tipo == "Colina isolada" and colina_cadeia=="No":
                if phi<0.05:
                    co=1
                else:
                    if phi<0.25:
                        Le=Lu/2
                    else:
                        Le=2*Alt_colina
                    Smax=1.6*Alt_colina/Le
                    alphaco=4
                    if Xtorre<=0:
                        kred=1.5
                    else:
                        kred=1.5
                    co=1+Smax*(1-abs(Xtorre)/(kred*Le))*np.exp(-alphaco*h_torre/Le)
            elif Tipo == "Falésia e escarpas":
                if phi<0.05:
                    co=1
                else:
                    if phi<0.25:
                        Le=Lu/2
                    else:
                        Le=2*Alt_colina
                    Smax=1.3*Alt_colina/Le
                    alphaco=2.5
                    if Xtorre<=0:
                        kred=1.5
                    else:
                        kred=4
                    co=1+Smax*(1-abs(Xtorre)/(kred*Le))*np.exp(-alphaco*h_torre/Le)
            elif Tipo == "Colina isolada" and colina_cadeia=="Yes":
                if phi<0.05:
                    co=1
                else:
                    if phi<0.25:
                        Le=Lu/2
                    else:
                        Le=2*Alt_colina
                    Smax=2.2*Alt_colina/Le
                    alphaco=3
                    if Xtorre<=0:
                        kred=1.5
                    else:
                        kred=1.5
                    co=1+Smax*(1-abs(Xtorre)/(kred*Le))*np.exp(-alphaco*h_torre/Le)

    if co is None:
        raise ValueError("co não foi calculado para este perfil.")

    # co nunca pode ser menor que 1 (EN 1991-1-4 Anexo A.3: co so amplifica).
    # Algumas das formulas de "s" acima (sobretudo a de falesia/log10, e o
    # ajuste de Franca com Smax/kred) nao sao limitadas e podem dar um valor
    # negativo em certas geometrias -- sem isto o co (e a pressao de vento
    # calculada a partir dele) saia negativo, o que nao existe fisicamente.
    co = max(co, 1.0)

    if pais == "France":
        rho_ar = 1.225
    else:
        rho_ar = 1.25
    wp = Pressure_wind(pais, h_vector=np.array([h_torre]), vb=vb * cdir,
                        z0=z0, zmin=zmin, Alt=0, rho_ar=rho_ar, c0=np.array([co]))
    wind_pressure = float(wp[0])

    return {
        "wind_pressure": wind_pressure,
        "co": co,
        "Lu": Lu,
        "Ld": Ld,
        "Tipo": Tipo,
        "Alt_colina": Alt_colina,
        "Xtorre": Xtorre,
    }


# ── wind_config (.txt) -- copia adaptada de gerar_wind_config.py ───────────
COUNTRY = "Portugal"
AUTO = "Yes"
TERRAIN = 0
SPEED_FOR_DISP = 0
RELIABILITY = 2
CLIENT_NAME = "BSS Engineering"
FOUNDATION_TYPE = 0
SLAB_HEIGHT = 0
SLAB_WIDTH = 0
PIER_HEIGHT = 0
PIER_WIDTH = 0
HEIGHT_ABOVE_GROUND = 0
SOIL_TYPE = 0
COMPRESSIBILITY = 0
UNIT_WEIGHT = 0
ALLOWABLE_BEARING = 0
BETA_ANGLE = 0
COEFF_FRICTION = 0
DISPLACEMENT_LIMIT = "Yes"
MAX_DISPLACEMENT = 1
LOAD_CASE = "SLS"
LOAD_CASE_SPEED = 0

CONFIG_NORMAL = {"DISPLACEMENT_LIMIT": "No", "MAX_DISPLACEMENT": 0}
CONFIG_ROT = {}


def _fmt(v):
    f = float(v)
    return int(f) if f == int(f) else f


def _get(key, override):
    return override.get(key, globals()[key])


def _conteudo_wind_config(max_result, override):
    z0 = float(max_result["z0"])
    zmin = float(max_result["zmin"])
    cdir = float(max_result["cdir"])
    vb = float(max_result["vb"])
    tipo = max_result["Tipo"]
    lu = float(max_result["Lu"])
    ld = float(max_result["Ld"])
    alt_colina = float(max_result["Alt_colina"])
    xtorre = float(max_result["Xtorre"])
    colina_cadeia = max_result.get("colina_cadeia", "No") or "No"
    # Pais real do site. "Portugal-RSA" (formula legada) escreve-se "Portugal".
    pais = max_result.get("pais") or _get('COUNTRY', override)
    if pais == "Portugal-RSA":
        pais = "Portugal"

    return f"""\
Wind Config
Country,{pais}
Auto,{_get('AUTO', override)}
z0,{z0}
zmin,{zmin}
cdir,{cdir}
Terrain,{_get('TERRAIN', override)}
vb,{_fmt(vb)}
Speed for Displacement,{_get('SPEED_FOR_DISP', override)}
Reliability,{_get('RELIABILITY', override)}
Client Name,{_get('CLIENT_NAME', override)}
Foundation Config
Foundation Type,{_get('FOUNDATION_TYPE', override)}
Slab Height,{_get('SLAB_HEIGHT', override)}
Slab Width,{_get('SLAB_WIDTH', override)}
Pier Height,{_get('PIER_HEIGHT', override)}
Pier Width,{_get('PIER_WIDTH', override)}
Height Above Ground,{_get('HEIGHT_ABOVE_GROUND', override)}
Soil Type,{_get('SOIL_TYPE', override)}
Compressibility,{_get('COMPRESSIBILITY', override)}
Unit Weight,{_get('UNIT_WEIGHT', override)}
Allowable Bearing Pressure,{_get('ALLOWABLE_BEARING', override)}
Beta Angle,{_get('BETA_ANGLE', override)}
Coefficient of friction,{_get('COEFF_FRICTION', override)}
Displacement Config
Displacement Limit,{_get('DISPLACEMENT_LIMIT', override)}
Maximum Displacement,{_get('MAX_DISPLACEMENT', override)}
Load Case,{_get('LOAD_CASE', override)}
Load Case Speed,{_get('LOAD_CASE_SPEED', override)}
Orografy Config
Tipo,{tipo}
Colina Cadeia,{colina_cadeia}
Lu,{_fmt(lu)}
Ld,{_fmt(ld)}
Alt Colina,{_fmt(alt_colina)}
Xtorre,{_fmt(xtorre)}"""


def gerar_wind_config(codigo, max_result, pasta_saida=WIND_CONFIG_DIR):
    """Grava {codigo}_wind_config.txt e {codigo}_rot_wind_config.txt em
    pasta_saida a partir do resultado maximo (dict devolvido por
    analisar_site)."""
    os.makedirs(pasta_saida, exist_ok=True)
    path_normal = os.path.join(pasta_saida, f"{codigo}_wind_config.txt")
    path_rot = os.path.join(pasta_saida, f"{codigo}_rot_wind_config.txt")

    with open(path_normal, "w", encoding="utf-8") as f:
        f.write(_conteudo_wind_config(max_result, CONFIG_NORMAL))
    with open(path_rot, "w", encoding="utf-8") as f:
        f.write(_conteudo_wind_config(max_result, CONFIG_ROT))

    return path_normal, path_rot


# ── CSV de resumo (formato analise_terreno.py) ────────────────────────────
def _linha_csv(codigo, longitude, latitude, direcao, lado, res,
               z0, zmin, cdir, h_torre, vb, pais, colina_cadeia):
    """Uma linha nas colunas de CSV_HEADER, a partir do dict que
    analise_perfil devolve (res)."""
    return {
        "codigo": codigo, "longitude": longitude, "latitude": latitude,
        "direcao": direcao, "lado": lado,
        "wind_pressure_Pa": round(res["wind_pressure"], 2),
        "co": round(res["co"], 4),
        "Tipo": res["Tipo"], "Alt_colina": res["Alt_colina"],
        "Lu": res["Lu"], "Ld": res["Ld"], "Xtorre": res["Xtorre"],
        "h_torre": h_torre, "vb": vb, "z0": z0, "zmin": zmin, "cdir": cdir,
        "pais": pais, "colina_cadeia": colina_cadeia,
    }


def _gravar_csv_incremental(caminho, linhas_novas, codigo):
    """Reescreve `caminho` mantendo as linhas de OUTRAS torres e substituindo
    as da torre `codigo` pelas `linhas_novas` (modo incremental do v2)."""
    existentes = []
    if os.path.isfile(caminho):
        with open(caminho, encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f, delimiter=";"):
                if row.get("codigo") != codigo:
                    existentes.append(row)
    os.makedirs(os.path.dirname(caminho) or ".", exist_ok=True)
    with open(caminho, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CSV_HEADER, delimiter=";", extrasaction="ignore")
        w.writeheader()
        w.writerows(existentes)
        w.writerows(linhas_novas)


# ── Mapa de pressoes (8 fatias N..NW) a partir de resultados_direcoes ──────
def _valores_por_rumo(linhas_direcoes, campo):
    """Mapeia as 8 linhas de resultados_direcoes para os 8 rumos cardeais
    (Direcao 0 ESQ = S, DIR = N, ...), lendo a coluna `campo`. Devolve lista
    de 8 na ordem N, NE, E, SE, S, SW, W, NW (None onde faltar)."""
    p = {}
    for l in linhas_direcoes or []:
        try:
            ang = int(str(l["direcao"]).split()[-1])
        except (ValueError, KeyError, IndexError):
            continue
        par = _DIR_ESQ_DIR.get(ang)
        if not par:
            continue
        rumo = par[0] if l.get("lado") == "ESQ" else par[1]
        try:
            p[rumo] = float(l[campo])
        except (TypeError, ValueError, KeyError):
            continue
    return [p.get(c) for c in _COMPASS_ORDER]


def _raio_mapa(pasta_saida):
    """radius_meters do site_info.json (para o mapa ter a MESMA escala dos
    outros pizza-maps da etapa 2). Fallback: RAIO_MAPA_PRESSAO_M."""
    try:
        with open(os.path.join(pasta_saida, "site_info.json"), encoding="utf-8") as f:
            r = json.load(f).get("radius_meters")
        if r and float(r) > 0:
            return float(r)
    except Exception:
        pass
    return RAIO_MAPA_PRESSAO_M


def gerar_mapa_pressao(linhas_direcoes, lat, lon, pasta_saida):
    """Mapa de 8 fatias colorido pela PRESSAO DE VENTO por rumo -- os valores
    de `wind_pressure_Pa` de resultados_direcoes.csv (ja com co e cdir).
    Grava imagens/qp_pressure.jpg."""
    valores = _valores_por_rumo(linhas_direcoes, "wind_pressure_Pa")
    caminho = desenhar_mapa_circular(
        valores, lat, lon, os.path.join(pasta_saida, "imagens", "qp_pressure.jpg"),
        radius_meters=_raio_mapa(pasta_saida),
        cmap_name="YlOrRd", fmt="{:.0f}", titulo_legenda="wind pressure (N/m2)")
    validos = [v for v in valores if v is not None]
    if caminho and validos:
        print(f"    mapa de pressao: imagens/qp_pressure.jpg  "
              f"(min {min(validos):.0f} / max {max(validos):.0f} N/m2)")
    return caminho


def gerar_mapa_co(linhas_direcoes, lat, lon, pasta_saida):
    """Mapa de 8 fatias colorido pelo COEFICIENTE OROGRAFICO co por rumo --
    os valores de `co` de resultados_direcoes.csv. Grava imagens/co_map.jpg.
    Por definicao o co nunca deveria ser menor que 1 -- qualquer fatia que
    apareca abaixo disso (arredondamento/interpolacao) e mostrada como 1,
    so nesta imagem (o valor no CSV/calculo fica inalterado)."""
    valores = _valores_por_rumo(linhas_direcoes, "co")
    valores = [v if v is None else max(v, 1.0) for v in valores]
    caminho = desenhar_mapa_circular(
        valores, lat, lon, os.path.join(pasta_saida, "imagens", "co_map.jpg"),
        radius_meters=_raio_mapa(pasta_saida),
        cmap_name="viridis", fmt="{:.3f}", titulo_legenda="co (orography)")
    validos = [v for v in valores if v is not None]
    if caminho and validos:
        print(f"    mapa de co: imagens/co_map.jpg  "
              f"(min {min(validos):.3f} / max {max(validos):.3f})")
    return caminho


# ── Orquestracao: roda as 4 direcoes x ESQ/DIR e acha o maximo global ──────
def analisar_site(resultado_site):
    """
    Recebe o dict resultado_site (codigo_site, h_torre, longitude, latitude,
    vb, pais, colina_cadeia, direcoes={ang: {x1..y6, z0_esq, z_min_esq,
    cdir_esq, z0_dir, zmin_dir, cdir_dir}}).
    Devolve (global_max, linhas_direcoes):
      - global_max        : dict da direcao/lado com maior pressao de vento
      - linhas_direcoes   : lista de dicts (uma por direcao x lado), colunas
                            de CSV_HEADER -> resultados_direcoes.csv
    """
    codigo = resultado_site.get("codigo_site")
    longitude = resultado_site.get("longitude")
    latitude = resultado_site.get("latitude")
    h_torre = resultado_site["h_torre"]
    vb = resultado_site["vb"]
    pais = resultado_site.get("pais", "Portugal")
    # ColinaCadeia vem do botao da pagina (via run_site). So afeta o calculo
    # de co em Franca; nos outros paises so vai para o ficheiro wind_config.
    colina_cadeia = (resultado_site.get("colina_cadeia") or "No")
    # Orografia (botao): "No" -> ignora a analise do perfil e forca co = 1.
    ignorar_oro = str(resultado_site.get("orografia") or "Yes").strip().lower() in (
        "no", "nao", "não", "0", "false", "ignorar")
    global_max = None
    linhas_direcoes = []
    _dummy = [0.0] * 6

    for ang in _DIRECOES_TEMPLATE:
        pontos = resultado_site["direcoes"].get(ang, {})
        direcao = f"Direcao {ang}"

        # cdir (coef. direcional): so != 1 em Franca. Ausente ou <= 0 -> 1.0.
        cdir_esq = pontos.get('cdir_esq')
        cdir_esq = 1.0 if cdir_esq is None or cdir_esq <= 0 else cdir_esq
        cdir_dir = pontos.get('cdir_dir')
        cdir_dir = 1.0 if cdir_dir is None or cdir_dir <= 0 else cdir_dir

        z0_esq, zmin_esq = pontos.get('z0_esq'), pontos.get('z_min_esq')
        z0_dir, zmin_dir = pontos.get('z0_dir'), pontos.get('zmin_dir')

        if ignorar_oro:
            # sem perfil -> so precisa de z0/zmin (da etapa 1); co = 1
            if z0_esq is None and z0_dir is None:
                continue
            x = y = x_inv = y_inv = _dummy
        else:
            if not pontos or any(pontos.get(p) is None for p in _PONTOS_TEMPLATE):
                continue
            x = [pontos[f'x{i}'] for i in range(1, 7)]
            y = [pontos[f'y{i}'] for i in range(1, 7)]
            x_inv, y_inv = inverter_perfil(x, y)

        # ESQ: ordem original + z0_esq / z_min_esq
        res_esq = analise_perfil(x, y, z0_esq, zmin_esq, h_torre, vb, cdir_esq,
                                 pais, colina_cadeia, ignorar_orografia=ignorar_oro)
        linhas_direcoes.append(_linha_csv(codigo, longitude, latitude, direcao, "ESQ",
                                          res_esq, z0_esq, zmin_esq, cdir_esq, h_torre, vb, pais, colina_cadeia))
        if global_max is None or res_esq["wind_pressure"] > global_max["wind_pressure"]:
            global_max = {**res_esq, "direcao": direcao, "lado": "ESQ",
                          "z0": z0_esq, "zmin": zmin_esq,
                          "cdir": cdir_esq, "h_torre": h_torre, "vb": vb,
                          "pais": pais, "colina_cadeia": colina_cadeia}

        # DIR: ordem inversa + z0_dir / zmin_dir
        res_dir = analise_perfil(x_inv, y_inv, z0_dir, zmin_dir, h_torre, vb, cdir_dir,
                                 pais, colina_cadeia, ignorar_orografia=ignorar_oro)
        linhas_direcoes.append(_linha_csv(codigo, longitude, latitude, direcao, "DIR",
                                          res_dir, z0_dir, zmin_dir, cdir_dir, h_torre, vb, pais, colina_cadeia))
        if global_max is None or res_dir["wind_pressure"] > global_max["wind_pressure"]:
            global_max = {**res_dir, "direcao": direcao, "lado": "DIR",
                          "z0": z0_dir, "zmin": zmin_dir,
                          "cdir": cdir_dir, "h_torre": h_torre, "vb": vb,
                          "pais": pais, "colina_cadeia": colina_cadeia}

    return global_max, linhas_direcoes


# Cada octante da bussola (setores de cdir.json, na ordem N/NE/E/SE/S/SW/
# W/NW) corresponde a exatamente uma Direcao x lado do perfil de terreno
# -- o inverso de run_site._DIRECAO_ESQ_DIR (0: S/N, 45: SW/NE, 90: W/E,
# 135: SE/NW).
_COMPASS_ORDEM = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
_COMPASS_TO_DIRECAO_LADO = {
    'N': ('Direcao 0', 'DIR'), 'NE': ('Direcao 45', 'DIR'),
    'E': ('Direcao 90', 'DIR'), 'SE': ('Direcao 135', 'ESQ'),
    'S': ('Direcao 0', 'ESQ'), 'SW': ('Direcao 45', 'ESQ'),
    'W': ('Direcao 90', 'ESQ'), 'NW': ('Direcao 135', 'DIR'),
}


def _atualizar_cdir_json(pasta_saida, max_result, linhas_direcoes):
    """Atualiza cdir.json (se existir -- so paises com cdir, ex. Franca)
    com os valores REAIS de pressao, ja calculados aqui na etapa 4 (com
    co/orografia): o "pior_pressão" (pior caso global, igual ao
    resultados_maximos.csv) e o "qp" de cada um dos 8 "setores" (cada
    octante da bussola -> a Direcao x lado correspondente, ver
    _COMPASS_TO_DIRECAO_LADO). O cdir.json e escrito antes disto pelo
    WindAnalysis (etapa 2), quando o co ainda nao existe -- por isso estes
    valores so podem ser preenchidos corretamente aqui."""
    caminho = os.path.join(pasta_saida, "cdir.json")
    if not os.path.isfile(caminho):
        return
    try:
        with open(caminho, "r", encoding="utf-8") as f:
            cdir_json = json.load(f)

        pressao_por_direcao_lado = {
            (linha["direcao"], linha["lado"]): linha["wind_pressure_Pa"]
            for linha in linhas_direcoes
        }
        setores = cdir_json.get("setores", [])
        for i, compass in enumerate(_COMPASS_ORDEM):
            if i >= len(setores):
                break
            qp = pressao_por_direcao_lado.get(_COMPASS_TO_DIRECAO_LADO[compass])
            if qp is not None:
                setores[i]["qp"] = round(qp)

        pior_info = {
            "qp": round(max_result["wind_pressure"]),
            "cdir": max_result["cdir"],
            "z0": max_result["z0"],
            "zmin": max_result["zmin"],
        }
        # O "cdir" do topo (antes: o cdir BASE da zona/regiao, ex. 0.7)
        # passa a repetir o cdir do pior setor (igual ao de "pior_pressão"),
        # para nao ter dois valores de "cdir" diferentes e sem ligacao um
        # com o outro no mesmo ficheiro.
        cdir_json["cdir"] = pior_info["cdir"]
        # Mesma posicao de sempre -- logo depois de angulo_cdir_fim, antes
        # de "setores" -- so com os valores certos agora (pior caso REAL,
        # calculado aqui na etapa 4, com co/orografia).
        cdir_json.pop("pior_pressão", None)
        ordenado = {}
        for k, v in cdir_json.items():
            ordenado[k] = v
            if k == "angulo_cdir_fim":
                ordenado["pior_pressão"] = pior_info
        if "pior_pressão" not in ordenado:
            ordenado["pior_pressão"] = pior_info
        with open(caminho, "w", encoding="utf-8") as f:
            json.dump(ordenado, f, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"    [AVISO] nao atualizei cdir.json: {e}")


def analisar_e_gerar_wind_config(resultado_site, pasta_saida=WIND_CONFIG_DIR):
    """Roda analisar_site(), grava os .txt de wind_config em pasta_saida e
    (re)escreve os CSV de resumo  resultados_maximos.csv  e
    resultados_direcoes.csv  DENTRO de pasta_saida (resultados/<ID>/) -- so
    com as linhas desta torre. Devolve o resultado maximo (ou None)."""
    codigo = resultado_site["codigo_site"]
    max_result, linhas_direcoes = analisar_site(resultado_site)
    if max_result is None:
        print(f"    [AVISO] Nenhuma direcao valida para calcular co/pressao em {codigo}.")
        return None

    print(f"    Maximo global: {max_result['direcao']} ({max_result['lado']})  "
          f"WP={max_result['wind_pressure']:.2f} Pa  co={max_result['co']:.3f}  Tipo={max_result['Tipo']}")

    _atualizar_cdir_json(pasta_saida, max_result, linhas_direcoes)

    path_normal, path_rot = gerar_wind_config(codigo, max_result, pasta_saida)
    print(f"    wind_config: {os.path.basename(path_normal)} + {os.path.basename(path_rot)}")

    # ── CSV de resumo (formato analise_terreno.py) -- SO desta torre, dentro
    #    da propria pasta resultados/<ID>/ (nao acumula as outras torres). ──
    linha_max = _linha_csv(
        codigo, resultado_site.get("longitude"), resultado_site.get("latitude"),
        max_result["direcao"], max_result["lado"], max_result,
        max_result["z0"], max_result["zmin"], max_result["cdir"],
        max_result["h_torre"], max_result["vb"],
        max_result["pais"], max_result["colina_cadeia"],
    )
    csv_max = os.path.join(pasta_saida, "resultados_maximos.csv")
    csv_dir = os.path.join(pasta_saida, "resultados_direcoes.csv")
    _gravar_csv_incremental(csv_max, [linha_max], codigo)
    _gravar_csv_incremental(csv_dir, linhas_direcoes, codigo)
    print(f"    resumo: {os.path.basename(csv_max)} (1 linha) + {os.path.basename(csv_dir)} ({len(linhas_direcoes)} linhas)")

    # ── Mapas de 8 rumos (pressao de vento e co), de resultados_direcoes ──
    _lat = resultado_site.get("latitude")
    _lon = resultado_site.get("longitude")
    try:
        gerar_mapa_pressao(linhas_direcoes, _lat, _lon, pasta_saida)
    except Exception as e:
        print(f"    [AVISO] mapa de pressao nao gerado: {e}")
    try:
        gerar_mapa_co(linhas_direcoes, _lat, _lon, pasta_saida)
    except Exception as e:
        print(f"    [AVISO] mapa de co nao gerado: {e}")

    return max_result


# ── CLI (etapa 4 do pipeline, quando corre como .exe separado) ─────────────
def _normalizar_direcoes(resultado_site):
    """JSON transforma as chaves int (0/45/90/135) de 'direcoes' em str.
    Repoe-as como int para analisar_site()."""
    d = resultado_site.get("direcoes") or {}
    resultado_site["direcoes"] = {int(k): v for k, v in d.items()}
    return resultado_site


def _cli(argv):
    """
    co_wind_analysis "ID" --outdir <dir>

    Le  <dir>/<ID>/resultado_site.json  (ja consolidado pelo run_site, com
    z0/zmin/cdir/vb/pais/colina_cadeia/orografia por direcao), calcula o co e
    a pressao de vento, e escreve em  <dir>/<ID>/ :
      - <ID>_wind_config.txt  +  <ID>_rot_wind_config.txt
      - imagens/qp_pressure.jpg  +  imagens/co_map.jpg
    alem de actualizar (incremental)  <dir>/resultados_maximos.csv  e
    <dir>/resultados_direcoes.csv .
    """
    outdir = os.path.join(os.getcwd(), "resultados")
    rest = []
    i = 0
    while i < len(argv):
        if argv[i] == "--outdir" and i + 1 < len(argv):
            outdir = argv[i + 1]; i += 2
        else:
            rest.append(argv[i]); i += 1

    if not rest:
        raise SystemExit('Uso: co_wind_analysis "ID" --outdir <dir>')

    id_torre = rest[0].strip()
    pasta_saida = os.path.join(outdir, id_torre)
    caminho_rs = os.path.join(pasta_saida, "resultado_site.json")
    if not os.path.isfile(caminho_rs):
        raise SystemExit(f"ERRO: nao encontrei {caminho_rs} -- corre primeiro as etapas 1-3.")

    with open(caminho_rs, "r", encoding="utf-8") as f:
        resultado_site = _normalizar_direcoes(json.load(f))
    resultado_site.setdefault("codigo_site", id_torre)

    analisar_e_gerar_wind_config(resultado_site, pasta_saida=pasta_saida)


if __name__ == "__main__":
    import sys
    _cli(sys.argv[1:])
