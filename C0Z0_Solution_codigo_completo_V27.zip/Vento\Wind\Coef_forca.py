import numpy as np
def coef_forca(h_torre,b_medio,lado,wind_pressure,rho_ar,Tube,visco,Espessura,k,vm,Pais):

    if Pais in ["Spain_NB_AE"]:
        cf=np.ones(len(Tube))*0.8
        return cf
    if lado==0:
        v=np.sqrt(2*wind_pressure/rho_ar) #Pag.78
        Re=v*Tube/(visco)
    else:
        Re=vm*Tube/(visco)
    Re=Re
    
    cf0=np.zeros(len(Re))
    ratiokb=k/Tube
    for i in range(len(Tube)):
        r=Espessura[i]*2
        if lado==0 or lado==20 or (lado>=16 and Re[i]<2*10**5) :
            if ratiokb[i]<10**-2 and ratiokb[i]>10**-3:
                ratio1=10**-2
                ratio2=10**-3
                if Re[i]>10**4 and Re[i]<1.85*10**5:
                    cf01=1.2
                elif Re[i]<2.16*10**5:
                    cf01=0.11/(Re[i]/10**6)**1.4
                else:
                    cf01=1.2+(0.18*np.log10(10*10**-2))/(1+0.4*np.log10(Re[i]/10**6))
                if Re[i]>10**4 and Re[i]<1.85*10**5:
                    cf02=1.2
                elif Re[i]<2.65*10**5:
                    cf02=0.11/(Re[i]/10**6)**1.4
                else:
                    cf02=1.2+(0.18*np.log10(10*10**-3))/(1+0.4*np.log10(Re[i]/10**6))
            elif ratiokb[i]>10**-4:
                ratio1=10**-3
                ratio2=10**-4
                if Re[i]>10**4 and Re[i]<1.85*10**5:
                    cf01=1.2
                elif Re[i]<2.65*10**5:
                    cf01=0.11/(Re[i]/10**6)**1.4
                else:
                    cf01=1.2+(0.18*np.log10(10*10**-3))/(1+0.4*np.log10(Re[i]/10**6))
                if Re[i]>10**4 and Re[i]<1.85*10**5:
                    cf02=1.2
                elif Re[i]<3.3*10**5:
                    cf02=0.11/(Re[i]/10**6)**1.4
                else:
                    cf02=1.2+(0.18*np.log10(10*10**-4))/(1+0.4*np.log10(Re[i]/10**6))
            elif ratiokb[i]>10**-5:
                ratio1=10**-4
                ratio2=10**-5
                
                if Re[i]>10**4 and Re[i]<1.85*10**5:
                    cf01=1.2
                elif Re[i]<3.3*10**5:
                    cf01=0.11/(Re[i]/10**6)**1.4
                else:
                    cf01=1.2+(0.18*np.log10(10*10**-4))/(1+0.4*np.log10(Re[i]/10**6))  
                if Re[i]>10**4 and Re[i]<1.85*10**5:
                    cf02=1.2
                elif Re[i]<4*10**5:
                    cf02=0.11/(Re[i]/10**6)**1.4
                elif Re[i]<6*10**5:
                    cf02=0.4
                else:
                    cf02=1.2+(0.18*np.log10(10*10**-5))/(1+0.4*np.log10(Re[i]/10**6))
            else:
                if Re[i]>10**4 and Re[i]<1.85*10**5:
                    cf0[i]=1.2
                    
                elif Re[i]<4*10**5:
                    cf0[i]=0.11/(Re[i]/10**6)**1.4
                    
                elif Re[i]<6*10**5:
                    cf0[i]=0.4
                    
                else:
                    cf0[i]=1.2+(0.18*np.log10(10*10**-5))/(1+0.4*np.log10(Re[i]/10**6))
            if ratiokb[i]>10**-5:
                cf0[i]=(cf01-cf02)/(ratio1-ratio2)*(ratiokb[i]-ratio2)+cf02
                
        elif lado==8:
            if r/Tube[i]<0.075:
                if Re[i]<=2.4*10**5:
                    cf0[i]=1.45
                elif Re[i]>=3*10**5:
                    cf0[i]=1.3
                else:
                    cf0[i]=2.05-2.5*10**-6*Re[i]
            else:
                if Re[i]<=2*10**5:
                    cf0[i]=1.3
                elif Re[i]>=7*10**5:
                    cf0[i]=1.1
                else:
                    cf0=1.38-4*10**-7*Re[i]
        elif lado==10:
            cf0[i]=1.3
        elif lado==12:
            if r/Tube[i]>0.06 and Re[i]>2*10**5 and Re[i]<1.2*10**6: #Smooth
                cf0[i]=0.9
            elif Re[i]<4*10**5:
                cf0[i]=1.3
            else:
                cf0[i]=1.1
            
        elif lado>=16 and lado<=18 and Re[i]>=2*10**5:
            cf0[i]=0.7
        elif lado==5:
            cf0[i]=1.8
        elif lado==6:
            cf0[i]=1.6
        if cf0[i]==0:
            cf0[i]=1.2
    if Pais in ["Portugal","France","Portugal-RSA","Spain"]:
            #Valores tirados da Pag.74
        lam=2*h_torre/b_medio #NA_7.13
    elif Pais=="United Kingdom":
        lam=2*(h_torre/b_medio)*(2/cf0)
    elif Pais=="Germany":
        if lado==0:
            if h_torre>=50:
                if 0.7*h_torre/b_medio>70:
                    lam=70
                else:
                    lam=0.7*h_torre/b_medio
            elif h_torre<15:
                if h_torre/b_medio>70:
                    lam=70
                else:
                    lam=h_torre/b_medio                
            else:
                if 15/b_medio>70:
                    lam15=70
                else:
                    lam15=15/b_medio
                if 0.7*50/b_medio>70:
                    lam50=70
                else:
                    lam50=0.7*50/b_medio   
                lam=lam15+(lam50-lam15)/(50-15)*(h_torre-15)               
        else:   
            if h_torre>=50:
                if 1.4*h_torre/b_medio>70:
                    lam=70
                else:
                    lam=1.4*h_torre/b_medio
            elif h_torre<15:
                if 2*h_torre/b_medio>70:
                    lam=70
                else:
                    lam=2*h_torre/b_medio                
            else:
                if 2*15/b_medio>70:
                    lam15=70
                else:
                    lam15=2*15/b_medio
                if 1.4*50/b_medio>70:
                    lam50=70
                else:
                    lam50=1.4*50/b_medio   
                lam=lam15+(lam50-lam15)/(50-15)*(h_torre-15)  
    if Pais!="United Kingdom":
        if lam<=10:
            psi_lam=0.0434*np.log(lam)+0.6
        elif lam<=100:
            psi_lam=0.1129*np.log(lam)+0.43
        else:
            psi_lam=0.0721*np.log(lam)+0.6178 
    else:
        if lam[i]<=10:
            psi_lam=0.0434*np.log(lam[i])+0.6
        elif lam[i]<=100:
            psi_lam=0.1129*np.log(lam[i])+0.43
        else:
            psi_lam=0.0721*np.log(lam[i])+0.6178 
    cf0=cf0
    psi_lam=psi_lam
    cf=cf0*psi_lam 
    return cf