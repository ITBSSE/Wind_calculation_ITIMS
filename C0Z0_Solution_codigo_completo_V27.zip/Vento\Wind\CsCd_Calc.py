import numpy as np 
from Wind.Wind_Ec import LogDecaiment
from Utilities_Monopole.Check_None import check_not_none
from Utilities_Monopole.Utilities import find_closest_value_position
def CsCd_calc(Pais,h_torre,h_vector,IV,Tube,z0,zmin,n1,me,cf,rho_ar,vm,Alt,Ocupation_CsCd,epsilon=None):
    """Código para calcular o efeito dinâmico na estrutura (CsCd – Eurocódigo)"""

    if Pais == "Portugal":
        check_not_none(
            [h_torre, h_vector, IV, Tube, z0, zmin, n1, me, cf, rho_ar, vm, Alt],
            ["h_torre", "h_vector", "IV", "Tube", "z0", "zmin",
             "n1", "me", "cf", "rho_ar", "vm", "Alt"]
        )

        CsCd, CsCd_Out = CsCd_calc_Portugal(
            h_torre, h_vector, IV, Tube,
            z0, zmin, n1, me, cf, rho_ar, vm, Alt, Pais,Ocupation_CsCd
        )
        return CsCd, CsCd_Out


    elif Pais == "France":
        check_not_none(
            [h_torre, h_vector, IV, Tube, z0, zmin, n1, me, cf, rho_ar, vm, Alt],
            ["h_torre", "h_vector", "IV", "Tube", "z0", "zmin",
             "n1", "me", "cf", "rho_ar", "vm", "Alt"]
        )

        CsCd, CsCd_Out = CsCd_calc_France(
            h_torre, h_vector, IV, Tube,
            z0, zmin, n1, me, cf, rho_ar, vm, Alt, Pais
        )
        return CsCd, CsCd_Out


    elif Pais == "Spain":
        check_not_none(
            [h_torre, h_vector, IV, Tube, z0, zmin, n1, me, cf, rho_ar, vm, Alt],
            ["h_torre", "h_vector", "IV", "Tube", "z0", "zmin",
             "n1", "me", "cf", "rho_ar", "vm", "Alt"]
        )

        CsCd, CsCd_Out = CsCd_calc_Spain(
            h_torre, h_vector, IV, Tube,
            z0, zmin, n1, me, cf, rho_ar, vm, Alt, Pais
        )
        return CsCd, CsCd_Out

    elif Pais == "Spain_NB_AE":
        CsCd = 1.0
        CsCd_Out = [[]]
        return CsCd, CsCd_Out
    elif Pais == "Italy":
        check_not_none(
            [h_torre, h_vector, IV, Tube, z0, zmin, n1, me, cf, rho_ar, vm, Alt],
            ["h_torre", "h_vector", "IV", "Tube", "z0", "zmin",
             "n1", "me", "cf", "rho_ar", "vm", "Alt"]
        )

        CsCd, CsCd_Out = CsCd_calc_Spain(  # Itália usa o mesmo modelo
            h_torre, h_vector, IV, Tube,
            z0, zmin, n1, me, cf, rho_ar, vm, Alt, Pais
        )
        return CsCd, CsCd_Out


    elif Pais == "Germany":
        check_not_none(
            [h_torre, h_vector, IV, Tube, zmin, epsilon, n1, me, cf, rho_ar, vm],
            ["h_torre", "h_vector", "IV", "Tube", "zmin",
             "epsilon", "n1", "me", "cf", "rho_ar", "vm"]
        )

        CsCd, CsCd_Out = CsCd_calc_Germany(
            h_torre, h_vector, IV, Tube,
            zmin, epsilon, n1, me, cf, rho_ar, vm
        )
        return CsCd, CsCd_Out


    elif Pais == "Portugal-RSA":
        # Caso simplificado por regulamento
        CsCd = 1.0
        CsCd_Out = [[]]
        return CsCd, CsCd_Out

def CsCd_calc_Portugal(h_torre,h_vector,IV,Tube,z0,zmin,n1,me,cf,rho_ar,vm,Alt,Pais,Ocupation_CsCd):
    if Pais!="Portugal-RSA":
        T=600 #Pag 109
        Zs=0.6*h_torre
        iZs=find_closest_value_position(h_vector,Zs)
        #vb,z0,zmin=Zone(zone,Terrain,Pais)
        Lt=300
        Zt=200
        alpha=0.67+0.05*np.log(z0)
        L=Lt*((h_vector+Alt)/Zt)**alpha
        Lmin=Lt*(zmin/Zt)**alpha
        for i in range(len(L)):
            if L[i]<Lmin:
                L[i]=Lmin
        fl=n1*L/vm #Pag 107
        me=me
        cf_CsCd   = cf.copy()
        Tube_CsCd = Tube.copy()

        cf_CsCd[np.where(Ocupation_CsCd==1)]=1.2

        Tube_CsCd[np.where(Ocupation_CsCd==1)]=Tube[np.where(Ocupation_CsCd==1)]+2*(0.3+0.25)
        
        cf_ponderado   = np.mean(cf_CsCd)
        Tube_ponderado = np.mean(Tube_CsCd)
        Sl=6.8*fl/((1+10.2*fl)**(5/3))
        B2=(1+0.9*((Tube_ponderado+h_torre)/L[iZs])**0.63)**-1 #Pag 108
        niuh=4.6*h_torre*fl[iZs]/L[iZs]
        niub=4.6*Tube_ponderado*fl[iZs]/L[iZs]
        Rh=1/niuh-1/(2*niuh**2)*(1-np.exp(-2*niuh))
        Rb=1/niub-1/(2*niub**2)*(1-np.exp(-2*niub))
        delta=LogDecaiment(np.array([cf_ponderado]),rho_ar,vm[iZs],n1,me,Tube_ponderado)
        R2=np.pi**2/(2*delta)*Sl[iZs]*Rh*Rb #Pag 109
        v=n1*np.sqrt(R2/(B2+R2))
        
        Kp=np.sqrt(2*np.log(v*T))+0.6/(np.sqrt(2*np.log(v*T))) #Pag 109
        for i in range(len(h_vector)):
            if Kp<3:
                Kp=3
    
        Kp=Kp
        Cs=(1+7*IV[iZs]*np.sqrt(B2))/(1+7*IV[iZs])
        Cd=(1+2*Kp*IV[iZs]*np.sqrt(B2+R2))/(1+7*IV[iZs]*np.sqrt(B2))
        CsCd=Cs*Cd

        n1=n1
        
        CsCd_Out=[["n1",np.round(n1,3)],["Zs",np.round(Zs,3)],["vm(Zs)",np.round(vm[iZs],3)],["Iv(Zs)",np.round(IV[iZs],3)],["L(Zs)",np.round(L[iZs],3)],["Sl(Zs,n1)",np.round(Sl[iZs],3)],["fl(Zs,n1,x)",np.round(fl[iZs],3)],
              ["B^2",np.round(B2,3)],["R^2",np.round(R2,3)],["niuh",np.round(niuh,3)],["niub",np.round(niub,3)],["Rh",np.round(Rh,3)],["Rb",np.round(Rb,3)],["kp",np.round(Kp,3)],["v",np.round(v,3)],["Delta",np.round(delta,3)],["me",np.round(me,3)],
              ["cf",np.round(cf_ponderado,3)],["Tube",np.round(Tube_ponderado,3)],["Cs",np.round(Cs,3)],["Cd",np.round(Cd,3)],["CsCd",np.round(CsCd,3)]]
    else:
        CsCd=1
        CsCd_Out=[[]]

    return CsCd,CsCd_Out
def CsCd_calc_France(h_torre,h_vector,IV,Tube,z0,zmin,n1,me,cf,rho_ar,vm,Alt,Pais):
    if Pais!="Portugal-RSA":
        T=600 #Pag 109
        Zs=0.6*h_torre
        iZs=find_closest_value_position(h_vector,Zs)
        #vb,z0,zmin=Zone(zone,Terrain,Pais)
        Lt=300
        Zt=200
        alpha=0.67+0.05*np.log(z0)
        L=Lt*((h_vector+Alt)/Zt)**alpha
        Lmin=Lt*(zmin/Zt)**alpha
        for i in range(len(L)):
            if L[i]<Lmin:
                L[i]=Lmin
        fl=n1*L/vm #Pag 107
        me=me
    
        Sl=6.8*fl/((1+10.2*fl)**(5/3))
        B2=(1+0.9*((Tube[1]+h_torre)/L[iZs])**0.63)**-1 #Pag 108
        niuh=4.6*h_torre*fl[iZs]/L[iZs]
        niub=4.6*Tube[1]*fl[iZs]/L[iZs]
        Rh=1/niuh-1/(2*niuh**2)*(1-np.exp(-2*niuh))
        Rb=1/niub-1/(2*niub**2)*(1-np.exp(-2*niub))
        delta=LogDecaiment(cf,rho_ar,vm[iZs],n1,me,Tube[-1])
        R2=np.pi**2/(2*delta)*Sl[iZs]*Rh*Rb #Pag 109
        v=n1*np.sqrt(R2/(B2+R2))
    
        Kp=np.sqrt(2*np.log(v*T))+0.6/(np.sqrt(2*np.log(v*T))) #Pag 109
        for i in range(len(h_vector)):
            if Kp<3:
                Kp=3
    
        Kp=Kp
        Cs=(1+7*IV[iZs]*np.sqrt(B2))/(1+7*IV[iZs])
        Cd=(1+2*Kp*IV[iZs]*np.sqrt(B2+R2))/(1+7*IV[iZs]*np.sqrt(B2))
        CsCd=Cs*Cd

        n1=n1
        CsCd_Out=[["n1",np.round(n1,3)],["Zs",np.round(Zs,3)],["vm(Zs)",np.round(vm[iZs],3)],["Iv(Zs)",np.round(IV[iZs],3)],["L(Zs)",np.round(L[iZs],3)],["Sl(Zs,n1)",np.round(Sl[iZs],3)],["fl(Zs,n1,x)",np.round(fl[iZs],3)],
              ["B^2",np.round(B2,3)],["R^2",np.round(R2,3)],["niuh",np.round(niuh,3)],["niub",np.round(niub,3)],["Rh",np.round(Rh,3)],["Rb",np.round(Rb,3)],["kp",np.round(Kp,3)],["v",np.round(v,3)],["Delta",np.round(delta,3)],["me",np.round(me,3)],
              ["cf",np.round(min(cf),3)],["Cs",np.round(Cs,3)],["Cd",np.round(Cd,3)],["CsCd",np.round(CsCd,3)]]
    else:
        CsCd=1  
        CsCd_Out=[[]]  
    return CsCd,CsCd_Out
def CsCd_calc_Italy(h_torre,h_vector,IV,Tube,z0,zmin,n1,me,cf,rho_ar,vm,Alt,Pais):
    if Pais!="Portugal-RSA":
        T=600 #Pag 109
        Zs=0.6*h_torre
        iZs=find_closest_value_position(h_vector,Zs)
        #vb,z0,zmin=Zone(zone,Terrain,Pais)
        Lt=300
        Zt=200
        alpha=0.67+0.05*np.log(z0)
        L=Lt*((h_vector+Alt)/Zt)**alpha
        Lmin=Lt*(zmin/Zt)**alpha
        for i in range(len(L)):
            if L[i]<Lmin:
                L[i]=Lmin
        fl=n1*L/vm #Pag 107
        me=me
    
        Sl=6.8*fl/((1+10.2*fl)**(5/3))
        B2=(1+0.9*((Tube[1]+h_torre)/L[iZs])**0.63)**-1 #Pag 108
        niuh=4.6*h_torre*fl[iZs]/L[iZs]
        niub=4.6*Tube[1]*fl[iZs]/L[iZs]
        Rh=1/niuh-1/(2*niuh**2)*(1-np.exp(-2*niuh))
        Rb=1/niub-1/(2*niub**2)*(1-np.exp(-2*niub))
        delta=LogDecaiment(cf,rho_ar,vm[iZs],n1,me,Tube[-1])
        R2=np.pi**2/(2*delta)*Sl[iZs]*Rh*Rb #Pag 109
        v=n1*np.sqrt(R2/(B2+R2))
    
        Kp=np.sqrt(2*np.log(v*T))+0.6/(np.sqrt(2*np.log(v*T))) #Pag 109
        for i in range(len(h_vector)):
            if Kp<3:
                Kp=3
    
        Kp=Kp
        Cs=(1+7*IV[iZs]*np.sqrt(B2))/(1+7*IV[iZs])
        Cd=(1+2*Kp*IV[iZs]*np.sqrt(B2+R2))/(1+7*IV[iZs]*np.sqrt(B2))
        CsCd=Cs*Cd

        n1=n1
        CsCd_Out=[["n1",np.round(n1,3)],["Zs",np.round(Zs,3)],["vm(Zs)",np.round(vm[iZs],3)],["Iv(Zs)",np.round(IV[iZs],3)],["L(Zs)",np.round(L[iZs],3)],["Sl(Zs,n1)",np.round(Sl[iZs],3)],["fl(Zs,n1,x)",np.round(fl[iZs],3)],
              ["B^2",np.round(B2,3)],["R^2",np.round(R2,3)],["niuh",np.round(niuh,3)],["niub",np.round(niub,3)],["Rh",np.round(Rh,3)],["Rb",np.round(Rb,3)],["kp",np.round(Kp,3)],["v",np.round(v,3)],["Delta",np.round(delta,3)],["me",np.round(me,3)],
              ["cf",np.round(min(cf),3)],["Cs",np.round(Cs,3)],["Cd",np.round(Cd,3)],["CsCd",np.round(CsCd,3)]]
    else:
        CsCd=1  
        CsCd_Out=[[]]  
    return CsCd,CsCd_Out
def CsCd_calc_Spain(h_torre,h_vector,IV,Tube,z0,zmin,n1,me,cf,rho_ar,vm,Alt,Pais):
    if Pais!="Portugal-RSA":
        T=600 #Pag 109
        Zs=0.6*h_torre
        iZs=find_closest_value_position(h_vector,Zs)
        #vb,z0,zmin=Zone(zone,Terrain,Pais)
        Lt=300
        Zt=200
        alpha=0.67+0.05*np.log(z0)
        L=Lt*((h_vector+Alt)/Zt)**alpha
        Lmin=Lt*(zmin/Zt)**alpha
        for i in range(len(L)):
            if L[i]<Lmin:
                L[i]=Lmin
        fl=n1*L/vm #Pag 107
        me=me
    
        Sl=6.8*fl/((1+10.2*fl)**(5/3))
        B2=(1+0.9*((Tube[1]+h_torre)/L[iZs])**0.63)**-1 #Pag 108
        niuh=4.6*h_torre*fl[iZs]/L[iZs]
        niub=4.6*Tube[1]*fl[iZs]/L[iZs]
        Rh=1/niuh-1/(2*niuh**2)*(1-np.exp(-2*niuh))
        Rb=1/niub-1/(2*niub**2)*(1-np.exp(-2*niub))
        delta=LogDecaiment(cf,rho_ar,vm[iZs],n1,me,Tube[-1])
        R2=np.pi**2/(2*delta)*Sl[iZs]*Rh*Rb #Pag 109
        v=n1*np.sqrt(R2/(B2+R2))
    
        Kp=np.sqrt(2*np.log(v*T))+0.6/(np.sqrt(2*np.log(v*T))) #Pag 109
        for i in range(len(h_vector)):
            if Kp<3:
                Kp=3
    
        Kp=Kp
        Cs=(1+7*IV[iZs]*np.sqrt(B2))/(1+7*IV[iZs])
        Cd=(1+2*Kp*IV[iZs]*np.sqrt(B2+R2))/(1+7*IV[iZs]*np.sqrt(B2))
        CsCd=Cs*Cd

        n1=n1
        CsCd_Out=[["n1",np.round(n1,3)],["Zs",np.round(Zs,3)],["vm(Zs)",np.round(vm[iZs],3)],["Iv(Zs)",np.round(IV[iZs],3)],["L(Zs)",np.round(L[iZs],3)],["Sl(Zs,n1)",np.round(Sl[iZs],3)],["fl(Zs,n1,x)",np.round(fl[iZs],3)],
              ["B^2",np.round(B2,3)],["R^2",np.round(R2,3)],["niuh",np.round(niuh,3)],["niub",np.round(niub,3)],["Rh",np.round(Rh,3)],["Rb",np.round(Rb,3)],["kp",np.round(Kp,3)],["v",np.round(v,3)],["Delta",np.round(delta,3)],["me",np.round(me,3)],
              ["cf",np.round(min(cf),3)],["Cs",np.round(Cs,3)],["Cd",np.round(Cd,3)],["CsCd",np.round(CsCd,3)]]
    else:
        CsCd=1  
        CsCd_Out=[[]]  
    return CsCd,CsCd_Out


def CsCd_calc_Germany(h_torre,h_vector,Iv,Tube,zmin,epsilon,n1,me,cf,rho_ar,vm):
    
    T=600 #Pag 109
    Zs=0.6*h_torre
    iZs=find_closest_value_position(h_vector,Zs)
    Lt=300
    Zt=200
    L=300*(h_vector/300)**epsilon
    izmin=h_vector<zmin
    L[izmin]=300*(zmin/300)**epsilon
    fl=n1*L/vm #Pag 107
    Sl=6.8*fl/((1+10.2*fl)**(5/3))
    B2=(1+0.9*((Tube[1]+h_torre)/L[iZs])**0.63)**-1 #Pag 108
    niuh=4.6*h_torre*fl[iZs]/L[iZs]
    niub=4.6*Tube[1]*fl[iZs]/L[iZs]
    Rh=1/niuh-1/(2*niuh**2)*(1-np.exp(-2*niuh))
    Rb=1/niub-1/(2*niub**2)*(1-np.exp(-2*niub))
    delta=LogDecaiment(cf,rho_ar,vm[iZs],n1,me,Tube[-1])
    R2=np.pi**2/(2*delta)*Sl[iZs]*Rh*Rb #Pag 109
    v=n1*np.sqrt(R2/(B2+R2))
    
    Kp=np.sqrt(2*np.log(v*T))+0.6/(np.sqrt(2*np.log(v*T))) #Pag 109
    for i in range(len(h_vector)):
        if Kp<3:
            Kp=3
    
    CsCd=(1+2*Kp*Iv[iZs]*np.sqrt(B2+R2))/(1+6*Iv[iZs])


    CsCd_Out=[["n1",np.round(n1,3)],["Zs",np.round(Zs,3)],["vm(Zs)",np.round(vm[iZs],3)],["Iv(Zs)",np.round(Iv[iZs],3)],["L(Zs)",np.round(L[iZs],3)],["Sl(Zs,n1)",np.round(Sl[iZs],3)],["fl(Zs,n1,x)",np.round(fl[iZs],3)],
              ["B^2",np.round(B2,3)],["R^2",np.round(R2,3)],["niuh",np.round(niuh,3)],["niub",np.round(niub,3)],["Rh",np.round(Rh,3)],["Rb",np.round(Rb,3)],["kp",np.round(Kp,3)],["v",np.round(v,3)],["Delta",np.round(delta,3)],["me",np.round(me,3)],
              ["cf",np.round(min(cf),3)],["CsCd",np.round(CsCd,3)]]
    return CsCd,CsCd_Out