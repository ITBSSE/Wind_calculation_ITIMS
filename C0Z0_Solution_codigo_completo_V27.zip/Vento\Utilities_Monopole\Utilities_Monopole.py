import numpy as np

def AreaInercia(de,lado,t):
    #dm=de-t
    dm=de
    match lado:
        case 0:
            Area=3.14*dm*t
            Inercia=0.393*(de-t)**3*t
        case 18:
            Area=lado*np.tan(np.pi/lado)*dm*t
            Inercia=0.393*(de-t)**3*t
        case 20:
            Area=lado*np.tan(np.pi/lado)*dm*t
            Inercia=0.393*(de-t)**3*t            
        case 16:
            Area=3.19*dm*t
            Inercia=0.403*(de-t)**3*t
        case 12:
            Area=3.22*dm*t
            Inercia=0.411*(de-t)**3*t
        case 8:
            Area=3.32*dm*t
            Inercia=0.438*(de-t)**3*t
        case 6:
            Area=3.46*dm*t**3
            Inercia=0.481*(de-t)**3*t
        case 4:
            Area=4*dm*t**3
            Inercia=0.666*(de-t)**3*t
        case Else:
            print("Error")
    return Area,Inercia

def Rayleigh (E,Inercia,h_inv,Massa):
    Momento=CalculoMomento(h_inv,Massa)
    fi=Momento/(E[::-1]*Inercia[::-1])
    hx=np.zeros(len(h_inv))
    for i in range(1,len(h_inv)):
        hx[i]=hx[i-1]+h_inv[i-1]-h_inv[i]
    int1=np.zeros(len(fi))
    for i in range(len(fi)):
        for k in range(i,len(fi)-1):
            int1[i]=int1[i]+(fi[k]+fi[k+1])/2*(hx[k+1]-hx[k])
    int2=np.zeros(len(fi))
    
    for i in range(len(fi)):
        for k in range(i,len(fi)-1):
            int2[i]=int2[i]+(int1[k]+int1[k+1])/2*(hx[k+1]-hx[k])
    mode=int2/np.max(int2)
    Massa=Massa[::-1]
    Fidi=Massa*int2
    Fidi2=Massa*int2*int2
    
    n1=np.sqrt(9.81*sum(Fidi)/sum(Fidi2))/(2*np.pi)
    mode=mode[::-1]
    return mode,n1

def CalculoMomento(h_inv,Massa):

    Massa=Massa[::-1]
    
    h_med=np.zeros(len(h_inv))
    for i in range(len(h_inv)-1):
        h_med[i]=(h_inv[i]+h_inv[i+1])/2
    Moment=np.zeros(len(h_inv))
    for  i in range(len(h_inv)):
        Moment[i]=np.sum((h_med[:i]-h_inv[i])*Massa[:i])
        #for k in range(len(h_inv)):
        #    if h_med[k]>h_inv[i]:     
        #       Moment[i]=Moment[i]+(h_med[k]-h_inv[i])*Massa[k]*9.81
    Moment=Moment*9.81

    return Moment

def massa_equivalent(m_vector,mode,h_vector):
    #Pag.150 ###A integração é feita pelo pelo modo
    Num=m_vector*mode**2
    Den=mode**2
    SumDen=0
    SumNum=0
    for i in range(len(h_vector)-1):
        SumNum=SumNum+(Num[i]+Num[i+1])/2*(mode[i+1]-mode[i])
        SumDen=SumDen+(Den[i]+Den[i+1])/2*(mode[i+1]-mode[i])
    me=SumNum/SumDen
    return me
