import numpy as np
from Wind.Velocidade_Media import Velocidade_media
from Wind.Iv_Calc import Iv_calc
from Utilities_Monopole.Check_None import check_not_none
from Utilities_Monopole.Utilities import Interpolation, LoadMatrix,ReturnValue
import os
from Wind.calculoc0 import calculoc0_Germany
def Pressure_wind(Pais,h_vector=None,vb=None,z0=None,zmin=None,Alt=None,rho_ar=None,c0=None,Zona=None,
                  Terrain=None,Altitude=None,Tipoc0=None,Alt_col=None,Lu=None,Ld=None,Xtopo=None,c0calc=None,
                  Tipo=None,vbmap=None,dist=None,hdis=None,h_torre=None,dist_Town=None):
    ###Código para o calculo da pressão do vento
    if Pais in ["Portugal", "Portugal-RSA"]:
        check_not_none(
            [h_vector, vb, z0, zmin, Alt, Pais, rho_ar, c0],
            ["h_vector", "vb", "z0", "zmin", "Alt", "Pais", "rho_ar", "c0"]
        )

        Wind_Pressure = Pressure_wind_Portugal(
            h_vector, vb, z0, zmin, Alt, Pais, rho_ar, c0
        )

        return Wind_Pressure
    elif Pais == "France":
        check_not_none(
            [h_vector, vb, z0, zmin, Alt, Pais, rho_ar, c0],
            ["h_vector", "vb", "z0", "zmin", "Alt", "Pais", "rho_ar", "c0"]
        )
        Wind_Pressure = Pressure_wind_France(
            h_vector, vb, z0, zmin, Alt, Pais, rho_ar, c0
        )
        return Wind_Pressure
    elif Pais == "Spain":
        check_not_none(
            [h_vector, vb, z0, zmin, Alt, Pais, rho_ar, c0],
            ["h_vector", "vb", "z0", "zmin", "Alt", "Pais", "rho_ar", "c0"]
        )
        Wind_Pressure = Pressure_wind_Spain(
            h_vector, vb, z0, zmin, Alt, Pais, rho_ar, c0
        )
        return Wind_Pressure
    elif Pais =="Spain_NB_AE":
        check_not_none(
            [h_vector,  Pais, rho_ar],
            ["h_vector", "Pais", "rho_ar"]
        )
        Wind_Pressure,vm = Pressure_wind_Spain_NB_AE(
            h_vector, Pais, rho_ar
        )
        return Wind_Pressure,vm
    elif Pais == "Italy":
        check_not_none(
            [h_vector, vb, z0, zmin, Alt, Pais, rho_ar, c0],
            ["h_vector", "vb", "z0", "zmin", "Alt", "Pais", "rho_ar", "c0"]
        )
        Wind_Pressure = Pressure_wind_Italy(
            h_vector, vb, z0, zmin, Alt, Pais, rho_ar, c0
        )
        return Wind_Pressure
    elif Pais == "Germany":
        check_not_none(
            [Zona, Terrain, Altitude, h_vector, rho_ar, Tipoc0, Alt_col, Lu, Ld, Xtopo, c0calc],
            ["Zona", "Terrain", "Altitude", "h_alt", "rho_ar", "Tipoc0",
            "Alt_col", "Lu", "Ld", "Xtopo", "c0calc"]
        )
        Wind_Pressure, Iv, vm, zmin, epsilon, c0 = Pressure_wind_Germany(
            Zona, Terrain, Altitude, h_vector, rho_ar,
            Tipoc0, Alt_col, Lu, Ld, Xtopo, c0calc
        )
        return Wind_Pressure, Iv, vm, zmin, epsilon, c0
    elif Pais=="UK":
        check_not_none(
            [h_vector, Tipo,vbmap,Altitude,dist,hdis,h_torre,dist_Town,c0,c0calc],
            ["h_vector", "Tipo","vbmap","Altitude","dist","hdis","h_torre","dist_Town","c0","c0Calc"]
        )        
        Wind_Pressure,Iv,vm=Pressure_wind_UK(h_vector, Tipo,vbmap,Altitude,dist,hdis,h_torre,dist_Town,c0,c0calc)
    
        return Wind_Pressure, Iv, vm
def Pressure_wind_France(h_vector,vb,z0,zmin,Alt,Pais,rho_ar,c0):
    #Portugal_Eurocode
    Wind_Pressure=np.zeros(len(h_vector))
    vm=Velocidade_media(h_vector,vb,z0,zmin,Pais,c0)
    IV=Iv_calc(h_vector, z0,zmin,Alt,Pais,c0)
    Wind_Pressure=(1+7*IV)*0.5*rho_ar*vm**2
    return Wind_Pressure
def Pressure_wind_Italy(h_vector,vb,z0,zmin,Alt,Pais,rho_ar,c0):
    #Portugal_Eurocode
    Wind_Pressure=np.zeros(len(h_vector))
    vm=Velocidade_media(h_vector,vb,z0,zmin,Pais,c0)
    IV=Iv_calc(h_vector, z0,zmin,Alt,Pais,c0)
    Wind_Pressure=(1+7*IV)*0.5*rho_ar*vm**2
    return Wind_Pressure
def Pressure_wind_Portugal(h_vector,vb,z0,zmin,Alt,Pais,rho_ar,c0):
    #Portugal_Eurocode
    Wind_Pressure=np.zeros(len(h_vector))
    vm=Velocidade_media(h_vector,vb,z0,zmin,Pais,c0)
    if Pais!="Portugal-RSA":
        IV=Iv_calc(h_vector, z0,zmin,Alt,Pais,c0)
        Wind_Pressure=(1+7*IV)*0.5*rho_ar*vm**2
    else:
        if vb==30:
            vraj=(vm/1.1+14)*1.1
        else:
            vraj=vm+14
        Wind_Pressure=0.613*vraj**2
    return Wind_Pressure
def Pressure_wind_Spain(h_vector,vb,z0,zmin,Alt,Pais,rho_ar,c0):
    #Portugal_Eurocode
    Wind_Pressure=np.zeros(len(h_vector))
    vm=Velocidade_media(h_vector,vb,z0,zmin,Pais,c0)
    IV=Iv_calc(h_vector, z0,zmin,Alt,Pais,c0)
    Wind_Pressure=(1+7*IV)*0.5*rho_ar*vm**2
    return Wind_Pressure
def Pressure_wind_Spain_NB_AE(h_vector,Pais,rho_ar):
    #Spain NB_AE
    vm=150*1000/3600*np.ones(len(h_vector))
    Wind_Pressure=0.5*rho_ar*vm**2
    return Wind_Pressure,vm
def Pressure_wind_Germany(Zona,Terreno,A,h_vector,rho_ar,Tipo,Alt_colina,Lu,Ld,Xtopo,c0calc):
    if Zona=="WZ 1": #Germany NA pag17
        vb0=22.5
    elif Zona=="WZ 2":
        vb0=25
    elif Zona=="WZ 3":
        vb0=27.5
    else:
        vb0=30
    if A>800:
        reduc=0.2+A/1000
    else:
        reduc=1
    vb=vb0*reduc 
    qb=0.5*rho_ar*vb**2
    if Terreno!="Inland" and Terreno!="Coast-North Sea" and Terreno!="Coast-Baltic Sea":
        if Terreno=="I":
            z0=0.01
            alpha=0.12
            zmin=2
            c1=1.18
            c2=0.97
            c3=0.14
            c4=0.17
            c5=2.6
            c6=0.19
            c7=1.9
            epsilon=0.13
        elif Terreno=="II":
            z0=0.05
            alpha=0.16
            zmin=4
            c1=1
            c2=0.86
            c3=0.19
            c4=0.22
            c5=2.1
            c6=0.24
            c7=1.7
            epsilon=0.26
        elif Terreno=="III":
            z0=0.3
            alpha=0.22
            zmin=8
            c1=0.77
            c2=0.73
            c3=0.28
            c4=0.29
            c5=1.6
            c6=0.31
            c7=1.5
            epsilon=0.37
        elif Terreno=="IV":
            z0=1.05
            alpha=0.3
            zmin=16
            c1=0.56
            c2=0.64
            c3=0.43
            c4=0.37
            c5=1.1
            c6=0.4
            c7=1.3
            epsilon=0.46

        vm=c1*vb*(h_vector/10)**alpha
        indicez=h_vector<zmin
        vm[indicez]=c2*vb
        Iv=c3*(h_vector/10)**-alpha
        Iv[indicez]=c4
        Wind_Pressure=c5*qb*(h_vector/10)**c6
        Wind_Pressure[indicez]=c7*qb
    else:
        if Terreno=="Inland":
            zmin=7
            c1=1
            c2=0.16
            c3=0.86
            c4=0.25
            c5=0.79
            c6=0.19
            c7=-0.16
            c8=0.22
            c9=-0.25
            c10=0.24
            epsilon=0.26 #NA Germany Pag26 podemos considerar como II
            Wind_Pressure=2.1*qb*(h_vector/10)**0.24
            indicez50=h_vector<50
            indicez7=h_vector<7
            Wind_Pressure[indicez50]=1.7*qb*(h_vector[indicez50]/10)**0.37
            Wind_Pressure[indicez7]=1.5*qb
        elif Terreno=="Coast-Baltic Sea" or Terreno=="Coast-North Sea":
            zmin=4
            c1=1.18
            c2=0.12
            c3=1.1
            c4=0.165
            c5=0.95
            c6=0.14
            c7=-0.12
            c8=0.15
            c9=-0.165
            c10=0.17
            epsilon=0.13
            if Terreno=="Coast-Baltic Sea":
                Wind_Pressure=2.6*qb*(h_vector/10)**0.19
                indicez50=h_vector<50
                indicez4=h_vector<4
                Wind_Pressure[indicez50]=2.3*qb*(h_vector[indicez50]/10)**0.27
                Wind_Pressure[indicez4]=1.8*qb
            else:
                Wind_Pressure=1.5*qb*(h_vector/10)**0.19
                indicez2=h_vector<2
                Wind_Pressure[indicez2]=1100

        vm=c1*vb*(h_vector/10)**c2
        indicez50=h_vector<50
        indicez=h_vector<zmin
        vm[indicez50]=c3*(h_vector[indicez50]/10)**c4*vb
        vm[indicez]=c5*vb
        Iv=c6*(h_vector/10)**c7
        Iv[indicez50]=c8*(h_vector[indicez50]/10)**c9
        Iv[indicez]=c10
    if c0calc=="Sim":
        c0=calculoc0_Germany(h_vector,Tipo,Alt_colina,Lu,Ld,Xtopo,zmin)
    else:
        c0=np.ones(len(h_vector))
    for i in range(len(h_vector)):
        if c0[i]!=1:
            vm=vm*c0
            Iv=Iv/c0
            Wind_Pressure=rho_ar*0.5*vm**2*(1+6*Iv)
    return Wind_Pressure,Iv,vm,zmin,epsilon,c0
def Pressure_wind_UK(h_vector, Tipo,vbmap,A,dist,hdis,h_torre,dist_Town,c0,c0Calc):
    # Get the current file path
    current_path = os.path.realpath(__file__)

    
    Zs=0.6*h_torre
    #A-Altitude
    #havealtura media
    #dist ##distancia á costa em Km
    #x-distancia até á construção
    if Zs<=10:
        cAlt=1+0.001*A
    else:
        cAlt=1+0.001*A*(10/Zs)**0.2
    vb=vbmap*cAlt
    
    file_name="MatrizUK.xlsx" #As matrizes estão todas no mesmo ficheiro, mas em folhas diferentes
    cr_matrix=LoadMatrix(os.path.join(os.path.dirname(current_path), file_name),"Cr(z)")
    cr=ReturnValue(cr_matrix,h_vector,hdis,dist)
    Iv_matrix=LoadMatrix(os.path.join(os.path.dirname(current_path), file_name),"Iv(z)")
    Iv=ReturnValue(Iv_matrix,h_vector,hdis,dist)
    if Tipo=="Town-III" or Tipo=="Town-IV":
        #calculo de KI,T,cr,T
        KiT_matrix=np.transpose(LoadMatrix(os.path.join(os.path.dirname(current_path), file_name),"kiT(z)"))
        KIT=ReturnValue(KiT_matrix,h_vector,hdis,dist_Town)
        crT_matrix=np.transpose(LoadMatrix(os.path.join(os.path.dirname(current_path), file_name),"crT(z)"))
        crT=ReturnValue(crT_matrix,h_vector,hdis,dist_Town)
    else:
        KIT=1
        crT=1
    if c0Calc=="Sim":
        indice50=h_vector<=50
        vm=vb*c0*cr*crT
        Iv=Iv*KIT/c0
        WindPressure=(1+(3*Iv))**2*0.613*vm**2
        WindPressureaux=(1+(3*Iv*c0))**2*0.613*(vm/c0)**2
        WindPressure[indice50]=WindPressureaux[indice50]*((c0[indice50]+0.6)/1.6)**2
    else:
        vm=vb*cr*crT
        WindPressure=(1+(3*Iv*KIT))**2*0.613*vm**2
        Iv=Iv*KIT
    KIT=KIT
    crT=crT
    return WindPressure,Iv,vm