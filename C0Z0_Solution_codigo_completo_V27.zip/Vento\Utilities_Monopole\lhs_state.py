import numpy as np

_pool = None       # ndarray shape (n_amostras, d)
_sample_idx = 0
_var_counter = 0

# Controla quais variáveis são aleatorizadas.
# Chaves disponíveis:
#   'fy'           — resistência do aço (Normal)
#   'Mlig'         — capacidade das ligações flangeadas (Normal)
#   'thickness'    — espessura de cada troço (Normal por troço, independente)
#   'E'            — módulo de Young (Normal)
#   'massa_antenas'— multiplicador das massas das antenas (Uniforme [0.9, 1.1])
_rand_config = {
    'fy':            True,
    'Mlig':          True,
    'thickness':     True,
    'E':             True,
    'massa_antenas': True,
    'alpha_flange':  True,   # factor de rigidez ZLE por ligação e direcção (Normal)
    'wind_pressure':  True,   # multiplicador lognormal da pressão de vento (média 0.8, σ 0.2)
    'CrEstatistico':  True,   # multiplicador lognormal directo do vector de pressão (média 0.8, σ 0.12)
    'cg':             True,   # factor de rajada estatístico lognormal (média 1, σ 0.15)
    'cf':             True,   # multiplicador lognormal do coeficiente de força do tubo (média 1, σ 0.125)
    'cscd':           True,   # multiplicador lognormal do CsCd (média 1, σ 0.15)
    'lognorm_antenas': True,  # multiplicador lognormal independente por antena (massa+área, média 1, CoV 0.20)
    'c0':             True,   # multiplicador lognormal do factor de orografia c0 (média 1, CoV 0.10)
}


def init(pool: np.ndarray):
    """Recebe a matriz LHS (n_amostras × d) gerada externamente e reinicia contadores."""
    global _pool, _sample_idx, _var_counter
    _pool = pool
    _sample_idx = 0
    _var_counter = 0


def set_sample(i: int):
    """Define qual a linha LHS activa (chamada antes de cada Calc())."""
    global _sample_idx, _var_counter
    _sample_idx = i
    _var_counter = 0


def next_quantile() -> float:
    """Devolve o próximo quantil [0,1] da linha LHS activa.
    Se o pool não estiver inicializado (modo determinístico) devolve uniforme aleatório."""
    global _var_counter
    if _pool is None:
        return float(np.random.uniform())
    q = float(_pool[_sample_idx, _var_counter % _pool.shape[1]])
    _var_counter += 1
    return q


def set_rand_config(config: dict):
    """Actualiza quais variáveis são aleatorizadas. Passa apenas as chaves a alterar."""
    global _rand_config
    _rand_config = {**_rand_config, **config}


def reset_rand_config():
    """Repõe a configuração padrão (todas as variáveis aleatorizadas)."""
    global _rand_config
    _rand_config = {
        'fy':            True,
        'Mlig':          True,
        'thickness':     True,
        'E':             True,
        'massa_antenas': True,
        'alpha_flange':  True,
        'wind_pressure':  True,
        'CrEstatistico':  True,
        'cg':             True,
        'cf':             True,
        'cscd':           True,
        'lognorm_antenas': True,
        'c0':             True,
    }


def is_rand(var: str) -> bool:
    """Devolve True se a variável 'var' deve ser aleatorizada."""
    return bool(_rand_config.get(var, True))
