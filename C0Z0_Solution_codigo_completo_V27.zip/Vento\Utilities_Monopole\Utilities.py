import pandas as pd
import numpy as np

def Interpolation(x1,y1,x2,y2,xref):
    y=y1+(y2-y1)/(x2-x1)*(xref-x1)
    return y
def LoadMatrix(filename,SheetName):
    # Read the data into a pandas DataFrame
    # Specify the sheet name if your data is not in the first sheet
    df = pd.read_excel(filename, SheetName)
    Matrix=np.array(df.values)

    return Matrix
def AreaInercia(de,lado,t):
    #dm=de-t
    dm=de
    match lado:
        case 0:
            Area=3.14*dm*t
            Inercia=0.393*(de-t)**3*t
        case 18:
            Area=lado*np.tan(np.pi/lado)*dm*t
            Inercia=0.393*(de-t)**3*t
        case 20:
            Area=lado*np.tan(np.pi/lado)*dm*t
            Inercia=0.393*(de-t)**3*t            
        case 16:
            Area=3.19*dm*t
            Inercia=0.403*(de-t)**3*t
        case 12:
            Area=3.22*dm*t
            Inercia=0.411*(de-t)**3*t
        case 8:
            Area=3.32*dm*t
            Inercia=0.438*(de-t)**3*t
        case 6:
            Area=3.46*dm*t
            Inercia=0.481*(de-t)**3*t
        case 4:
            Area=4*dm*t
            Inercia=0.666*(de-t)**3*t
        case Else:
            print("Error")
    return Area,Inercia
def find_closest_value_position(vector, reference_value):
    closest_position = None
    min_difference = float('inf')  # Initialize with positive infinity
    
    for i, value in enumerate(vector):
        difference = abs(value - reference_value)
        if difference < min_difference:
            min_difference = difference
            closest_position = i
    
    return closest_position
def ReturnValue(Matrix,h_vector,hdis,dist):
    if dist<min(Matrix[1:,0]):
        i_closer=1
        dist=min(Matrix[1:,0])
    elif dist>max(Matrix[1:,0]):
        i_closer=Matrix.shape[0]-1
        dist=max(Matrix[1:,0])
    else:
        i_closer=find_closest_value_position(Matrix[1:,0],dist)
    if dist>=Matrix[i_closer,0]:
        i2_closer=i_closer+1
    else:
        i2_closer=i_closer-1
    dif=h_vector-hdis
    Out=np.zeros(len(h_vector))
    for j in range(len(h_vector)):
        if dif[j]<min(Matrix[0,1:]):
            j_closer=1
            dif[j]=min(Matrix[0,1:])
        elif dif[j]>max(Matrix[0,1:]):
            j_closer=Matrix.shape[1]-1
            dif[j]=max(Matrix[0,1:])
        else:
            j_closer=find_closest_value_position(Matrix[0,:],dif[j])
        if dif[j]>=Matrix[0,j_closer]:
            j2_closer=j_closer+1
        else:
            j2_closer=j_closer-1
        Out[j]=Interpolation(Matrix[0,j_closer],Matrix[i_closer,j_closer],Matrix[0,j2_closer],Matrix[i2_closer,j2_closer],dif[j])    
           
    return Out

def loaddistribution(y,y1,y2,load):
    ratio=(y-y1)/(y2-y1)
    load1=load*(1-ratio)
    load2=load*ratio
    return load1,load2
def atualizar_area_tip(caminho_csv, Aincrease):
    with open(caminho_csv, "r", encoding="utf-8") as f:
        linhas = f.readlines()
    for i, linha in enumerate(linhas):
        if linha.startswith("Available area at top (m²),NA"):
            linhas[i] = f"Available area at top (m²),{f2(Aincrease)}\n"
            break
    with open(caminho_csv, "w", encoding="utf-8") as f:
        f.writelines(linhas)

def adicionar_linha_Aincrease(caminho_csv, Aincrease):

    with open(caminho_csv, "a", encoding="utf-8") as f:
        f.write(f"Aincrease, {f2(Aincrease)}\n")
def adicionar_linha(caminho_csv, Line):

    with open(caminho_csv, "a", encoding="utf-8") as f:
        f.write(f"{Line}\n")
def atualizar_primeira_linha_Aincrease(caminho_txt, Aincrease):
    with open(caminho_txt, "r", encoding="utf-8") as f:
        linhas = f.readlines()

    if not linhas:
        raise ValueError("O ficheiro está vazio.")

    partes = linhas[0].strip().split(";")



    partes[-1] = str(np.round(Aincrease,2))
    linhas[0] = ";".join(partes) + "\n"

    with open(caminho_txt, "w", encoding="utf-8") as f:
        f.writelines(linhas)

def f2(x):
    if x is None:
        return "NA"
    if isinstance(x, str):
        return x
    if isinstance(x, (int, float)) and not np.isnan(x):
        return f"{x:.2f}"
    return "NA"
def f1(x):
    if x is None:
        return "NA"
    if isinstance(x, str):
        return x
    if isinstance(x, (int, float)) and not np.isnan(x):
        return f"{x:.1f}"
    return "NA"
def f3(x):
    if x is None:
        return "NA"
    if isinstance(x, str):
        return x
    if isinstance(x, (int, float)) and not np.isnan(x):
        return f"{x:.3f}"
    return "NA"
def f0(x):
    if x is None:
        return "NA"
    if isinstance(x, str):
        return x
    if isinstance(x, (int, float)) and not np.isnan(x):
        return f"{x:.0f}"
    return "NA"