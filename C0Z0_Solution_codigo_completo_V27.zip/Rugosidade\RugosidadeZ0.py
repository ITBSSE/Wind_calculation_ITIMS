import rasterio
import rasterio.features
import numpy as np
import shapely.geometry as geom
import shapely.ops as ops
import math
import json
import matplotlib
matplotlib.use("Agg")   # servidor Linux sem display / .exe onefile
import matplotlib.pyplot as plt
from pyproj import Transformer
from matplotlib.patches import Patch, Polygon as MplPolygon
import geopandas as gpd
import contextily as ctx
import os
import requests
import urllib.parse
import re
import sys
from matplotlib.collections import PatchCollection
from rasterio.transform import Affine
from rasterio.mask import mask
from rasterio.merge import merge as rasterio_merge
from collections import Counter
from shapely.geometry import Point
import time
from datetime import datetime, timedelta
from statistics import mean, median, mode, stdev

def configurar_gdal_pyinstaller():
    """
    Configura GDAL_DATA para PyInstaller para resolver warnings de gdalvrt.xsd
    """
    if getattr(sys, 'frozen', False):
        try:
            possible_paths = [
                os.path.join(sys._MEIPASS, 'rasterio', 'gdal_data'),
                os.path.join(sys._MEIPASS, 'Library', 'share', 'gdal'),
                os.path.join(sys._MEIPASS, 'share', 'gdal'),
                os.path.join(sys._MEIPASS, 'gdal'),
                os.path.join(sys._MEIPASS, 'proj_data'),
                os.path.join(sys._MEIPASS, 'Library', 'share')
            ]
            
            gdal_data_found = False
            for gdal_path in possible_paths:
                if os.path.exists(gdal_path):
                    os.environ['GDAL_DATA'] = gdal_path
                    gdal_data_found = True
                    break
            
            proj_lib_path = os.path.join(sys._MEIPASS, 'Library', 'share', 'proj')
            if os.path.exists(proj_lib_path):
                os.environ['PROJ_LIB'] = proj_lib_path
            
            if not gdal_data_found:
                pass
                
        except Exception as e:
            print(f"Erro ao configurar GDAL_DATA: {e}")

configurar_gdal_pyinstaller()


def _adicionar_mapa_base(ax, alpha=0.6, attribution=False, **kwargs):
    """Mapa de fundo -- SEMPRE a mesma fonte em todos os mapas da solucao
    (Esri.WorldGrayCanvas: a unica que nao pede API key nem bloqueia).
    Se a rede da maquina falhar (proxy da hosting, DNS filtrado, etc.),
    desiste em silencio -- o mapa sai sem fundo, mas o calculo
    (z0/co/pressao) nao e afetado."""
    try:
        ctx.add_basemap(ax, source=ctx.providers.Esri.WorldGrayCanvas,
                        alpha=alpha, attribution=attribution, **kwargs)
        return True
    except Exception as e:
        print(f"    [AVISO] mapa sem fundo (contextily): {e}")
        return False

class AerodynamicCalculationLogger:
    """
    Classe para registrar todos os processos de cálculo dos parâmetros aerodinâmicos
    (wk e z0) incluindo valores das variáveis, cálculos intermediários e resultados finais.
    """
    
    def __init__(self, pasta_saida):
        self.pasta_saida = pasta_saida
        self.log_data = {
            "metadata": {
                "created_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                "description": "Log detalhado dos cálculos de parâmetros aerodinâmicos (Wk e Z0)",
                "version": "1.0"
            },
            "calculation_steps": [],
            "final_results": {}
        }
        self.step_counter = 1
    
    def log_step(self, step_name, description, data=None):
        """Registra um passo do cálculo"""
        step = {
            "step_number": self.step_counter,
            "description": description,
            "data": data or {}
        }
        self.log_data["calculation_steps"].append(step)
        self.step_counter += 1
    
    def log_variable(self, step_name, var_name, var_value, description=""):
        """Registra o valor de uma variável específica"""
        self.log_step(f"{step_name}_variable", f"Variável {var_name}: {description}", {
            "variable_name": var_name,
            "variable_value": var_value,
            "variable_type": type(var_value).__name__,
            "description": description
        })
    
    def log_calculation(self, step_name, formula, inputs, result, description=""):
        """Registra um cálculo específico"""
        self.log_step(f"{step_name}_calculation", description, {
            "formula": formula,
            "inputs": inputs,
            "result": result
        })
    
    def log_z0_calculation(self, pixel_id, pixel_type, input_data, z0_result, formula_used):
        """Registra cálculo específico de Z0 para um pixel"""
        calc_data = {
            "pixel_id": pixel_id,
            "pixel_type": pixel_type,
            "input_data": input_data,
            "z0_result": z0_result,
            "formula_used": formula_used,
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        }
        
        self.log_step(f"z0_pixel_{pixel_id}", f"Cálculo Z0 para pixel {pixel_id} ({pixel_type})", calc_data)
    
    def log_wk_calculation(self, sector_id, area_m2, raio_medio, L, wk_result):
        """Registra cálculo específico de Wk para um setor"""
        exp_value = math.exp(-raio_medio / L) if L > 0 else 0
        
        calc_data = {
            "sector_id": sector_id,
            "area_m2": area_m2,
            "raio_medio": raio_medio,
            "L_parameter": L,
            "exp_calculation": {
                "formula": "exp(-raio_medio/L)",
                "raio_medio": raio_medio,
                "L": L,
                "division": -raio_medio / L if L > 0 else 0,
                "exp_result": exp_value
            },
            "wk_calculation": {
                "formula": "area_m2 * exp(-raio_medio/L)",
                "area_m2": area_m2,
                "exp_value": exp_value,
                "wk_result": wk_result
            }
        }
        
        self.log_step(f"wk_{sector_id}", f"Cálculo Wk para setor {sector_id}", calc_data)
        return calc_data
    
    def log_final_sector_calculation(self, sector_name, total_wk, soma_wk_ln_z0, ln_z0_setor, z0_setor_final):
        """Registra cálculo final de um setor"""
        calc_data = {
            "sector_name": sector_name,
            "total_wk": total_wk,
            "soma_wk_ln_z0": soma_wk_ln_z0,
            "ln_z0_calculation": {
                "formula": "Σ(Wk * ln(z0,k)) / Σ(Wk)",
                "numerator": soma_wk_ln_z0,
                "denominator": total_wk,
                "division_result": ln_z0_setor
            },
            "z0_final_calculation": {
                "formula": "exp(ln(z0_setor))",
                "ln_value": ln_z0_setor,
                "exp_result": z0_setor_final
            },
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        }
        
        self.log_data["final_results"][sector_name] = calc_data
        self.log_step(f"final_{sector_name}", f"Cálculo final para {sector_name}", calc_data)
    
    def save_log(self, filename="aerodynamic_calculations_log.json"):
        """Salva o log completo em arquivo JSON"""
        log_path = os.path.join(self.pasta_saida, filename)
        
        # Adicionar sumário final
        self.log_data["summary"] = {
            "total_steps": len(self.log_data["calculation_steps"]),
            "total_final_results": len(self.log_data["final_results"]),
            "log_completed_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        try:
            with open(log_path, 'w', encoding='utf-8') as f:
                json.dump(self.log_data, f, indent=2, ensure_ascii=False, default=str)
            
            return log_path
        except Exception as e:
            return None

TREE_HEIGHT_LEGEND = {
    '0-2m': '#E6FFE6',
    '2-4m': '#CCFFCC',
    '4-6m': '#90EE90',
    '6-8m': '#7CFC00',
    '8-10m': '#32CD32',
    '10-12m': '#228B22',
    '12-14m': '#006400',
    '14-16m': '#004225',
    '16+m': '#002612'
}

BUILDING_HEIGHT_LEGEND = {
    '0-2m': '#87CEEB',
    '2-3m': '#2196f3',
    '3-5m': '#3f51b5',
    '5-10m': '#673ab7',
    '10-15m': '#9c27b0',
    '15+ m': '#f44336'
}

def get_height_category(altura):
    """Função utilitária para categorizar alturas de forma consistente."""
    if altura < 2:
        return '0-2m'
    elif altura < 4:
        return '2-4m'
    elif altura < 6:
        return '4-6m'
    elif altura < 8:
        return '6-8m'
    elif altura < 10:
        return '8-10m'
    elif altura < 12:
        return '10-12m'
    elif altura < 14:
        return '12-14m'
    elif altura < 16:
        return '14-16m'
    else:
        return '16+m'

def get_building_height_category(altura):
    """Função utilitária para categorizar alturas de edifícios."""
    if altura < 2:
        return '0-2m'
    elif altura < 3:
        return '2-3m'
    elif altura < 5:
        return '3-5m'
    elif altura < 10:
        return '5-10m'
    elif altura < 15:
        return '10-15m'
    else:
        return '15+ m'

def get_confidence_category(confidence):
    """Função utilitária para categorizar valores de confiança em intervalos de 0.1."""
    if confidence < 0.1:
        return '0.0-0.1'
    elif confidence < 0.2:
        return '0.1-0.2'
    elif confidence < 0.3:
        return '0.2-0.3'
    elif confidence < 0.4:
        return '0.3-0.4'
    elif confidence < 0.5:
        return '0.4-0.5'
    elif confidence < 0.6:
        return '0.5-0.6'
    elif confidence < 0.7:
        return '0.6-0.7'
    elif confidence < 0.8:
        return '0.7-0.8'
    elif confidence < 0.9:
        return '0.8-0.9'
    else:
        return '0.9-1.0'

def get_confidence_colors():
    """Função utilitária para obter o dicionário de cores de confiança."""
    return {
        '0.0-0.1': '#8B0000',  # Vermelho escuro - muito baixa
        '0.1-0.2': '#DC143C',  # Vermelho - baixa
        '0.2-0.3': '#FF4500',  # Laranja avermelhado
        '0.3-0.4': '#FF8C00',  # Laranja escuro
        '0.4-0.5': '#FFA500',  # Laranja
        '0.5-0.6': '#FFD700',  # Dourado - média
        '0.6-0.7': '#ADFF2F',  # Verde amarelado
        '0.7-0.8': '#32CD32',  # Verde lima
        '0.8-0.9': '#228B22',  # Verde floresta
        '0.9-1.0': '#006400'   # Verde escuro - alta
    }

def get_extended_height_category(altura):
    """Função utilitária para categorizar alturas estendidas (até 25m+)."""
    if altura < 2:
        return '0-2m'
    elif altura < 3:
        return '2-3m'
    elif altura < 5:
        return '3-5m'
    elif altura < 10:
        return '5-10m'
    elif altura < 15:
        return '10-15m'
    elif altura < 25:
        return '15-25m'
    else:
        return '≥25m'

def get_deviation_category(desvio):
    """Função utilitária para categorizar valores de desvio padrão."""
    if desvio < 2:
        return '0-2m'
    elif desvio < 4:
        return '2-4m'
    elif desvio < 6:
        return '4-6m'
    elif desvio < 8:
        return '6-8m'
    elif desvio < 10:
        return '8-10m'
    elif desvio < 12:
        return '10-12m'
    elif desvio < 14:
        return '12-14m'
    elif desvio < 16:
        return '14-16m'
    else:
        return '16+m'

def get_building_extended_colors():
    """Função utilitária para obter o dicionário de cores estendidas de edifícios."""
    return {
        '0-2m': '#87CEEB',
        '2-3m': '#2196f3',
        '3-5m': '#3f51b5', 
        '5-7m': '#673ab7',
        '7-10m': '#9c27b0',
        '10-15m': '#e91e63',
        '≥15m': '#f44336'
    }

def get_tree_extended_colors():
    """Função utilitária para obter o dicionário de cores estendidas de árvores."""
    return {
        '0-2m': '#E6FFE6',
        '2-3m': '#90EE90',
        '3-5m': '#7CFC00',
        '5-10m': '#32CD32',
        '10-15m': '#228B22',
        '15-25m': '#006400',
        '≥25m': '#004225'
    }

def get_tree_detailed_colors():
    """Função utilitária para obter o dicionário de cores detalhadas de árvores (intervalos de 2m)."""
    return {
        '0-2m': '#E6FFE6',
        '2-4m': '#CCFFCC',
        '4-6m': '#90EE90',
        '6-8m': '#7CFC00',
        '8-10m': '#32CD32',
        '10-12m': '#228B22',
        '12-14m': '#006400',
        '14-16m': '#004225',
        '16+m': '#002612'
    }

def get_building_height_color(altura):
    """Função utilitária para obter cor baseada na altura do edifício."""
    colors = {
        '0-2m': '#87CEEB',
        '2-3m': '#2196f3',
        '3-5m': '#3f51b5',
        '5-10m': '#673ab7',
        '10-15m': '#9c27b0',
        '15+ m': '#f44336'
    }
    return colors.get(get_building_height_category(altura), '#CCCCCC')

def get_tree_height_color(altura):
    """Função utilitária para obter cor baseada na altura da árvore."""
    colors = {
        '0-2m': '#E6FFE6',
        '2-4m': '#CCFFCC', 
        '4-6m': '#90EE90',
        '6-8m': '#7CFC00',
        '8-10m': '#32CD32',
        '10-12m': '#228B22',
        '12-14m': '#006400',
        '14-16m': '#004225',
        '16+m': '#002612'
    }
    return colors.get(get_height_category(altura), '#CCCCCC')

def get_deviation_color_by_value(desvio):
    """
    Retorna cor baseada no valor do desvio padrão (nova classificação detalhada).
    """
    if desvio < 2:
        return '#E6F3FF'  # Azul muito claro - 0-2m
    elif desvio < 4:
        return '#CCE7FF'  # Azul claro - 2-4m
    elif desvio < 6:
        return '#87CEEB'  # Azul claro médio - 4-6m
    elif desvio < 8:
        return '#6BA6CD'  # Azul médio claro - 6-8m
    elif desvio < 10:
        return '#4682B4'  # Azul médio - 8-10m
    elif desvio < 12:
        return '#36648B'  # Azul médio escuro - 10-12m
    elif desvio < 14:
        return '#191970'  # Azul escuro - 12-14m
    elif desvio < 16:
        return '#000080'  # Azul muito escuro - 14-16m
    else:
        return '#000040'  # Azul quase preto - 16+m

def get_confidence_color_by_value(confidence):
    """
    Retorna cor baseada no valor da confiança (intervalos de 0.1).
    Transição: Vermelho (baixa) → Laranja → Amarelo → Verde (alta)
    """
    if confidence < 0.1:
        return '#8B0000'  # Vermelho escuro - muito baixa (0.0-0.1)
    elif confidence < 0.2:
        return '#DC143C'  # Vermelho - baixa (0.1-0.2)
    elif confidence < 0.3:
        return '#FF4500'  # Laranja avermelhado (0.2-0.3)
    elif confidence < 0.4:
        return '#FF8C00'  # Laranja escuro (0.3-0.4)
    elif confidence < 0.5:
        return '#FFA500'  # Laranja (0.4-0.5) - Agora limite baixa/média é 0.4
    elif confidence < 0.6:
        return '#FFD700'  # Dourado - média (0.5-0.6)
    elif confidence < 0.7:
        return '#ADFF2F'  # Verde amarelado (0.6-0.7)
    elif confidence < 0.8:
        return '#32CD32'  # Verde lima (0.7-0.8)
    elif confidence < 0.9:
        return '#228B22'  # Verde floresta (0.8-0.9)
    else:
        return '#006400'  # Verde escuro - alta (0.9-1.0)

def get_z0_color_by_value(z0_value):
    import matplotlib.cm as cm
    import matplotlib.colors as mcolors
    
    # Normalizar o valor z0 para o range [0, 1] baseado no range [0, 2]
    normalized_value = min(max(z0_value / 2.0, 0.0), 1.0)
    
    # Usar colormap viridis (roxo para baixo, amarelo para alto) 
    try:
        # Usar nova sintaxe para matplotlib >= 3.7
        import matplotlib.pyplot as plt
        colormap = plt.colormaps.get_cmap('viridis')
    except (AttributeError, KeyError):
        # Fallback para versões antigas do matplotlib
        colormap = cm.get_cmap('viridis')
    color = colormap(normalized_value)
    
    return color

def get_z0_value_category(z0_value):
    """
    Retorna categoria textual baseada no valor Z0.
    Mais divisões após o valor 1 para melhor granularidade.
    """
    if z0_value < 0.01:
        return "z0 = até 0.01"
    elif z0_value < 0.05:
        return "z0 = 0.01 até 0.05"
    elif z0_value < 0.1:
        return "z0 = 0.05 até 0.1"
    elif z0_value < 0.2:
        return "z0 = 0.1 até 0.2"
    elif z0_value < 0.3:
        return "z0 = 0.2 até 0.3"
    elif z0_value < 0.5:
        return "z0 = 0.3 até 0.5"
    elif z0_value < 0.7:
        return "z0 = 0.5 até 0.7"
    elif z0_value < 1.0:
        return "z0 = 0.7 até 1.0"
    elif z0_value < 1.1:
        return "z0 = 1.0 até 1.1"
    elif z0_value < 1.2:
        return "z0 = 1.1 até 1.2"
    elif z0_value < 1.3:
        return "z0 = 1.2 até 1.3"
    elif z0_value < 1.4:
        return "z0 = 1.3 até 1.4"
    elif z0_value < 1.5:
        return "z0 = 1.4 até 1.5"
    elif z0_value < 1.6:
        return "z0 = 1.5 até 1.6"
    elif z0_value < 1.7:
        return "z0 = 1.6 até 1.7"
    elif z0_value < 1.8:
        return "z0 = 1.7 até 1.8"
    elif z0_value < 1.9:
        return "z0 = 1.8 até 1.9"
    elif z0_value < 2.0:
        return "z0 = 1.9 até 2.0"
    else:
        return "z0 ≥ 2.0"

def get_z0_range_for_category(categoria):
    """
    Retorna o range de valores para uma categoria Z0.
    """
    ranges = {
        "Muito Liso (< 0.01m)": (0.0, 0.01),
        "Liso (0.01-0.05m)": (0.01, 0.05),
        "Mod. Liso (0.05-0.1m)": (0.05, 0.1),
        "Rugosidade Baixa (0.1-0.2m)": (0.1, 0.2),
        "Rugosidade Baixa-Média (0.2-0.3m)": (0.2, 0.3),
        "Rugosidade Média (0.3-0.5m)": (0.3, 0.5),
        "Rugosidade Média-Alta (0.5-0.7m)": (0.5, 0.7),
        "Rugosidade Alta (0.7-1.0m)": (0.7, 1.0),
        "Rugosidade Muito Alta (1.0-1.5m)": (1.0, 1.5),
        "Rugosidade Extrema (≥ 1.5m)": (1.5, float('inf'))
    }
    return ranges.get(categoria, (0.0, 0.001))

def setup_map_base(lat, lon, figsize=(15, 15)):
    transformer_to_web = Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
    center_x_web, center_y_web = transformer_to_web.transform(lon, lat)
    gdf_center = gpd.GeoDataFrame(geometry=[Point(center_x_web, center_y_web)], crs="EPSG:3857")
    
    fig, ax = plt.subplots(figsize=figsize)
    
    return fig, ax, gdf_center

def finalize_map(ax, gdf_center, gdf_pixels_web, title, subtitle, pasta_saida, filename):
    minx_map, miny_map, maxx_map, maxy_map = gdf_pixels_web.total_bounds
    ax.set_xlim(minx_map, maxx_map)
    ax.set_ylim(miny_map, maxy_map)
        
    _adicionar_mapa_base(ax)
    
    ax.set_aspect("equal")
    ax.set_axis_off()
    plt.tight_layout()
    
    pasta_imagens = os.path.join(pasta_saida, "imagens")
    os.makedirs(pasta_imagens, exist_ok=True)
    caminho_completo = os.path.join(pasta_imagens, filename)
    plt.savefig(caminho_completo, dpi=300, bbox_inches='tight', format='jpeg')
    plt.close()

def calculate_descriptive_stats(values):
    """
    Calcula estatísticas descritivas (média, moda, mediana, desvio padrão) para uma lista de valores.
    
    Args:
        values: Lista de valores numéricos
        
    Returns:
        dict: Dicionário com as estatísticas calculadas
    """
    if not values:
        return {
            'count': 0,
            'mean': 0.0,
            'median': 0.0,
            'mode': 0.0,
            'std_dev': 0.0,
            'min': 0.0,
            'max': 0.0
        }
    
    valid_values = [v for v in values if v is not None and v != 0]
    
    if not valid_values:
        return {
            'count': 0,
            'mean': 0.0,
            'median': 0.0,
            'mode': 0.0,
            'std_dev': 0.0,
            'min': 0.0,
            'max': 0.0
        }
    
    try:
        mean_val = mean(valid_values)
        median_val = median(valid_values)
        
        try:
            mode_val = mode(valid_values)
        except:
            counter = Counter(valid_values)
            mode_val = counter.most_common(1)[0][0] if counter else 0.0
        
        std_dev_val = stdev(valid_values) if len(valid_values) > 1 else 0.0
        
        return {
            'count': len(valid_values),
            'mean': round(mean_val, 4),
            'median': round(median_val, 4),
            'mode': round(mode_val, 4),
            'std_dev': round(std_dev_val, 4),
            'min': round(min(valid_values), 4),
            'max': round(max(valid_values), 4)
        }
        
    except Exception as e:
        return {
            'count': len(valid_values),
            'mean': 0.0,
            'median': 0.0,
            'mode': 0.0,
            'std_dev': 0.0,
            'min': round(min(valid_values), 4) if valid_values else 0.0,
            'max': round(max(valid_values), 4) if valid_values else 0.0
        }

# --- C0Z0_Solution: rasters grandes em  dados/  ao lado do .exe / do codigo.
#     Caminho vem do config.py na raiz, ou da variavel de ambiente C0Z0_DADOS. ---
try:
    _RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _RAIZ not in sys.path:
        sys.path.insert(0, _RAIZ)
    from config import DADOS as _DADOS
except Exception:
    _b = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else _RAIZ
    _DADOS = os.environ.get("C0Z0_DADOS") or os.path.join(_b, "dados")

# mapas_circulares.py vive na raiz da solution -- e a UNICA funcao que
# desenha mapas circulares (fatias); final_z0_map_by_sector.jpg passa por
# ela para sair sempre com o mesmo layout/escala dos outros mapas
# circulares da solucao (ex.: qp_pressure.jpg, co_map.jpg).
from mapas_circulares import desenhar_mapa_circular, adicionar_colorbar_padrao


def get_base_path():
    """Pasta com os rasters. E sempre  dados/  (config.py -> DADOS): tanto em
    dev como em .exe onefile os rasters ficam FORA do binario, ao lado dele
    (sao GB -- nao entram no bundle)."""
    return _DADOS

metodoUmArvore = False

BASE_PATH = get_base_path()
WORK_DIR = _DADOS          # onde estao TIF_Arvores / TIF_Arvores_Desvio / TIF_Building

GEOTIFF_PATH_CONTINENTE = os.path.join(BASE_PATH, "LandCover_Continente.tif")
TIF_ARVORES_PATH = os.path.join(WORK_DIR, "TIF_Arvores")
TIF_ARVORES_DESVIO_PATH = os.path.join(WORK_DIR, "TIF_Arvores_Desvio")
VRT_ARVORES_PATH = os.path.join(BASE_PATH, "ETH_GlobalCanopyHeight_10m_2020_mosaic_Map.vrt")
BASE_DOWNLOAD_URL = "https://libdrive.ethz.ch/index.php/s/cO8or7iOe5dT2Rt/download?path=%2F3deg_cogs&files="

def garantir_diretorios():
    """
    Cria os diretórios necessários se eles não existirem.
    """
    current_dir = os.getcwd()
    
    diretorios = [
        os.path.join(current_dir, "TIF_Arvores"),
        os.path.join(current_dir, "TIF_Arvores_Desvio"), 
        os.path.join(current_dir, "TIF_Building"),
        os.path.join(current_dir, "resultados")
    ]
    
    for diretorio in diretorios:
        os.makedirs(diretorio, exist_ok=True)

def verificar_geotiff():
    if not os.path.exists(GEOTIFF_PATH_CONTINENTE):
        return False
    return True

LANDCOVER_CLASSES = {
    111: "Continuous urban fabric",
    112: "Discontinuous urban fabric", 
    121: "Industrial or commercial units",
    122: "Road and rail networks and associated land",
    123: "Port areas",
    124: "Airports",
    131: "Mineral extraction sites",
    132: "Dump sites",
    133: "Construction sites",
    141: "Green urban areas",
    142: "Sport and leisure facilities",
    211: "Non-irrigated arable land",
    212: "Permanently irrigated land",
    213: "Rice fields",
    221: "Vineyards",
    222: "Fruit trees and berry plantations",
    223: "Olive groves",
    231: "Pastures",
    241: "Annual crops associated with permanent crops",
    242: "Complex cultivation patterns",
    243: "Land principally occupied by agriculture, with significant areas of natural vegetation",
    244: "Agro-forestry areas",
    311: "Broad-leaved forest",
    312: "Coniferous forest",
    313: "Mixed forest",
    321: "Natural grasslands",
    322: "Moors and heathland",
    323: "Sclerophyllous vegetation",
    324: "Transitional woodland-shrub",
    331: "Beaches, dunes, sands",
    332: "Bare rocks",
    333: "Sparsely vegetated areas",
    334: "Burnt areas",
    335: "Glaciers and perpetual snow",
    411: "Inland marshes",
    412: "Peat bogs",
    421: "Salt marshes",
    422: "Salines",
    423: "Intertidal flats",
    511: "Water courses",
    512: "Water bodies",
    521: "Coastal lagoons",
    522: "Estuaries",
    523: "Sea and ocean",
    
    # Códigos simplificados que podem aparecer no dataset
    1: "Continuous urban fabric",
    2: "Discontinuous urban fabric",
    3: "Industrial or commercial units",
    4: "Road and rail networks and associated land",
    5: "Port areas",
    6: "Airports",
    7: "Mineral extraction sites",
    8: "Dump sites",
    9: "Construction sites",
    10: "Green urban areas",
    11: "Sport and leisure facilities",
    12: "Non-irrigated arable land",
    13: "Permanently irrigated land",
    14: "Rice fields",
    15: "Vineyards",
    16: "Fruit trees and berry plantations",
    17: "Olive groves",
    18: "Pastures",
    19: "Annual crops associated with permanent crops",
    20: "Complex cultivation patterns",
    21: "Land principally occupied by agriculture, with significant areas of natural vegetation",
    22: "Agro-forestry areas",
    23: "Broad-leaved forest",
    24: "Coniferous forest",
    25: "Mixed forest",
    26: "Natural grasslands",
    27: "Moors and heathland",
    28: "Sclerophyllous vegetation",
    29: "Transitional woodland-shrub",
    30: "Beaches, dunes, sands",
    31: "Bare rocks",
    32: "Sparsely vegetated areas",
    33: "Burnt areas",
    34: "Glaciers and perpetual snow",
    35: "Inland marshes",
    36: "Peat bogs",
    37: "Salt marshes",
    38: "Salines",
    39: "Intertidal flats",
    40: "Water courses",
    41: "Water bodies",
    42: "Coastal lagoons",
    43: "Estuaries",
    44: "Sea and ocean"
}

LANDCOVER_Z0_VALUES = {
    111: 0.5,
    112: 0.4,
    121: 0.7,
    122: 0.1,
    123: 0.5,
    124: 0.03,
    131: 0.1,
    132: 0.1,
    133: 0.3,
    141: 0.4,
    142: 0.5,
    211: 0.056,
    212: 0.056,
    213: 0.0184,
    221: 0.3,
    222: 0.4,
    223: 0.4,
    231: 0.036,
    241: 0.056,
    242: 0.056,
    243: 0.056,
    244: 0.5,
    311: 0.5,
    312: 0.5,
    313: 0.5,
    321: 0.056,
    322: 0.06,
    323: 0.056,
    324: 0.4,
    331: 0.01,
    332: 0.05,
    333: 0.2,
    334: 0.2,
    335: 0.005,
    411: 0.05,
    412: 0.0184,
    421: 0.0348,
    422: 0.03,
    423: 0.0005,
    511: 0,
    512: 0,
    521: 0,
    522: 0,
    523: 0,
    
    1: 0.5,
    2: 0.4,    # 112 - Discontinuous urban fabric
    3: 0.7,    # 121 - Industrial or commercial units
    4: 0.1,    # 122 - Road and rail networks
    5: 0.5,    # 123 - Port areas
    6: 0.03,   # 124 - Airports
    7: 0.1,    # 131 - Mineral extraction sites
    8: 0.1,    # 132 - Dump sites
    9: 0.3,    # 133 - Construction sites
    10: 0.4,   # 141 - Green urban areas
    11: 0.5,   # 142 - Sport and leisure facilities
    12: 0.056, # 211 - Non-irrigated arable land
    13: 0.056, # 212 - Permanently irrigated land
    14: 0.0184,# 213 - Rice fields
    15: 0.3,   # 221 - Vineyards
    16: 0.4,   # 222 - Fruit trees and berry plantations
    17: 0.4,   # 223 - Olive groves
    18: 0.036, # 231 - Pastures
    19: 0.056, # 241 - Annual crops associated with permanent crops
    20: 0.056, # 242 - Complex cultivation patterns
    21: 0.056, # 243 - Land principally occupied by agriculture
    22: 0.5,   # 244 - Agro-forestry areas
    23: 0.5,   # 311 - Broad-leaved forest
    24: 0.5,   # 312 - Coniferous forest
    25: 0.5,   # 313 - Mixed forest
    26: 0.056, # 321 - Natural grasslands
    27: 0.06,  # 322 - Moors and heathland
    28: 0.056, # 323 - Sclerophyllous vegetation
    29: 0.4,   # 324 - Transitional woodland-shrub
    30: 0.01,  # 331 - Beaches, dunes, sands
    31: 0.05,  # 332 - Bare rocks
    32: 0.2,   # 333 - Sparsely vegetated areas
    33: 0.2,   # 334 - Burnt areas
    34: 0.005, # 335 - Glaciers and perpetual snow
    35: 0.05,  # 411 - Inland marshes
    36: 0.0184,# 412 - Peat bogs
    37: 0.0348,# 421 - Salt marshes
    38: 0.03,  # 422 - Salines
    39: 0.0005,# 423 - Intertidal flats
    40: 0,     # 511 - Water courses
    41: 0,     # 512 - Water bodies
    42: 0,     # 521 - Coastal lagoons
    43: 0,     # 522 - Estuaries
    44: 0
}

LANDCOVER_COMPLETE_VALUES = {
    111: {'z0': 0.5, 'd': 6.43, 'alfaBuilding': 0.2608, 'alfaArvores': 0.17},    # Continuous urban fabric
    112: {'z0': 0.4, 'd': 5.71, 'alfaBuilding': 0.144, 'alfaArvores': 0.17},      # Discontinuous urban fabric
    121: {'z0': 0.7, 'd': 7.86, 'alfaBuilding': 0.126, 'alfaArvores': 0.17},     # Industrial or commercial units
    122: {'z0': 0.1, 'd': 2.6, 'alfaBuilding': 0.0932, 'alfaArvores': 0.17},    # Road and rail networks
    123: {'z0': 0.5, 'd': 6.43, 'alfaBuilding': 0.0632, 'alfaArvores': 0.17},    # Port areas
    124: {'z0': 0.03, 'd': 1.5, 'alfaBuilding': 0.0632, 'alfaArvores': 0.17},  # Airports
    131: {'z0': 0.1, 'd': 2.6, 'alfaBuilding': 0.0375, 'alfaArvores': 0.17},    # Mineral extraction sites
    132: {'z0': 0.1, 'd': 2.6, 'alfaBuilding': 0.0375, 'alfaArvores': 0.17},    # Dump sites
    133: {'z0': 0.3, 'd': 5, 'alfaBuilding': 0.0375, 'alfaArvores': 0.17},    # Construction sites
    141: {'z0': 0.8, 'd': 8.57, 'alfaBuilding': 0.144, 'alfaArvores': 0.17},     # Green urban areas
    142: {'z0': 0.5, 'd': 6.43, 'alfaBuilding': 0.0375, 'alfaArvores': 0.17},
    
    211: {'z0': 0.056, 'd': 2.07, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},
    212: {'z0': 0.056, 'd': 2.07, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},  # Permanently irrigated land
    213: {'z0': 0.03, 'd': 1.5, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17}, # Rice fields
    221: {'z0': 0.3, 'd': 5, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # Vineyards
    222: {'z0': 0.4, 'd': 5.71, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},      # Fruit trees and berry plantations
    223: {'z0': 0.4, 'd': 5.71, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},      # Olive groves
    231: {'z0': 0.036, 'd': 1.65, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},  # Pastures
    241: {'z0': 0.1, 'd': 2.6, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},  # Annual crops with permanent crops
    242: {'z0': 0.15, 'd': 3.2, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},  # Complex cultivation patterns
    243: {'z0': 0.2, 'd': 3.8, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},  # Land principally occupied by agriculture
    244: {'z0': 0.5, 'd': 6.43, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},
    
    311: {'z0': 1, 'd': 10, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},
    312: {'z0': 1.2, 'd': 10, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # Coniferous forest
    313: {'z0': 1.1, 'd': 10, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # Mixed forest
    321: {'z0': 0.056, 'd': 2.07, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},  # Natural grasslands
    322: {'z0': 0.06, 'd': 2.12, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # Moors and heathland
    323: {'z0': 0.07, 'd': 2.24, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # Sclerophyllous vegetation
    324: {'z0': 0.4, 'd': 5.71, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},
    
    331: {'z0': 0.01, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},
    332: {'z0': 0.05, 'd': 2, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # Bare rocks
    333: {'z0': 0.03, 'd': 1.5, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # Sparsely vegetated areas
    334: {'z0': 0.2, 'd': 3.8, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # Burnt areas
    335: {'z0': 0.005, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},
    
    411: {'z0': 0.05, 'd': 2, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},
    412: {'z0': 0.03, 'd': 1.5, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},  # Peat bogs
    421: {'z0': 0.0348, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},  # Salt marshes
    422: {'z0': 0.03, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # Salines
    423: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},  # Intertidal flats
    511: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # Water courses
    512: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # Water bodies
    521: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # Coastal lagoons
    522: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # Estuaries
    523: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},
    
    1: {'z0': 0.5, 'd': 6.43, 'alfaBuilding': 0.2608, 'alfaArvores': 0.17},
    2: {'z0': 0.4, 'd': 5.71, 'alfaBuilding': 0.144, 'alfaArvores': 0.17},        # 112 - Discontinuous urban fabric
    3: {'z0': 0.7, 'd': 7.86, 'alfaBuilding': 0.126, 'alfaArvores': 0.17},       # 121 - Industrial or commercial units
    4: {'z0': 0.1, 'd': 2.6, 'alfaBuilding': 0.0932, 'alfaArvores': 0.17},      # 122 - Road and rail networks
    5: {'z0': 0.5, 'd': 6.43, 'alfaBuilding': 0.0632, 'alfaArvores': 0.17},      # 123 - Port areas
    6: {'z0': 0.03, 'd': 1.5, 'alfaBuilding': 0.0632, 'alfaArvores': 0.17},    # 124 - Airports
    7: {'z0': 0.1, 'd': 2.6, 'alfaBuilding': 0.0375, 'alfaArvores': 0.17},      # 131 - Mineral extraction sites
    8: {'z0': 0.1, 'd': 2.6, 'alfaBuilding': 0.0375, 'alfaArvores': 0.17},      # 132 - Dump sites
    9: {'z0': 0.3, 'd': 5, 'alfaBuilding': 0.0375, 'alfaArvores': 0.17},      # 133 - Construction sites
    10: {'z0': 0.8, 'd': 8.57, 'alfaBuilding': 0.144, 'alfaArvores': 0.17},      # 141 - Green urban areas
    11: {'z0': 0.5, 'd': 6.43, 'alfaBuilding': 0.0375, 'alfaArvores': 0.17},     # 142 - Sport and leisure facilities
    12: {'z0': 0.056, 'd': 2.07, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # 211 - Non-irrigated arable land
    13: {'z0': 0.056, 'd': 2.07, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # 212 - Permanently irrigated land
    14: {'z0': 0.03, 'd': 1.5, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17}, # 213 - Rice fields
    15: {'z0': 0.3, 'd': 5, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},      # 221 - Vineyards
    16: {'z0': 0.4, 'd': 5.71, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},       # 222 - Fruit trees and berry plantations
    17: {'z0': 0.4, 'd': 5.71, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},       # 223 - Olive groves
    18: {'z0': 0.036, 'd': 1.65, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # 231 - Pastures
    19: {'z0': 0.1, 'd': 2.6, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # 241 - Annual crops with permanent crops
    20: {'z0': 0.15, 'd': 3.2, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # 242 - Complex cultivation patterns
    21: {'z0': 0.2, 'd': 3.8, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # 243 - Land principally occupied by agriculture
    22: {'z0': 0.5, 'd': 6.43, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},      # 244 - Agro-forestry areas
    23: {'z0': 1, 'd': 10, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},      # 311 - Broad-leaved forest
    24: {'z0': 1.2, 'd': 10, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # 312 - Coniferous forest
    25: {'z0': 1.1, 'd': 10, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},      # 313 - Mixed forest
    26: {'z0': 0.056, 'd': 2.07, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # 321 - Natural grasslands
    27: {'z0': 0.06, 'd': 2.12, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # 322 - Moors and heathland
    28: {'z0': 0.07, 'd': 2.24, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # 323 - Sclerophyllous vegetation
    29: {'z0': 0.4, 'd': 5.71, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},      # 324 - Transitional woodland-shrub
    30: {'z0': 0.01, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # 331 - Beaches, dunes, sands
    31: {'z0': 0.05, 'd': 2, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},    # 332 - Bare rocks
    32: {'z0': 0.3, 'd': 1.5, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # 333 - Sparsely vegetated areas
    33: {'z0': 0.2, 'd': 3.8, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # 334 - Burnt areas
    34: {'z0': 0.005, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # 335 - Glaciers and perpetual snow
    35: {'z0': 0.05, 'd': 2, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # 411 - Inland marshes
    36: {'z0': 0.03, 'd': 1.5, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # 412 - Peat bogs
    37: {'z0': 0.0348, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # 421 - Salt marshes
    38: {'z0': 0.03, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # 422 - Salines
    39: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},   # 423 - Intertidal flats
    40: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # 511 - Water courses
    41: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # 512 - Water bodies
    42: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # 521 - Coastal lagoons
    43: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17},     # 522 - Estuaries
    44: {'z0': 0.0003, 'd': 1, 'alfaBuilding': 0.0222, 'alfaArvores': 0.17}      # 523 - Sea and ocean
}

COLORS = plt.cm.tab20.colors

# ==============================
# FUNÇÕES DE ANÁLISE E DOWNLOAD DE DADOS DE ÁRVORES
# ==============================

def identificar_tifs_necessarios(lat, lon, raio_m, margem=1.2):
    """
    Identifica quais arquivos TIF de arvores (ETH GlobalCanopyHeight, grade
    de 3 graus) sao necessarios para cobrir o circulo de raio_m ao redor de
    (lat, lon): quando o circulo atravessa a fronteira de um tile, devolve
    TODOS os tiles que o circulo toca (1, 2 ou 4), nao so o tile onde o
    ponto central cai. Evita cortar dados de arvores do lado que ficou no
    tile vizinho.

    Padrao de nomenclatura:
    - Principal: ETH_GlobalCanopyHeight_10m_2020_NXXWXXX_Map.tif
    - Desvio: ETH_GlobalCanopyHeight_10m_2020_NXXWXXX_Map_SD.tif

    Returns:
        Lista de tuplas (arquivo_principal, arquivo_desvio), sem duplicatas.
    """
    dlat = (raio_m * margem) / 111320
    dlon = (raio_m * margem) / (111320 * math.cos(math.radians(lat)))

    def _tile_origin(v):
        return int(v // 3) * 3

    lat_tiles = sorted({_tile_origin(lat - dlat), _tile_origin(lat + dlat)})
    lon_tiles = sorted({_tile_origin(lon - dlon), _tile_origin(lon + dlon)})

    pares = []
    for lat_tile in lat_tiles:
        lat_str = f"N{abs(lat_tile):02d}" if lat_tile >= 0 else f"S{abs(lat_tile):02d}"
        for lon_tile in lon_tiles:
            lon_str = f"E{abs(lon_tile):03d}" if lon_tile >= 0 else f"W{abs(lon_tile):03d}"
            principal = f"ETH_GlobalCanopyHeight_10m_2020_{lat_str}{lon_str}_Map.tif"
            desvio = f"ETH_GlobalCanopyHeight_10m_2020_{lat_str}{lon_str}_Map_SD.tif"
            pares.append((principal, desvio))
    return pares

def verificar_tif_local(filename, pasta_tif="./TIF_Arvores"):

    caminho_completo = os.path.join(pasta_tif, filename)
    existe = os.path.exists(caminho_completo)
    
    if existe:
        # Verificar se o arquivo não está vazio
        try:
            tamanho = os.path.getsize(caminho_completo)
            if tamanho > 0:
                return True
            else:
                return False
        except:
            return False
    else:
        return False

def fazer_download_tif(filename, pasta_destino="./TIF_Arvores", base_url=BASE_DOWNLOAD_URL):

    os.makedirs(pasta_destino, exist_ok=True)
    
    # Construir URL completa
    url = base_url + urllib.parse.quote(filename)
    caminho_arquivo = os.path.join(pasta_destino, filename)

    try:
        # Fazer requisição com timeout
        response = requests.get(url, timeout=300, stream=True)  # 5 minutos de timeout
        
        if response.status_code == 200:
            total_size = int(response.headers.get('content-length', 0))
            
            downloaded_size = 0
            
            with open(caminho_arquivo, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded_size += len(chunk)
            
            # Verificar se o download foi completo
            final_size = os.path.getsize(caminho_arquivo)
            if final_size == total_size or total_size == 0:
                return True
            else:
                return False
        else:
            return False
            
    except requests.exceptions.Timeout:
        return False
    except Exception as e:
        return False

def _garantir_arquivo_tif(nome, pasta_destino):
    """Garante que um unico tile existe localmente (baixa se faltar).
    Devolve o caminho, ou None se nao foi possivel obter."""
    if verificar_tif_local(nome, pasta_destino):
        return os.path.join(pasta_destino, nome)
    if fazer_download_tif(nome, pasta_destino):
        return os.path.join(pasta_destino, nome)
    return None

def _obter_raster_cobrindo_tiles(nomes_tiles, pasta_tiles, pasta_mosaicos, bbox):
    """Garante os tiles necessarios localmente e devolve um UNICO caminho
    de raster que os cobre: o proprio tile se so precisar de 1 (caso comum,
    sem custo extra), ou um mosaico mesclado e cacheado se precisar de mais
    de um (ponto perto de uma fronteira de tile).

    O mosaico e recortado a bbox (left, bottom, right, top) -- a area do
    circulo de analise, com margem -- em vez dos tiles inteiros (36000x36000
    px cada): mesclar tiles inteiros gerava arquivos de GBs e demorava
    minutos; recortado, fica na casa dos KB/MB e e quase instantaneo.
    """
    caminhos = [c for c in (_garantir_arquivo_tif(nome, pasta_tiles) for nome in nomes_tiles) if c]

    if not caminhos:
        return None
    if len(caminhos) == 1:
        return caminhos[0]

    os.makedirs(pasta_mosaicos, exist_ok=True)
    chave = "_".join(sorted(os.path.basename(c) for c in caminhos))
    caminho_mosaico = os.path.join(pasta_mosaicos, f"mosaico_{chave}")
    if os.path.isfile(caminho_mosaico):
        return caminho_mosaico

    srcs = [rasterio.open(c) for c in caminhos]
    try:
        mosaico, transform = rasterio_merge(srcs, bounds=bbox)
        meta = srcs[0].meta.copy()
        meta.update({'height': mosaico.shape[1], 'width': mosaico.shape[2], 'transform': transform})
        with rasterio.open(caminho_mosaico, 'w', **meta) as dst:
            dst.write(mosaico)
    finally:
        for s in srcs:
            s.close()
    return caminho_mosaico

def garantir_tif_arvores(lat, lon, raio_m, margem=1.2):
    """Garante os tiles de arvores (principal e desvio) que cobrem o
    circulo de raio_m ao redor de (lat, lon) -- baixando os que faltarem e
    mesclando automaticamente (so a area de interesse, nao os tiles
    inteiros) quando o circulo atravessa mais de um tile de 3 graus."""
    pares = identificar_tifs_necessarios(lat, lon, raio_m, margem=margem)
    nomes_principais = [p[0] for p in pares]
    nomes_desvio = [p[1] for p in pares]

    dlat = (raio_m * margem) / 111320
    dlon = (raio_m * margem) / (111320 * math.cos(math.radians(lat)))
    bbox = (lon - dlon, lat - dlat, lon + dlon, lat + dlat)  # left, bottom, right, top

    caminho_principal = _obter_raster_cobrindo_tiles(
        nomes_principais, TIF_ARVORES_PATH, os.path.join(TIF_ARVORES_PATH, "_mosaicos"), bbox)
    caminho_desvio = _obter_raster_cobrindo_tiles(
        nomes_desvio, TIF_ARVORES_DESVIO_PATH, os.path.join(TIF_ARVORES_DESVIO_PATH, "_mosaicos"), bbox)

    return caminho_principal, caminho_desvio

# ==============================
# FUNÇÕES DE DETECÇÃO DE EDIFÍCIOS (DHM)
# ==============================

def carregar_dhm_region(lat_centro, lon_centro, raio_m, arquivo_dhm=None):

    if arquivo_dhm is None:
        arquivo_dhm = os.path.join(get_base_path(), 'DHM_2012_10m_LAEA.tif')
    
    try:
        with rasterio.open(arquivo_dhm) as dataset:
            # Converter centro para o sistema de coordenadas do raster
            centro_geom = gpd.GeoDataFrame(
                geometry=[Point(lon_centro, lat_centro)], 
                crs="EPSG:4326"
            ).to_crs(dataset.crs)
            
            centro_x, centro_y = centro_geom.geometry.iloc[0].x, centro_geom.geometry.iloc[0].y
            
            # Criar buffer circular no sistema de coordenadas do raster
            buffer_geom = centro_geom.buffer(raio_m)
            
            # Extrair dados da região usando mask
            region_data, region_transform = mask(dataset, buffer_geom.geometry, crop=True)
            region_data = region_data[0]  # Primeira banda
            
            return {
                'data': region_data,
                'transform': region_transform,
                'crs': dataset.crs,
                'centro_x': centro_x,
                'centro_y': centro_y
            }
            
    except Exception as e:
        return None

def detectar_edificios_dhm(region_info):

    data = region_info['data']
    transform = region_info['transform']
    crs = region_info['crs']
    
    # Remover valores inválidos
    data_clean = np.where((data > -9999) & (data < 9999), data, np.nan)
    
    # Estatísticas
    valid_data = data_clean[~np.isnan(data_clean)]
    if len(valid_data) == 0:
        return gpd.GeoDataFrame(columns=['geometry'], crs=crs)
    
    pixels_edificios = []
    rows, cols = data.shape
    
    # Obter tamanho real do pixel DHM
    pixel_size_x = abs(transform.a)  # ~10m
    pixel_size_y = abs(transform.e)  # ~10m
    
    # Processar pixels com altura ≥ 2m
    for row in range(rows):
        for col in range(cols):
            altura_pixel = data_clean[row, col]
            
            if np.isnan(altura_pixel) or altura_pixel < 2.0:
                continue
                
            # Converter coordenadas de pixel para geográficas (centro do pixel)
            x_center, y_center = rasterio.transform.xy(transform, row, col)
            
            # Criar geometria EXATA do pixel DHM (quadrado alinhado com a grade)
            # Calcular os cantos do pixel
            left = x_center - pixel_size_x / 2
            right = x_center + pixel_size_x / 2
            bottom = y_center - pixel_size_y / 2
            top = y_center + pixel_size_y / 2
            
            # Criar polígono EXATO do pixel (não buffer circular)
            pixel_geom = geom.Polygon([
                (left, bottom), (right, bottom), 
                (right, top), (left, top), (left, bottom)
            ])
            
            pixels_edificios.append({
                'geometry': pixel_geom,
                'altura': float(altura_pixel),
                'row': row,
                'col': col,
                'centro_x': x_center,
                'centro_y': y_center
            })
    
    # Pixels com edifícios detectados no DHM
    
    if not pixels_edificios:
        return gpd.GeoDataFrame(columns=['geometry'], crs=crs)
    
    return gpd.GeoDataFrame(pixels_edificios, crs=crs)

def detect_building_subpixels_dhm(gdf_buildings_dhm, all_subpixels, raster_crs, all_subpixels_data=None):
    """
    Detecta quais subpixels de 10x10m intersectam com pixels de edifícios do DHM.
    Usa intersecção espacial precisa para evitar falsos positivos.
    Retorna lista de dicionários com índice e altura do edifício.
    """
    if gdf_buildings_dhm.empty:
        return []
    
    # Converter edifícios DHM para o CRS do raster se necessário
    if raster_crs != gdf_buildings_dhm.crs:
        gdf_buildings_proj = gdf_buildings_dhm.to_crs(raster_crs)
    else:
        gdf_buildings_proj = gdf_buildings_dhm
    
    # Verificando intersecções entre subpixels e pixels de edifícios
    building_subpixels = []
    intersections_found = 0
    
    # Criar índice espacial dos edifícios para eficiência
    from shapely.strtree import STRtree
    building_geometries = list(gdf_buildings_proj.geometry)
    building_tree = STRtree(building_geometries)
    
    for i, subpixel in enumerate(all_subpixels):
        # Usar índice espacial para encontrar candidatos próximos
        possible_matches_idx = building_tree.query(subpixel)
        
        # Verificar intersecção real com candidatos
        for match_idx in possible_matches_idx:
            building_geom = building_geometries[match_idx]
            
            # Verificar se há intersecção significativa (mais de 1% da área)
            if subpixel.intersects(building_geom):
                intersection_area = subpixel.intersection(building_geom).area
                subpixel_area = subpixel.area
                overlap_ratio = intersection_area / subpixel_area if subpixel_area > 0 else 0
                
                # Só considerar se há pelo menos 1% de sobreposição
                if overlap_ratio > 0.01:
                    # Obter altura do edifício correspondente
                    altura_edificio = gdf_buildings_dhm.iloc[match_idx]['altura']
                    
                    # Obter pixel_id e landcover_code se os dados estão disponíveis
                    pixel_id = None
                    landcover_code = None
                    landcover_category = None
                    
                    if all_subpixels_data and i < len(all_subpixels_data):
                        subpixel_data = all_subpixels_data[i]
                        pixel_id = subpixel_data.get('pixel_id')
                        landcover_code = subpixel_data.get('value')
                        landcover_category = subpixel_data.get('category', 'Não identificado')
                    
                    building_subpixels.append({
                        'index': i,
                        'altura': altura_edificio,
                        'pixel_id': pixel_id,
                        'landcover_code': landcover_code,
                        'landcover_category': landcover_category
                    })
                    intersections_found += 1
                    break  # Uma vez encontrada intersecção, não precisa verificar outros
    
    # Subpixels marcados como edifícios e verificação de alinhamento
    expected_ratio = len(building_subpixels) / len(gdf_buildings_proj) if len(gdf_buildings_proj) > 0 else 0
    
    return building_subpixels

# ==============================
# FUNÇÕES DE DETECÇÃO DE ÁRVORES (ETH Global Canopy Height)
# ==============================

def carregar_arvores_region(lat_centro, lon_centro, raio_m, caminho_tif_arvores, pais="Portugal", regiao="N/A"):

    try:
        with rasterio.open(caminho_tif_arvores) as dataset:            
            # CORREÇÃO: Como o TIF está em EPSG:4326 (graus), precisamos converter
            # para um sistema projetado adequado antes de criar buffer em metros
            
            # Verificar se é território ultramarino francês para usar UTM ao invés de LAEA
            territorios_ultramarinos_franceses = ["Martinique", "Mayotte", "Réunion", "Guadeloupe", "French Guiana"]
            
            if regiao in territorios_ultramarinos_franceses:
                # Para ilhas francesas: usar sistema UTM apropriado baseado na longitude
                utm_zone = int((lon_centro + 180) / 6) + 1
                hemisphere = 'north' if lat_centro >= 0 else 'south'
                target_crs = f"EPSG:326{utm_zone:02d}" if hemisphere == 'north' else f"EPSG:327{utm_zone:02d}"
            else:
                # Para Europa continental: usar sistema LAEA
                target_crs = "IGNF:ETRS89LAEA"  # Mesmo sistema do DHM
            
            # Converter centro para sistema projetado onde metros fazem sentido
            centro_geom_wgs84 = gpd.GeoDataFrame(
                geometry=[Point(lon_centro, lat_centro)], 
                crs="EPSG:4326"
            )
            
            centro_geom_projected = centro_geom_wgs84.to_crs(target_crs)
            centro_x_proj, centro_y_proj = centro_geom_projected.geometry.iloc[0].x, centro_geom_projected.geometry.iloc[0].y
            
            # Criar buffer circular em metros no sistema projetado
            buffer_geom_projected = centro_geom_projected.buffer(raio_m)
            
            # Converter buffer de volta para o CRS do arquivo TIF (EPSG:4326)
            buffer_geom = buffer_geom_projected.to_crs(dataset.crs)
            
            centro_x, centro_y = centro_x_proj, centro_y_proj  # Usar coordenadas projetadas
            
            # Extraindo região
            
            # Extrair dados da região usando mask (só carrega a região necessária!)
            region_data, region_transform = mask(dataset, buffer_geom.geometry, crop=True)
            region_data = region_data[0]  # Primeira banda


            return {
                'data': region_data,
                'transform': region_transform,
                'crs': dataset.crs,
                'centro_x': centro_x,
                'centro_y': centro_y
            }
            
    except Exception as e:
        return None

def detectar_arvores_canopy(region_info, altura_minima=2.0):

    data = region_info['data']
    transform = region_info['transform']
    crs = region_info['crs']
    
    valid_mask = (data > 0) & (data < 250) & ~np.isnan(data)
    
    # Verificar se há dados válidos
    if not np.any(valid_mask):
        return gpd.GeoDataFrame(columns=['geometry'], crs=crs)
    
    # Estatísticas apenas dos pixels válidos
    valid_data = data[valid_mask]
    
    # Obter tamanho real do pixel de árvores
    pixel_size_x = abs(transform.a)
    pixel_size_y = abs(transform.e)
    
    # Encontrar coordenadas dos pixels válidos usando operações vetorizadas
    valid_rows, valid_cols = np.where(valid_mask)
    
    # Criar listas para geometrias e dados
    pixels_arvores = []
    
    # Processar apenas pixels válidos (muito mais eficiente)
    for i in range(len(valid_rows)):
        row, col = valid_rows[i], valid_cols[i]
        altura_pixel = data[row, col]
        
        # Converter coordenadas de pixel para geográficas (centro do pixel)
        x_center, y_center = rasterio.transform.xy(transform, row, col)
        
        # Criar geometria EXATA do pixel de árvores (quadrado alinhado com a grade)
        # Calcular os cantos do pixel
        left = x_center - pixel_size_x / 2
        right = x_center + pixel_size_x / 2
        bottom = y_center - pixel_size_y / 2
        top = y_center + pixel_size_y / 2
        
        # Criar polígono EXATO do pixel (não buffer circular)
        pixel_geom = geom.Polygon([
            (left, bottom), (right, bottom), 
            (right, top), (left, top), (left, bottom)
        ])
        
        pixels_arvores.append({
            'geometry': pixel_geom,
            'altura': float(altura_pixel),
            'row': int(row),
            'col': int(col),
            'centro_x': x_center,
            'centro_y': y_center
        })
    
    if not pixels_arvores:
        return gpd.GeoDataFrame(columns=['geometry'], crs=crs)
    
    return gpd.GeoDataFrame(pixels_arvores, crs=crs)

def carregar_desvio_arvores_region(lat_centro, lon_centro, raio_m, caminho_tif_desvio, pais="Portugal", regiao="N/A"):
    
    try:
        with rasterio.open(caminho_tif_desvio) as dataset:
            # Verificar se é território ultramarino francês para usar UTM ao invés de LAEA
            territorios_ultramarinos_franceses = ["Martinique", "Mayotte", "Réunion", "Guadeloupe", "French Guiana"]
            
            if regiao in territorios_ultramarinos_franceses:
                # Para ilhas francesas: usar sistema UTM apropriado baseado na longitude
                utm_zone = int((lon_centro + 180) / 6) + 1
                hemisphere = 'north' if lat_centro >= 0 else 'south'
                target_crs = f"EPSG:326{utm_zone:02d}" if hemisphere == 'north' else f"EPSG:327{utm_zone:02d}"
            else:
                # Para Europa continental: usar sistema LAEA
                target_crs = "IGNF:ETRS89LAEA"
            
            centro_geom_wgs84 = gpd.GeoDataFrame(
                geometry=[Point(lon_centro, lat_centro)], 
                crs="EPSG:4326"
            )
            
            centro_geom_projected = centro_geom_wgs84.to_crs(target_crs)
            centro_x_proj, centro_y_proj = centro_geom_projected.geometry.iloc[0].x, centro_geom_projected.geometry.iloc[0].y
            
            buffer_geom_projected = centro_geom_projected.buffer(raio_m)
            
            buffer_geom = buffer_geom_projected.to_crs(dataset.crs)
            
            centro_x, centro_y = centro_x_proj, centro_y_proj
            
            region_data, region_transform = mask(dataset, buffer_geom.geometry, crop=True)
            region_data = region_data[0]

            return {
                'data': region_data,
                'transform': region_transform,
                'crs': dataset.crs,
                'centro_x': centro_x,
                'centro_y': centro_y
            }
            
    except Exception as e:
        return None

def detectar_desvio_arvores(region_info, desvio_minimo=0.5):

    data = region_info['data']
    transform = region_info['transform']
    crs = region_info['crs']
    
    # Remover valores inválidos (NoData geralmente é 255 ou valores muito altos)
    valid_mask = (data >= desvio_minimo) & (data < 250) & ~np.isnan(data)
    
    # Verificar se há dados válidos
    if not np.any(valid_mask):
        return gpd.GeoDataFrame(columns=['geometry'], crs=crs)
    
    # Obter tamanho real do pixel de desvio
    pixel_size_x = abs(transform.a)
    pixel_size_y = abs(transform.e)
    
    # Encontrar coordenadas dos pixels válidos
    valid_rows, valid_cols = np.where(valid_mask)
    
    pixels_desvio = []
    
    # Processar apenas pixels válidos
    for i in range(len(valid_rows)):
        row, col = valid_rows[i], valid_cols[i]
        desvio_pixel = data[row, col]
        
        # Converter coordenadas de pixel para geográficas (centro do pixel)
        x_center, y_center = rasterio.transform.xy(transform, row, col)
        
        # Criar geometria EXATA do pixel de desvio
        left = x_center - pixel_size_x / 2
        right = x_center + pixel_size_x / 2
        bottom = y_center - pixel_size_y / 2
        top = y_center + pixel_size_y / 2
        
        pixel_geom = geom.Polygon([
            (left, bottom), (right, bottom), 
            (right, top), (left, top), (left, bottom)
        ])
        
        pixels_desvio.append({
            'geometry': pixel_geom,
            'desvio': float(desvio_pixel),
            'row': int(row),
            'col': int(col),
            'centro_x': x_center,
            'centro_y': y_center
        })
    
    # Pixels com desvio significativo detectados
    
    if not pixels_desvio:
        return gpd.GeoDataFrame(columns=['geometry'], crs=crs)
    
    return gpd.GeoDataFrame(pixels_desvio, crs=crs)

def detect_deviation_subpixels(gdf_desvios, all_subpixels, raster_crs):

    if gdf_desvios.empty:
        return []
    
    # Converter desvios para o CRS do raster se necessário
    if raster_crs != gdf_desvios.crs:
        gdf_desvios_proj = gdf_desvios.to_crs(raster_crs)
    else:
        gdf_desvios_proj = gdf_desvios
    
    deviation_subpixels = []
    intersections_found = 0
    
    # Criar índice espacial dos desvios para eficiência
    from shapely.strtree import STRtree
    deviation_geometries = list(gdf_desvios_proj.geometry)
    deviation_tree = STRtree(deviation_geometries)
    
    for i, subpixel in enumerate(all_subpixels):
        # Usar índice espacial para encontrar candidatos próximos
        possible_matches_idx = deviation_tree.query(subpixel)
        
        # Verificar intersecção real com candidatos
        for match_idx in possible_matches_idx:
            deviation_geom = deviation_geometries[match_idx]
            
            # Verificar se há intersecção significativa
            if subpixel.intersects(deviation_geom):
                intersection_area = subpixel.intersection(deviation_geom).area
                subpixel_area = subpixel.area
                overlap_ratio = intersection_area / subpixel_area if subpixel_area > 0 else 0
                
                if overlap_ratio > 0.01:
                    desvio_valor = gdf_desvios.iloc[match_idx]['desvio']
                    deviation_subpixels.append({
                        'index': i,
                        'desvio': desvio_valor
                    })
                    intersections_found += 1
                    break
    
    return deviation_subpixels

def calcular_confidence_arvore(desvio_padrao):

    confidence = 1.0 / (1.0 + (desvio_padrao / 6.0) ** 2)
    return confidence

def calcular_altura_arvore_alternativa(altura_original, desvio_padrao):

    if desvio_padrao <= 2:
        altura_ajustada = altura_original
    else:
        altura_ajustada = altura_original - desvio_padrao
    
    if desvio_padrao >= 8:
        return None

    if altura_ajustada < 4:
        return None
    
    return altura_ajustada

def detect_tree_subpixels(gdf_trees, all_subpixels, raster_crs, gdf_desvio=None, all_subpixels_data=None):

    if gdf_trees.empty:
        return []
    
    if raster_crs != gdf_trees.crs:
        gdf_trees_proj = gdf_trees.to_crs(raster_crs)
    else:
        gdf_trees_proj = gdf_trees
    
    # Converter dados de desvio se disponíveis
    gdf_desvio_proj = None
    if gdf_desvio is not None and not gdf_desvio.empty:
        if raster_crs != gdf_desvio.crs:
            gdf_desvio_proj = gdf_desvio.to_crs(raster_crs)
        else:
            gdf_desvio_proj = gdf_desvio

    tree_subpixels = []
    intersections_found = 0

    # Criar índice espacial das árvores para eficiência
    from shapely.strtree import STRtree
    tree_geometries = list(gdf_trees_proj.geometry)
    tree_tree = STRtree(tree_geometries)
    
    # Criar índice espacial do desvio se disponível
    desvio_tree = None
    desvio_geometries = None
    if gdf_desvio_proj is not None:
        desvio_geometries = list(gdf_desvio_proj.geometry)
        desvio_tree = STRtree(desvio_geometries)
    
    for i, subpixel in enumerate(all_subpixels):
        # Usar índice espacial para encontrar candidatos próximos
        possible_matches_idx = tree_tree.query(subpixel)
        
        # Verificar intersecção real com candidatos
        for match_idx in possible_matches_idx:
            tree_geom = tree_geometries[match_idx]
            
            # Verificar se há intersecção significativa (mais de 1% da área)
            if subpixel.intersects(tree_geom):
                intersection_area = subpixel.intersection(tree_geom).area
                subpixel_area = subpixel.area
                overlap_ratio = intersection_area / subpixel_area if subpixel_area > 0 else 0
                
                # Só considerar se há pelo menos 1% de sobreposição
                if overlap_ratio > 0.01:
                    # Obter altura da árvore correspondente
                    altura_arvore_original = gdf_trees.iloc[match_idx]['altura']
                    
                    # Calcular confiança baseada no desvio padrão
                    confidence = 1.0  # Padrão se não houver dados de desvio
                    desvio_padrao = 0.0
                    
                    if desvio_tree is not None:
                        # Procurar desvio padrão correspondente
                        possible_desvio_idx = desvio_tree.query(subpixel)
                        
                        for desvio_idx in possible_desvio_idx:
                            desvio_geom = desvio_geometries[desvio_idx]
                            
                            if subpixel.intersects(desvio_geom):
                                desvio_padrao = gdf_desvio.iloc[desvio_idx]['desvio']
                                confidence = calcular_confidence_arvore(desvio_padrao)
                                break
                    
                    # APLICAR MÉTODO DE CÁLCULO DA ALTURA (ORIGINAL OU ALTERNATIVO)
                    if metodoUmArvore:
                        # Método original - usar altura sem modificações
                        altura_arvore = altura_arvore_original
                        pixel_valido = True
                    else:
                        # Método alternativo - ajustar altura baseado no desvio padrão
                        altura_arvore = calcular_altura_arvore_alternativa(altura_arvore_original, desvio_padrao)
                        
                        if altura_arvore is None:
                            pixel_valido = False
                        else:
                            pixel_valido = True
                    
                    # APLICAR FILTROS DE CONFIABILIDADE (apenas se método original ou pixel não foi deletado)
                    if pixel_valido and metodoUmArvore:
                        if confidence < 0.4:
                            pixel_valido = False
                        elif 0.4 <= confidence < 0.7 and altura_arvore < 4.0:
                            pixel_valido = False
                    
                    if pixel_valido:                        
                        pixel_id = None
                        landcover_code = None
                        if all_subpixels_data and i < len(all_subpixels_data):
                            pixel_id = all_subpixels_data[i]['pixel_id']
                            landcover_code = all_subpixels_data[i].get('value')
                        
                        tree_subpixels.append({
                            'index': i,
                            'altura': altura_arvore,
                            'desvio': desvio_padrao,
                            'confidence': confidence,
                            'pixel_id': pixel_id,
                            'landcover_code': landcover_code
                        })
                        intersections_found += 1
                    
                    break
    
    return tree_subpixels

def detect_all_tree_subpixels_unfiltered(gdf_trees, all_subpixels, raster_crs, gdf_desvio=None):

    if gdf_trees.empty:
        return []
    
    # Converter árvores para o CRS do raster se necessário
    if raster_crs != gdf_trees.crs:
        gdf_trees_proj = gdf_trees.to_crs(raster_crs)
    else:
        gdf_trees_proj = gdf_trees
    
    # Converter dados de desvio se disponíveis
    gdf_desvio_proj = None
    if gdf_desvio is not None and not gdf_desvio.empty:
        if raster_crs != gdf_desvio.crs:
            gdf_desvio_proj = gdf_desvio.to_crs(raster_crs)
        else:
            gdf_desvio_proj = gdf_desvio
    
    tree_subpixels = []
    intersections_found = 0
    
    # Criar índice espacial das árvores para eficiência
    from shapely.strtree import STRtree
    tree_geometries = list(gdf_trees_proj.geometry)
    tree_tree = STRtree(tree_geometries)
    
    # Criar índice espacial do desvio se disponível
    desvio_tree = None
    desvio_geometries = None
    if gdf_desvio_proj is not None:
        desvio_geometries = list(gdf_desvio_proj.geometry)
        desvio_tree = STRtree(desvio_geometries)
    
    for i, subpixel in enumerate(all_subpixels):
        # Usar índice espacial para encontrar candidatos próximos
        possible_matches_idx = tree_tree.query(subpixel)
        
        # Verificar intersecção real com candidatos
        for match_idx in possible_matches_idx:
            tree_geom = tree_geometries[match_idx]
            
            # Verificar se há intersecção significativa (mais de 1% da área)
            if subpixel.intersects(tree_geom):
                intersection_area = subpixel.intersection(tree_geom).area
                subpixel_area = subpixel.area
                overlap_ratio = intersection_area / subpixel_area if subpixel_area > 0 else 0
                
                # Só considerar se há pelo menos 1% de sobreposição
                if overlap_ratio > 0.01:
                    # Obter altura da árvore correspondente
                    altura_arvore_original = gdf_trees.iloc[match_idx]['altura']
                    
                    # Calcular confiança baseada no desvio padrão (para informação)
                    confidence = 1.0
                    desvio_padrao = 0.0
                    
                    if desvio_tree is not None:
                        # Procurar desvio padrão correspondente
                        possible_desvio_idx = desvio_tree.query(subpixel)
                        
                        for desvio_idx in possible_desvio_idx:
                            desvio_geom = desvio_geometries[desvio_idx]
                            
                            if subpixel.intersects(desvio_geom):
                                desvio_padrao = gdf_desvio.iloc[desvio_idx]['desvio']
                                confidence = calcular_confidence_arvore(desvio_padrao)
                                break
                    
                    if metodoUmArvore:
                        altura_arvore = altura_arvore_original
                        incluir_arvore = True
                    else:
                        altura_arvore = calcular_altura_arvore_alternativa(altura_arvore_original, desvio_padrao)
                        
                        if altura_arvore is None:
                            incluir_arvore = False
                        else:
                            incluir_arvore = True
                    
                    if incluir_arvore:
                        tree_subpixels.append({
                            'index': i,
                            'altura': altura_arvore,
                            'desvio': desvio_padrao,
                            'confidence': confidence
                        })
                        intersections_found += 1
                    
                    break  # Uma vez encontrada intersecção, não precisa verificar outros
    
    return tree_subpixels

def create_unfiltered_trees_map(tree_subpixels_data, all_subpixels, gdf_pixels_web, 
                               lat, lon, radius_meters, pasta_saida):

    if not tree_subpixels_data:
        return
            
    # Configuração inicial do mapa usando função auxiliar
    fig, ax, gdf_center = setup_map_base(lat, lon)
    
    # Criar patches para árvores com cores baseadas na altura (mesmas cores do mapa filtrado)
    tree_patches = []
    tree_colors = []
    confidence_stats = {}
    height_stats = {}
    unique_pixels_for_plot = {}  # Para deduplicate na visualização
    
    for tree_data in tree_subpixels_data:
        idx = tree_data['index']
        altura = tree_data['altura']
        confidence = tree_data['confidence']
        
        # Usar o GeoDataFrame já convertido para Web Mercator
        geom_web = gdf_pixels_web.geometry.iloc[idx] if idx < len(gdf_pixels_web) else None
        
        if geom_web is not None:
            # Usar bounds como chave única para deduplicação visual
            bounds_key = tuple(geom_web.bounds)
            
            # Se já temos este pixel, pular a visualização mas manter estatísticas
            if bounds_key not in unique_pixels_for_plot:
                unique_pixels_for_plot[bounds_key] = True
                mpl_poly = MplPolygon(list(geom_web.exterior.coords), closed=True)
                tree_patches.append(mpl_poly)
                
                # Obter cor baseada na altura (mesma função do mapa filtrado)
                cor = get_tree_height_color(altura)
                tree_colors.append(cor)
            
            # Estatísticas de confiança para informação
            if confidence >= 0.7:
                cat_conf = 'Alta (≥0.7)'
            elif confidence >= 0.4:
                cat_conf = 'Média (0.4-0.7)'
            else:
                cat_conf = 'Baixa (<0.4)'
                
            confidence_stats[cat_conf] = confidence_stats.get(cat_conf, 0) + 1
            
            # Estatísticas por faixa de altura (nova classificação detalhada)
            categoria = get_height_category(altura)
                
            height_stats[categoria] = height_stats.get(categoria, 0) + 1
    
    if tree_patches:
        # Adicionar coleção de árvores
        tree_collection = PatchCollection(tree_patches, 
                                        facecolor=tree_colors, 
                                        edgecolor='darkgreen', 
                                        linewidth=0.1, 
                                        alpha=0.8)
        ax.add_collection(tree_collection)

    # Legenda das árvores por altura
    handles = []
    
    for altura, cor in TREE_HEIGHT_LEGEND.items():
        count = height_stats.get(altura, 0)
        handles.append(Patch(color=cor, label=f'Trees {altura} ({count})'))
    
    ax.legend(handles=handles, bbox_to_anchor=(1.05, 1), loc="upper left")
    
    # Map finalization using helper function
    title = "All Detected Trees (Before Filters)"
    subtitle = f"Center: {lat:.6f}, {lon:.6f} | Radius: {radius_meters}m | Total: {len(tree_subpixels_data)} trees"
    filename = "unfiltered_trees_map.jpg"
    finalize_map(ax, gdf_center, gdf_pixels_web, title, subtitle, pasta_saida, filename)

def create_confidence_map(tree_subpixels_data, all_subpixels, gdf_pixels_web, 
                         lat, lon, radius_meters, pasta_saida):
    """
    Cria um mapa separado baseado nos níveis de confiança das árvores.
    Intervalos de confiança: 0.0-0.1, 0.1-0.2, ..., 0.9-1.0
    """
    if not tree_subpixels_data:
        return

    # Configuração inicial do mapa usando função auxiliar
    fig, ax, gdf_center = setup_map_base(lat, lon)

    # Criar patches para árvores com cores baseadas na confiança
    tree_patches = []
    tree_colors = []
    confidence_stats = {}
    height_stats = {}
    unique_pixels_for_plot = {}  # Para deduplicate na visualização

    for tree_data in tree_subpixels_data:
        idx = tree_data['index']
        altura = tree_data['altura']
        confidence = tree_data['confidence']

        # Usar o GeoDataFrame já convertido para Web Mercator
        geom_web = gdf_pixels_web.geometry.iloc[idx] if idx < len(gdf_pixels_web) else None

        if geom_web is not None:
            # Usar bounds como chave única para deduplicação visual
            bounds_key = tuple(geom_web.bounds)
            
            # Se já temos este pixel, pular a visualização mas manter estatísticas
            if bounds_key not in unique_pixels_for_plot:
                unique_pixels_for_plot[bounds_key] = True
                mpl_poly = MplPolygon(list(geom_web.exterior.coords), closed=True)
                tree_patches.append(mpl_poly)

                # Obter cor baseada na confiança
                cor = get_confidence_color_by_value(confidence)
                tree_colors.append(cor)

            # Estatísticas por faixa de confiança (intervalos de 0.1)
            categoria = get_confidence_category(confidence)
            confidence_stats[categoria] = confidence_stats.get(categoria, 0) + 1

            # Estatísticas por faixa de altura para informação
            cat_altura = get_height_category(altura)
                
            height_stats[cat_altura] = height_stats.get(cat_altura, 0) + 1
    
    if tree_patches:
        # Adicionar coleção de árvores
        tree_collection = PatchCollection(tree_patches, 
                                        facecolor=tree_colors, 
                                        edgecolor='darkblue', 
                                        linewidth=0.1, 
                                        alpha=0.8)
        ax.add_collection(tree_collection)

    # Legenda das árvores por confiança
    handles = []
    confianca_legenda = get_confidence_colors()
    
    for confianca, cor in confianca_legenda.items():
        count = confidence_stats.get(confianca, 0)
        handles.append(Patch(color=cor, label=f'Confidence {confianca}: {count} trees'))
    
    ax.legend(handles=handles, bbox_to_anchor=(1.05, 1), loc="upper left")
    
    # Map finalization using helper function
    title = "Detected Trees Confidence Map"
    subtitle = f"Center: {lat:.6f}, {lon:.6f} | Radius: {radius_meters}m | Total: {len(tree_subpixels_data)} trees"
    filename = "trees_confidence_map.jpg"
    finalize_map(ax, gdf_center, gdf_pixels_web, title, subtitle, pasta_saida, filename)
    
def create_trees_map(tree_subpixels_data, all_subpixels, gdf_pixels_web, lat, lon, radius_meters, pasta_saida):

    if not tree_subpixels_data:
        return
    
    # Configuração inicial do mapa usando função auxiliar
    fig, ax, gdf_center = setup_map_base(lat, lon)
    
    # Criar patches para árvores com cores baseadas na altura
    tree_patches = []
    tree_colors = []
    height_stats = {}
    unique_pixels_for_plot = {}  # Para deduplicate na visualização
    
    for tree_data in tree_subpixels_data:
        idx = tree_data['index']
        altura = tree_data['altura']
        
        # Usar o GeoDataFrame já convertido para Web Mercator
        geom_web = gdf_pixels_web.geometry.iloc[idx] if idx < len(gdf_pixels_web) else None
        
        if geom_web is not None:
            # Usar bounds como chave única para deduplicação visual
            bounds_key = tuple(geom_web.bounds)
            
            # Se já temos este pixel, pular a visualização mas manter estatísticas
            if bounds_key not in unique_pixels_for_plot:
                unique_pixels_for_plot[bounds_key] = True
                mpl_poly = MplPolygon(list(geom_web.exterior.coords), closed=True)
                tree_patches.append(mpl_poly)
                
                # Obter cor baseada na altura
                cor = get_tree_height_color(altura)
                tree_colors.append(cor)
            
            # Estatísticas por faixa de altura
            categoria = get_extended_height_category(altura)
            height_stats[categoria] = height_stats.get(categoria, 0) + 1
    
    if tree_patches:
        # Adicionar coleção de árvores
        tree_collection = PatchCollection(tree_patches, 
                                        facecolor=tree_colors, 
                                        edgecolor='darkgreen', 
                                        linewidth=0.2, 
                                        alpha=0.8)
        ax.add_collection(tree_collection)
    
    # Legenda das árvores por altura
    handles = []
    
    for altura, cor in TREE_HEIGHT_LEGEND.items():
        count = height_stats.get(altura, 0)
        handles.append(Patch(color=cor, label=f'Trees {altura} ({count})'))
    
    ax.legend(handles=handles, bbox_to_anchor=(1.05, 1), loc="upper left")
    
    # Map finalization using helper function
    title = "Canopy Height Tree Analysis"
    subtitle = f"Center: {lat:.6f}, {lon:.6f} | Radius: {radius_meters}m | Total: {len(tree_subpixels_data)} trees"
    filename = "canopy_trees_map.jpg"
    finalize_map(ax, gdf_center, gdf_pixels_web, title, subtitle, pasta_saida, filename)

def create_deviation_map(deviation_subpixels_data, all_subpixels, gdf_pixels_web, lat, lon, radius_meters, pasta_saida):
    """
    Cria uma imagem separada apenas com os dados de desvio padrão das árvores.
    """
    if not deviation_subpixels_data:
        print("Nenhum dado de desvio para gerar mapa")
        return
    
    # Configuração inicial do mapa usando função auxiliar
    fig, ax, gdf_center = setup_map_base(lat, lon)
    
    # Criar patches para desvios com cores baseadas no valor
    deviation_patches = []
    deviation_colors = []
    deviation_stats = {}
    unique_pixels_for_plot = {}  # Para deduplicate na visualização
    
    for deviation_data in deviation_subpixels_data:
        idx = deviation_data['index']
        desvio = deviation_data['desvio']
        
        # Usar o GeoDataFrame já convertido para Web Mercator
        geom_web = gdf_pixels_web.geometry.iloc[idx] if idx < len(gdf_pixels_web) else None
        
        if geom_web is not None:
            # Usar bounds como chave única para deduplicação visual
            bounds_key = tuple(geom_web.bounds)
            
            # Se já temos este pixel, pular a visualização mas manter estatísticas
            if bounds_key not in unique_pixels_for_plot:
                unique_pixels_for_plot[bounds_key] = True
                mpl_poly = MplPolygon(list(geom_web.exterior.coords), closed=True)
                deviation_patches.append(mpl_poly)
                
                # Obter cor baseada no desvio
                cor = get_deviation_color_by_value(desvio)
                deviation_colors.append(cor)
            
            # Estatísticas por faixa de desvio (nova classificação detalhada)
            categoria = get_deviation_category(desvio)
            deviation_stats[categoria] = deviation_stats.get(categoria, 0) + 1
    
    if deviation_patches:
        # Adicionar coleção de desvios
        deviation_collection = PatchCollection(deviation_patches, 
                                            facecolor=deviation_colors, 
                                            edgecolor='darkblue', 
                                            linewidth=0.2, 
                                            alpha=0.8)
        ax.add_collection(deviation_collection)
        
    # Legenda dos desvios por valor (todas as categorias)
    handles = []
    category_values = {
        '0-2m': 1.0, 
        '2-4m': 3.0, 
        '4-6m': 5.0, 
        '6-8m': 7.0, 
        '8-10m': 9.0, 
        '10-12m': 11.0, 
        '12-14m': 13.0, 
        '14-16m': 15.0, 
        '16+m': 17.0
    }
    
    for categoria in ['0-2m', '2-4m', '4-6m', '6-8m', '8-10m', '10-12m', '12-14m', '14-16m', '16+m']:
        count = deviation_stats.get(categoria, 0)
        color = get_deviation_color_by_value(category_values[categoria])
        handles.append(Patch(color=color, label=f'Deviation {categoria} ({count} pixels)'))
    
    ax.legend(handles=handles, bbox_to_anchor=(1.05, 1), loc="upper left")
    
    # Map finalization using helper function
    title = "Trees Height Standard Deviation Analysis"
    subtitle = f"Center: {lat:.6f}, {lon:.6f} | Radius: {radius_meters}m | Total: {len(deviation_subpixels_data)} pixels"
    filename = "trees_deviation_map.jpg"
    finalize_map(ax, gdf_center, gdf_pixels_web, title, subtitle, pasta_saida, filename)
    
def create_buildings_map(building_subpixels_data, all_subpixels, gdf_pixels_web, 
                        lat, lon, radius_meters, pasta_saida):
    
    # Configuração inicial do mapa usando função auxiliar
    fig, ax, gdf_center = setup_map_base(lat, lon)
    
    # Criar patches para edifícios com cores baseadas na altura
    building_patches = []
    building_colors = []
    height_stats = {}
    
    # Garantir que building_subpixels_data não seja None
    if building_subpixels_data is None:
        building_subpixels_data = []
    
    # Criar pixels únicos apenas para visualização (evitar sobreposições visuais)
    unique_buildings_for_plot = {}
    for building_data in building_subpixels_data:
        idx = building_data['index']
        if idx < len(gdf_pixels_web):
            geom_web = gdf_pixels_web.geometry.iloc[idx]
            bounds_key = tuple(geom_web.bounds)
            # Manter apenas o primeiro edifício de cada localização geométrica
            if bounds_key not in unique_buildings_for_plot:
                unique_buildings_for_plot[bounds_key] = building_data
    
    for building_data in unique_buildings_for_plot.values():
        idx = building_data['index']
        altura = building_data['altura']
        
        # Usar o GeoDataFrame já convertido para Web Mercator
        geom_web = gdf_pixels_web.geometry.iloc[idx] if idx < len(gdf_pixels_web) else None
        
        if geom_web is not None:
            mpl_poly = MplPolygon(list(geom_web.exterior.coords), closed=True)
            building_patches.append(mpl_poly)
            
            # Obter cor baseada na altura
            cor = get_building_height_color(altura)
            building_colors.append(cor)
            
            # Estatísticas por faixa de altura
            categoria = get_building_height_category(altura)
                
            height_stats[categoria] = height_stats.get(categoria, 0) + 1
    
    if building_patches:
        # Adicionar coleção de edifícios
        building_collection = PatchCollection(building_patches, 
                                            facecolor=building_colors, 
                                            edgecolor='darkred', 
                                            linewidth=0.2, 
                                            alpha=0.8)
        ax.add_collection(building_collection)
    
    # Legenda dos edifícios por altura
    handles = []
    
    if height_stats:
        for altura, cor in BUILDING_HEIGHT_LEGEND.items():
            count = height_stats.get(altura, 0)
            handles.append(Patch(color=cor, label=f'Buildings {altura} ({count})'))
    else:
        # Mostrar legenda completa quando não há edifícios
        for altura, cor in BUILDING_HEIGHT_LEGEND.items():
            handles.append(Patch(color=cor, label=f'Buildings {altura} (0)', alpha=0.3))
        handles.append(Patch(color='gray', label='No buildings detected', alpha=0.5))
    
    ax.legend(handles=handles, bbox_to_anchor=(1.05, 1), loc="upper left")
    
    # Map finalization using helper function
    title = "Building Height Analysis"
    total_edificios = len(building_subpixels_data) if building_subpixels_data else 0
    subtitle = f"Center: {lat:.6f}, {lon:.6f} | Radius: {radius_meters}m | Total: {total_edificios} buildings"
    filename = "buildings_map.jpg"
    finalize_map(ax, gdf_center, gdf_pixels_web, title, subtitle, pasta_saida, filename)
    
def create_landcover_map(landcover_subpixels_data, all_subpixels, gdf_pixels_web, 
                        lat, lon, radius_meters, pasta_saida):
    """
    Cria uma imagem separada apenas com os dados de cobertura do solo.
    """
    if not landcover_subpixels_data:
        return
    
    # Configuração inicial do mapa usando função auxiliar
    fig, ax, gdf_center = setup_map_base(lat, lon)
    
    # Criar patches para cobertura do solo
    landcover_patches = []
    landcover_colors = []
    category_stats = {}
    
    # Usar as mesmas cores do COLORS do sistema
    COLORS = plt.cm.tab20.colors
    
    # Criar pixels únicos apenas para visualização (evitar sobreposições visuais)
    unique_pixels_for_plot = {}
    for subpixel_data in landcover_subpixels_data:
        idx = subpixel_data['index']
        if idx < len(gdf_pixels_web):
            geom_web = gdf_pixels_web.geometry.iloc[idx]
            bounds_key = tuple(geom_web.bounds)
            # Manter apenas o primeiro pixel de cada localização geométrica
            if bounds_key not in unique_pixels_for_plot:
                unique_pixels_for_plot[bounds_key] = subpixel_data
    
    for subpixel_data in unique_pixels_for_plot.values():
        idx = subpixel_data['index']
        category = subpixel_data['category']
        
        # Usar o GeoDataFrame já convertido para Web Mercator
        geom_web = gdf_pixels_web.geometry.iloc[idx] if idx < len(gdf_pixels_web) else None
        
        if geom_web is not None:
            mpl_poly = MplPolygon(list(geom_web.exterior.coords), closed=True)
            landcover_patches.append(mpl_poly)
            
            # Usar a mesma lógica de cores do sistema principal
            try:
                color_index = list(LANDCOVER_CLASSES.values()).index(category) % len(COLORS)
            except ValueError:
                color_index = hash(category) % len(COLORS)
            
            cor = COLORS[color_index]
            landcover_colors.append(cor)
            
            # Estatísticas por categoria
            category_stats[category] = category_stats.get(category, 0) + 1
    
    if landcover_patches:
        # Adicionar coleção de cobertura do solo
        landcover_collection = PatchCollection(landcover_patches, facecolor=landcover_colors, edgecolor='black', linewidth=0.1, alpha=0.8)
        ax.add_collection(landcover_collection)
    
    # Legenda das principais categorias (limitada para não ficar muito grande)
    handles = []
    main_categories = sorted(category_stats.items(), key=lambda x: x[1], reverse=True)[:15]  # Top 15
    
    for categoria, count in main_categories:
        # Usar a mesma lógica de cores
        try:
            color_index = list(LANDCOVER_CLASSES.values()).index(categoria) % len(COLORS)
        except ValueError:
            color_index = hash(categoria) % len(COLORS)
        
        cor = COLORS[color_index]
        handles.append(Patch(color=cor, label=f'{categoria} ({count})'))
    
    ax.legend(handles=handles, bbox_to_anchor=(1.05, 1), loc="upper left")
    
    # Map finalization using helper function
    title = "Land Cover Analysis"
    subtitle = f"Center: {lat:.6f}, {lon:.6f} | Radius: {radius_meters}m | Total: {len(landcover_subpixels_data)} pixels"
    filename = "landcover_map.jpg"
    finalize_map(ax, gdf_center, gdf_pixels_web, title, subtitle, pasta_saida, filename)

# ==============================
# FUNÇÕES DE DETECÇÃO DE ÁRVORES (ETH CANOPY HEIGHT)
# ==============================

def create_trees_map(tree_subpixels_data, all_subpixels, gdf_pixels_web, 
                    lat, lon, radius_meters, pasta_saida):
    """
    Cria mapa separado mostrando apenas as árvores detectadas.
    """
    # Criar patches para árvores com cores baseadas na altura
    tree_patches = []
    tree_colors = []
    height_stats = {}
    unique_pixels_for_plot = {}  # Para deduplicate na visualização
    
    for tree_data in tree_subpixels_data:
        idx = tree_data['index']
        altura = tree_data['altura']
        
        # Usar geometria do subpixel já convertida
        geom_web = gdf_pixels_web.geometry.iloc[idx] if idx < len(gdf_pixels_web) else None
        
        if geom_web is not None:
            # Usar bounds como chave única para deduplicação visual
            bounds_key = tuple(geom_web.bounds)
            
            # Se já temos este pixel, pular a visualização mas manter estatísticas
            if bounds_key not in unique_pixels_for_plot:
                unique_pixels_for_plot[bounds_key] = True
                mpl_poly = MplPolygon(list(geom_web.exterior.coords), closed=True)
                tree_patches.append(mpl_poly)
                
                # Obter cor baseada na altura
                cor = get_tree_height_color(altura)
                tree_colors.append(cor)
            
            # Estatísticas por faixa de altura
            categoria = get_extended_height_category(altura)
            height_stats[categoria] = height_stats.get(categoria, 0) + 1

    if not tree_patches:
        return

    # Configuração inicial do mapa usando função auxiliar
    fig, ax, gdf_center = setup_map_base(lat, lon)

    # Adicionar coleção de árvores
    tree_collection = PatchCollection(tree_patches, 
                                    facecolor=tree_colors, 
                                    edgecolor='darkgreen', 
                                    linewidth=0.2, 
                                    alpha=0.8)
    ax.add_collection(tree_collection)

    # Definir limites baseados nas árvores
    if tree_patches:
        # Calcular bounds das árvores
        all_coords = []
        for patch in tree_patches:
            coords = patch.get_path().vertices
            all_coords.extend(coords)
        
        if all_coords:
            xs, ys = zip(*all_coords)
            minx_trees, maxx_trees = min(xs), max(xs)
            miny_trees, maxy_trees = min(ys), max(ys)
            
            # Adicionar buffer
            buffer_x = (maxx_trees - minx_trees) * 0.1
            buffer_y = (maxy_trees - miny_trees) * 0.1
            
            ax.set_xlim(minx_trees - buffer_x, maxx_trees + buffer_x)
            ax.set_ylim(miny_trees - buffer_y, maxy_trees + buffer_y)

    # Legenda das árvores por altura (nova classificação detalhada)
    handles = []
    arvores_legenda = get_tree_detailed_colors()
    
    for altura, cor in arvores_legenda.items():
        count = height_stats.get(altura, 0)
        label = f'Trees {altura} ({count})'
        handles.append(Patch(color=cor, label=label))

    if handles:
        ax.legend(handles=handles, bbox_to_anchor=(1.05, 1), loc="upper left")

    # Título e finalização usando função utilitária
    total_trees = len(tree_subpixels_data)
    title = f"DETECTED TREES MAP ({total_trees} trees)"
    subtitle = f"ETH Global Canopy Height 2020 | Center: {lat:.6f}, {lon:.6f} | Radius: {radius_meters}m"
    
    finalize_map(ax, gdf_center, gdf_pixels_web, title, subtitle, pasta_saida, "canopy_trees_height_map.jpg")

# ==============================
# FUNÇÕES PRINCIPAIS
# ==============================

def split_circle_into_sectors(lat, lon, radius_m, n_sectors, target_crs):
    # Primeiro, criar os setores em coordenadas geográficas (WGS84)
    # Conversão aproximada de metros para graus
    radius_deg_lat = radius_m / 111320  # 1 grau de latitude ≈ 111.32 km
    radius_deg_lon = radius_m / (111320 * math.cos(math.radians(lat)))  # Ajustado pela latitude

    sectors = []
    angle_step = 360 / n_sectors
    # Rotacionar para a esquerda por metade do ângulo de um setor para que 
    # o centro da primeira fatia aponte para o norte (0°)
    rotation_offset = -angle_step / 2

    for i in range(n_sectors):
        # Criar setores em coordenadas geográficas, começando do norte (0°) com rotação
        angle1 = math.radians(i * angle_step + rotation_offset)
        angle2 = math.radians((i + 1) * angle_step + rotation_offset)
        
        # Criar setor circular real com múltiplos pontos na borda
        num_pontos_arco = 20  # Número de pontos para criar o arco circular
        points_geo = [(lon, lat)]  # Começar do centro
        
        # Adicionar pontos ao longo do arco circular
        for j in range(num_pontos_arco + 1):
            # Interpolar entre angle1 e angle2
            t = j / num_pontos_arco
            angle = angle1 + t * (angle2 - angle1)
            lon_point = lon + radius_deg_lon * math.sin(angle)
            lat_point = lat + radius_deg_lat * math.cos(angle)
            points_geo.append((lon_point, lat_point))
        
        # Fechar o polígono voltando ao centro
        points_geo.append((lon, lat))
        
        # Criar polígono em WGS84
        sector_geo = geom.Polygon(points_geo)
        
        # Converter para o sistema de coordenadas do raster
        if target_crs != "EPSG:4326":
            from shapely.ops import transform
            transformer = Transformer.from_crs("EPSG:4326", target_crs, always_xy=True)
            sector_projected = transform(transformer.transform, sector_geo)
            sectors.append(sector_projected)
        else:
            sectors.append(sector_geo)

    return sectors

def calculate_dynamic_ring_radii(radius_meters, growth_factor=1.05, max_rings=50):

    ring_widths = []
    ring_radii = []
    raio_medio = []

    # Primeiro anel: F1 = 0.1 * radius_meters
    f1 = 0.1 * radius_meters
    ring_widths.append(f1)
    ring_radii.append(f1)
    raio_medio.append(f1 / 2)
    
    # Calcular anéis subsequentes: Fn+1 = Fn * growth_factor
    current_f = f1
    total_width = f1
    ring_count = 1
    
    while (total_width < radius_meters and ring_count < max_rings):
        # Próximo anel é o anterior multiplicado pelo fator de crescimento
        next_f = current_f * growth_factor
        ring_widths.append(next_f)
        total_width += next_f
        ring_radii.append(total_width)
        current_f = next_f
        ring_count += 1
        raio_medio.append(total_width - (current_f / 2) )
    
    # O raio total ajustado é a soma de todos os anéis
    adjusted_total_radius = total_width
    
    # Cálculo dinâmico de anéis configurado
    
    return ring_radii, adjusted_total_radius, raio_medio

def divide_sectors_concentrically(sectors, lat, lon, radius_m, target_crs, ring_radii, raio_medio):
    """
    Divide cada setor em múltiplos anéis concêntricos usando raios pré-calculados.
    
    Args:
        sectors: Lista de setores originais
        lat, lon: Coordenadas do centro
        radius_m: Raio total em metros
        target_crs: Sistema de coordenadas do raster
        ring_radii: Lista com os raios dos anéis já calculados
        raio_medio: Lista com os raios médios de cada anel
    """
    divided_sectors = []
    
    # Usar raios dos anéis já calculados
    n_rings_dynamic = len(ring_radii)
    
    # Criar círculos para cada anel (do centro para fora)
    circles = []
    for i, ring_radius in enumerate(ring_radii):
        
        radius_deg_lat = ring_radius / 111320
        radius_deg_lon = ring_radius / (111320 * math.cos(math.radians(lat)))
        
        # Círculo em coordenadas geográficas com mais pontos para maior precisão
        num_pontos = 100  # Aumentado de 50 para 100 para círculos mais suaves
        points = []
        for j in range(num_pontos):
            angle = 2 * math.pi * j / num_pontos
            lon_point = lon + radius_deg_lon * math.sin(angle)
            lat_point = lat + radius_deg_lat * math.cos(angle)
            points.append((lon_point, lat_point))
        points.append(points[0])  # Fechar círculo
        
        circle_geo = geom.Polygon(points)
        
        # Converter para CRS do raster se necessário
        if target_crs != "EPSG:4326":
            from shapely.ops import transform
            transformer = Transformer.from_crs("EPSG:4326", target_crs, always_xy=True)
            circle = transform(transformer.transform, circle_geo)
        else:
            circle = circle_geo
            
        circles.append(circle)
    
    # Criar anéis para cada setor
    for i, sector in enumerate(sectors):
        # Primeiro anel (centro) - com buffer negativo para evitar sobreposições
        first_ring = sector.intersection(circles[0])
        # CORREÇÃO: Aplicar buffer negativo pequeno para eliminar sobreposições
        if first_ring.area > 0:
            first_ring = first_ring.buffer(-0.01)
        
        divided_sectors.append({
            'geometry': first_ring,
            'type': f'anel_1',
            'ring_number': 1,
            'original_sector': i + 1,
            'sector_id': f"{i+1}_anel_1",
            'radius_range': f"0-{ring_radii[0]:.1f}m",
            'raio_medio': raio_medio[0]
        })
        
        # Anéis intermediários e externos - com buffer negativo
        for ring in range(1, n_rings_dynamic):
            # Anel = círculo_atual - círculo_anterior
            ring_geom = sector.intersection(circles[ring].difference(circles[ring-1]))
            
            # CORREÇÃO: Aplicar buffer negativo pequeno para eliminar sobreposições
            if ring_geom.area > 0:
                ring_geom = ring_geom.buffer(-0.01)
            
            radius_start = ring_radii[ring-1]
            radius_end = ring_radii[ring]
            
            divided_sectors.append({
                'geometry': ring_geom,
                'type': f'anel_{ring + 1}',
                'ring_number': ring + 1,
                'original_sector': i + 1,
                'sector_id': f"{i+1}_anel_{ring + 1}",
                'radius_range': f"{radius_start:.1f}-{radius_end:.1f}m",
                'raio_medio': raio_medio[ring]
            })
    
    return divided_sectors

def get_raster_pixels_in_geometry(tiff_path, geometry, lat=None, lon=None):
    """
    Obtém todos os pixels do raster que estão dentro da geometria especificada.
    Retorna uma lista de dicionários com informações de cada pixel.
    """
    with rasterio.open(tiff_path) as src:
        raster_crs = src.crs
        transform = src.transform
        
        # A geometria já deve estar no CRS correto
        # Obter bounds da geometria com uma pequena margem para evitar truncamento
        minx, miny, maxx, maxy = geometry.bounds
        
        # Adicionar uma pequena margem (equivalente a meio pixel) para garantir cobertura completa
        pixel_size_x = abs(transform.a)
        pixel_size_y = abs(transform.e)
        margin_x = pixel_size_x * 0.5
        margin_y = pixel_size_y * 0.5
        
        minx -= margin_x
        miny -= margin_y
        maxx += margin_x
        maxy += margin_y
        
        # Obter janela do raster
        try:
            window = src.window(minx, miny, maxx, maxy)
            # Ler dados da janela
            data_windowed = src.read(1, window=window)
            transform_windowed = src.window_transform(window)
            
            pixels_info = []
            rows, cols = data_windowed.shape
            
            for row in range(rows):
                for col in range(cols):
                    # Obter coordenadas do centro do pixel
                    pixel_x, pixel_y = rasterio.transform.xy(transform_windowed, row, col)
                    
                    # Criar geometria do pixel primeiro
                    pixel_size_x = abs(transform_windowed.a)
                    pixel_size_y = abs(transform_windowed.e)
                    
                    # Coordenadas dos cantos do pixel
                    left = pixel_x - pixel_size_x / 2
                    right = pixel_x + pixel_size_x / 2
                    bottom = pixel_y - pixel_size_y / 2
                    top = pixel_y + pixel_size_y / 2
                    
                    pixel_geom = geom.Polygon([
                        (left, bottom), (right, bottom), 
                        (right, top), (left, top), (left, bottom)
                    ])
                    
                    # Verificar se o pixel intersecta com a geometria
                    # Usar múltiplas condições para garantir inclusão completa dos pixels na borda
                    pixel_center = geom.Point(pixel_x, pixel_y)
                    
                    # Incluir pixel se:
                    # 1. A geometria do pixel intersecta com a geometria alvo
                    # 2. O centro do pixel está dentro da geometria
                    # 3. O pixel está muito próximo da borda (dentro de uma tolerância)
                    intersects = (pixel_geom.intersects(geometry) or geometry.contains(pixel_center) or geometry.distance(pixel_center) < max(pixel_size_x, pixel_size_y) * 0.1)
                    
                    if intersects:
                        # Calcular a área de intersecção para informação adicional
                        try:
                            intersection_area = pixel_geom.intersection(geometry).area
                            pixel_area = pixel_geom.area
                            coverage_ratio = intersection_area / pixel_area if pixel_area > 0 else 0
                        except:
                            # Em caso de erro geométrico, assumir cobertura total
                            coverage_ratio = 1.0
                        
                        pixel_value = data_windowed[row, col]
                        
                        # Calcular distância do centro da geometria para informação adicional
                        geom_center = geometry.centroid
                        if "EPSG:4326" in str(raster_crs) and lat is not None:
                            dx = (pixel_x - geom_center.x) * 111320 * math.cos(math.radians(lat))
                            dy = (pixel_y - geom_center.y) * 111320
                            distance = math.sqrt(dx*dx + dy*dy)
                        else:
                            distance = math.sqrt((pixel_x - geom_center.x)**2 + (pixel_y - geom_center.y)**2)
                        
                        pixels_info.append({
                            'geometry': pixel_geom,
                            'value': int(pixel_value) if pixel_value > 0 else 0,
                            'center_x': pixel_x,
                            'center_y': pixel_y,
                            'distance_from_center': distance,
                            'coverage_ratio': coverage_ratio,
                            'row': row,
                            'col': col
                        })
            
            return pixels_info, raster_crs
            
        except Exception as e:
            return [], None

def analyze_pixels_data(pixels_info):

    if not pixels_info:
        return {}, {}
    
    # Filtrar pixels válidos (sem NoData)
    valid_pixels = [p for p in pixels_info if p['value'] > 0]
    
    if not valid_pixels:
        return {}, {}
    
    # Calcular percentagens por classe
    values = [p['value'] for p in valid_pixels]
    unique, counts = np.unique(values, return_counts=True)
    total_pixels = len(valid_pixels)
    
    percentages = {}
    for val, count in zip(unique, counts):
        category = LANDCOVER_CLASSES.get(int(val), f"Classe_{val}")
        percentage = round(count / total_pixels * 100, 2)
        percentages[category] = percentage
    
    # Agrupar pixels por valor para colorização
    pixels_by_value = {}
    for pixel in valid_pixels:
        value = pixel['value']
        if value not in pixels_by_value:
            pixels_by_value[value] = []
        pixels_by_value[value].append(pixel)
    
    return percentages, pixels_by_value

def create_dhm_aligned_subpixels(pixel, dhm_transform):
    """
    Cria subpixels de 10x10m alinhados com a grade do DHM.
    """
    from shapely.geometry import Polygon
    
    geom_pixel = pixel['geometry']
    minx, miny, maxx, maxy = geom_pixel.bounds
    
    # Obter informações da grade DHM
    dhm_pixel_size = abs(dhm_transform.a)  # ~10m
    dhm_origin_x = dhm_transform.c
    dhm_origin_y = dhm_transform.f
    
    # Calcular o alinhamento com a grade DHM
    # Encontrar o primeiro pixel DHM que intersecta a área do pixel CLC
    start_col = int((minx - dhm_origin_x) / dhm_pixel_size)
    start_row = int((dhm_origin_y - maxy) / dhm_pixel_size)
    
    # Calcular quantos pixels DHM cabem no pixel CLC (deveria ser ~10x10)
    n_cols = int((maxx - minx) / dhm_pixel_size)
    n_rows = int((maxy - miny) / dhm_pixel_size)
    
    aligned_subpixels = []
    
    for row_offset in range(n_rows):
        for col_offset in range(n_cols):
            # Coordenadas do pixel DHM
            dhm_col = start_col + col_offset
            dhm_row = start_row + row_offset
            
            # Converter para coordenadas geográficas usando o transform do DHM
            dhm_x = dhm_origin_x + (dhm_col + 0.5) * dhm_pixel_size
            dhm_y = dhm_origin_y - (dhm_row + 0.5) * dhm_pixel_size
            
            # Criar geometria do subpixel alinhado com DHM
            half_pixel = dhm_pixel_size / 2
            subpixel_geom = Polygon([
                (dhm_x - half_pixel, dhm_y - half_pixel),
                (dhm_x + half_pixel, dhm_y - half_pixel),
                (dhm_x + half_pixel, dhm_y + half_pixel),
                (dhm_x - half_pixel, dhm_y + half_pixel),
                (dhm_x - half_pixel, dhm_y - half_pixel)
            ])
            
            # Verificar se o subpixel está dentro do pixel CLC original
            if geom_pixel.intersects(subpixel_geom):
                aligned_subpixels.append(subpixel_geom)
    
    return aligned_subpixels



def calcular_z0_e_d_arvore(altura, landcover_code=None, logger=None, pixel_id=None):
    """
    Calcula Z0 e d para uma árvore baseado na sua altura e land cover subjacente.
    OTIMIZADO: Usa dicionário unificado para acesso direto aos valores alfaArvores.
    
    Args:
        altura: Altura da árvore em metros
        landcover_code: Código CLC do land cover subjacente (opcional)
        logger: Logger opcional para registrar cálculos
        pixel_id: ID do pixel para logging
        
    Returns:
        dict: Dicionário com z0 e d calculados
    """
    # Método tradicional (fallback)
    z0_tradicional_raw = 0.15 * altura
    z0_tradicional = min(z0_tradicional_raw, 2.0)
    d_tradicional = 0.67 * altura
    
    # Se há land cover, usar nova fórmula otimizada com alfaArvores
    if landcover_code is not None and landcover_code in LANDCOVER_COMPLETE_VALUES:
        # OTIMIZAÇÃO: Acesso direto aos valores pré-calculados
        lc_values = LANDCOVER_COMPLETE_VALUES[landcover_code]
        alfaArvores = lc_values['alfaArvores']
        
        # Calcular Z0: z0 = min(alfaArvores * altura, 2)
        z0_final = min(alfaArvores * altura, 2.0)
        d_final = d_tradicional  # d mantém a mesma fórmula
        
        usa_landcover = True
        formula_used = f"z0 = min({alfaArvores} * {altura}, 2) = {z0_final}"

    else:
        # Usar fórmula tradicional
        z0_final = z0_tradicional
        d_final = d_tradicional
        usa_landcover = False
        formula_used = f"z0 = min(0.15 * {altura}, 2.0) = {z0_final} (tradicional)"

    # Log do cálculo se logger fornecido
    if logger and pixel_id:
        logger.log_z0_calculation(
            pixel_id=pixel_id,
            pixel_type="tree",
            input_data={
                "altura": altura,
                "landcover_code": landcover_code,
                "usa_landcover": usa_landcover,
                "z0_final": z0_final,
                "z0_tradicional": z0_tradicional
            },
            z0_result=z0_final,
            formula_used=formula_used
        )
    
    return {
        'z0': round(z0_final, 3),
        'd': round(d_final, 3),
        'usa_landcover': usa_landcover,
        'z0_tradicional': round(z0_tradicional, 3)
    }

def calcular_z0_e_d_edificio(altura, landcover_code=None, logger=None, pixel_id=None):
    """
    Calcula Z0 e d para um edifício baseado na sua altura e land cover subjacente.
    OTIMIZADO: Usa dicionário unificado para acesso direto aos valores.
    
    Args:
        altura: Altura do edifício em metros
        landcover_code: Código CLC do land cover subjacente (opcional)
        logger: Logger opcional para registrar cálculos
        pixel_id: ID do pixel para logging
        
    Returns:
        dict: Dicionário com z0 e d calculados
    """
    # Método tradicional (fallback)
    z0_tradicional_raw = 0.123 * altura
    z0_tradicional = min(z0_tradicional_raw, 2.0)
    d_tradicional = 0.67 * altura
    
    # Se há land cover, usar nova fórmula otimizada
    if landcover_code is not None and landcover_code in LANDCOVER_COMPLETE_VALUES:
        # OTIMIZAÇÃO: Acesso direto aos valores pré-calculados
        lc_values = LANDCOVER_COMPLETE_VALUES[landcover_code]
        alfaBuilding = lc_values['alfaBuilding']
        
        # Calcular Z0: z0 = min(alfaBuilding * altura, 2)
        z0_final = min(alfaBuilding * altura, 2.0)
        d_final = d_tradicional  # d mantém a mesma fórmula
        
        usa_landcover = True
        formula_used = f"z0 = min({alfaBuilding} * {altura}, 2) = {z0_final}"
        
    else:
        # Usar fórmula tradicional
        z0_final = z0_tradicional
        d_final = d_tradicional
        usa_landcover = False
        formula_used = f"z0 = min(0.123 * {altura}, 2.0) = {z0_final} (tradicional)"
        
    # Log do cálculo se logger fornecido
    if logger and pixel_id:
        logger.log_z0_calculation(
            pixel_id=pixel_id,
            pixel_type="building",
            input_data={
                "altura": altura,
                "landcover_code": landcover_code,
                "usa_landcover": usa_landcover,
                "z0_final": z0_final,
                "z0_tradicional": z0_tradicional
            },
            z0_result=z0_final,
            formula_used=formula_used
        )
    
    return {
        'z0': round(z0_final, 3),
        'd': round(d_final, 3),
        'usa_landcover': usa_landcover,
        'z0_tradicional': round(z0_tradicional, 3)
    }

def calcular_z0_landcover(category, codigo_clc, logger=None, pixel_id=None):
    """
    Calcula Z0 para land cover usando dicionário unificado OTIMIZADO.
    
    Args:
        category: Categoria do land cover (string) - usado apenas para logging
        codigo_clc: Código CLC do tipo de cobertura do solo (CODE_12)
        logger: Logger opcional para registrar cálculos
        pixel_id: ID do pixel para logging
        
    Returns:
        float: Valor de Z0 para o tipo de land cover
    """
    # DEBUG: Mostrar valores sendo processados (apenas primeiros 10 para não spam)
    # OTIMIZAÇÃO: Acesso direto ao dicionário unificado
    if codigo_clc in LANDCOVER_COMPLETE_VALUES:
        z0_value = LANDCOVER_COMPLETE_VALUES[codigo_clc]['z0']

    else:
        z0_value = 0.1  # Valor padrão
    
    # Obter nome da categoria pelo código
    category_name = LANDCOVER_CLASSES.get(codigo_clc, f"Classe_{codigo_clc}")
    
    # Log do cálculo se logger fornecido
    if logger and pixel_id:
        logger.log_z0_calculation(
            pixel_id=pixel_id,
            pixel_type="landcover",
            input_data={
                "codigo_clc": codigo_clc,
                "category_name": category_name,
                "found_in_z0_map": codigo_clc in LANDCOVER_Z0_VALUES,
                "used_default": codigo_clc not in LANDCOVER_Z0_VALUES,
                "default_value": 0.1
            },
            z0_result=z0_value,
            formula_used="Lookup direto por código CODE_12 ou valor padrão 0.1"
        )
    
    return z0_value

def calcular_d_landcover(category, codigo_clc):
    """
    Calcula altura de deslocamento (d) para land cover usando dicionário unificado OTIMIZADO.
    
    Args:
        category: Categoria do land cover (string) - mantido para compatibilidade
        codigo_clc: Código CLC do tipo de cobertura do solo
        
    Returns:
        float: Valor de d (displacement height) para o tipo de land cover
    """
    # OTIMIZAÇÃO: Acesso direto ao dicionário unificado
    if codigo_clc in LANDCOVER_COMPLETE_VALUES:
        return LANDCOVER_COMPLETE_VALUES[codigo_clc]['d']
    else:
        return 0.05  # Valor padrão

# ==============================
# FUNÇÕES PARA MAPAS DE Z0
# ==============================

def create_z0_map(landcover_subpixels_data, building_subpixels_data, tree_subpixels_data,
                  all_subpixels, gdf_pixels_web, lat, lon, radius_meters, pasta_saida):
    """
    Cria um mapa separado focado nos valores de Z0 de todos os pixels.
    Combina Z0 de landcover, edifícios e árvores com cores em gradiente roxo → amarelo.
    """

    # Configuração inicial do mapa usando função auxiliar
    fig, ax, gdf_center = setup_map_base(lat, lon)
    
    # Coletar todos os valores de Z0 para determinar range real
    all_z0_values = []
    pixel_z0_data = {}  # idx -> {'z0': value, 'type': 'landcover'/'building'/'tree'}
    
    # 1. Processar landcover (base)
    if landcover_subpixels_data:
        codigos_unicos = set()
        
        for i, sp in enumerate(landcover_subpixels_data):
            idx = sp.get('original_index', sp.get('index', i))
            if idx >= 0:
                codigo_clc = sp.get('value', 0)
                category = sp.get('category', 'Unknown')
                codigos_unicos.add(codigo_clc)
                
                # Passar pixel_id para debug
                pixel_id = sp.get('pixel_id', i+1)
                z0_landcover = calcular_z0_landcover(category, codigo_clc, pixel_id=pixel_id)
                pixel_z0_data[idx] = {'z0': z0_landcover, 'type': 'landcover', 'category': category}
                all_z0_values.append(z0_landcover)
    
    # 2. Processar edifícios (sobrescreve landcover se houver)  
    if building_subpixels_data:
        for building_data in building_subpixels_data:
            idx = building_data['index']
            altura = building_data['altura']
            
            # Obter informações do land cover se disponível
            landcover_code = building_data.get('landcover_code')
            
            # Calcular Z0 considerando o land cover subjacente
            parametros = calcular_z0_e_d_edificio(altura, landcover_code)
            z0_edificio = parametros['z0']
            
            pixel_z0_data[idx] = {
                'z0': z0_edificio, 
                'type': 'building', 
                'altura': altura,
                'landcover_code': landcover_code,
                'usa_landcover': parametros.get('usa_landcover', False)
            }
            all_z0_values.append(z0_edificio)
    
    # 3. Processar árvores (sobrescreve landcover/edifícios se houver)
    if tree_subpixels_data:
        for tree_data in tree_subpixels_data:
            idx = tree_data['index']
            altura = tree_data['altura']
            
            # Obter informações do land cover se disponível
            landcover_code = tree_data.get('landcover_code')
            
            # Calcular Z0 considerando o land cover subjacente
            parametros = calcular_z0_e_d_arvore(altura, landcover_code)
            z0_arvore = parametros['z0']
            
            pixel_z0_data[idx] = {
                'z0': z0_arvore, 
                'type': 'tree', 
                'altura': altura,
                'landcover_code': landcover_code,
                'usa_landcover': parametros.get('usa_landcover', False)
            }
            all_z0_values.append(z0_arvore)
    
    if not all_z0_values:
        return
    
    # Estatísticas dos valores Z0
    min_z0 = min(all_z0_values)
    max_z0 = max(all_z0_values)
    mean_z0 = sum(all_z0_values) / len(all_z0_values)
        
    # Criar patches com cores baseadas em Z0
    z0_patches = []
    z0_colors = []
    z0_stats = {'landcover': 0, 'building': 0, 'tree': 0}
    unique_pixels_for_plot = {}  # Para deduplicate na visualização
    
    for idx, data in pixel_z0_data.items():
        if idx < len(gdf_pixels_web):
            pixel_geom_web = gdf_pixels_web.geometry.iloc[idx]
            z0_value = data['z0']
            pixel_type = data['type']
            
            # Usar bounds como chave única para deduplicação visual
            bounds_key = tuple(pixel_geom_web.bounds)
            
            # Se já temos este pixel, pular a visualização mas manter estatísticas
            if bounds_key not in unique_pixels_for_plot:
                unique_pixels_for_plot[bounds_key] = True
                # Adicionar patch
                mpl_poly = MplPolygon(list(pixel_geom_web.exterior.coords), closed=True)
                z0_patches.append(mpl_poly)
                
                # Cor baseada no valor Z0
                cor = get_z0_color_by_value(z0_value)
                z0_colors.append(cor)
            
            # Estatísticas por tipo (manter sempre, mesmo com deduplicação)
            z0_stats[pixel_type] += 1
    
    if z0_patches:
        z0_collection = PatchCollection(z0_patches, 
                                       facecolor=z0_colors,
                                       edgecolor='white',
                                       linewidth=0.1,
                                       alpha=0.9)
        ax.add_collection(z0_collection)
    
    # Plotar centro
    gdf_center.plot(ax=ax, color='red', markersize=200, marker='*', edgecolor='white', linewidth=2)
    
    # Limites do mapa com buffer padronizado
    if gdf_pixels_web.empty:
        plt.close()
        return
        
    minx_map, miny_map, maxx_map, maxy_map = gdf_pixels_web.total_bounds
    # Adicionar buffer de 15% para padronizar distância das bordas
    buffer = radius_meters * 0.15
    ax.set_xlim(minx_map - buffer, maxx_map + buffer)
    ax.set_ylim(miny_map - buffer, maxy_map + buffer)
    ax.set_aspect('equal')
    
    # Adicionar mapa base
    import contextily as ctx
    _adicionar_mapa_base(ax)


    
    # Colorbar -- a UNICA da solucao, partilhada por todos os mapas
    # circulares (mapas_circulares.adicionar_colorbar_padrao).
    import matplotlib.colors as mcolors
    try:
        colormap = plt.colormaps.get_cmap('viridis')
    except (AttributeError, KeyError):
        from matplotlib import cm
        colormap = cm.get_cmap('viridis')
    norm = mcolors.Normalize(vmin=0, vmax=2)
    adicionar_colorbar_padrao(ax, colormap, norm, fmt="{:.2f}")

    # Remover eixos do mapa principal
    ax.set_axis_off()

    # Save image using optimized structure with padding padronizado
    filename = f"z0_map.jpg"
    pasta_imagens = os.path.join(pasta_saida, "imagens")
    os.makedirs(pasta_imagens, exist_ok=True)
    caminho_completo = os.path.join(pasta_imagens, filename)
    plt.tight_layout(pad=0.5)  # Padding reduzido e fixo
    plt.savefig(caminho_completo, dpi=300, bbox_inches='tight', pad_inches=0.1, format='jpeg')
    plt.close()

    # Calculate total_pixels for return
    total_pixels = len(pixel_z0_data)

    return {
        'total_pixels': total_pixels,
        'z0_range': {'min': min_z0, 'max': max_z0, 'mean': mean_z0},
        'type_distribution': z0_stats,
        'filename': filename
    }

def create_individual_sector_map(sector_info, sector_subpixels_data, building_subpixels_data, tree_subpixels_data,
                                all_subpixels, lat, lon, radius_meters, raster_crs, pasta_saida, sector_index, generate_image=True):
    """
    Processa dados de um setor específico e opcionalmente cria uma imagem. Sempre retorna estatísticas.
    
    Args:
        sector_info: Informações do setor (geometria, ID, etc.)
        sector_subpixels_data: Dados dos subpixels válidos do setor
        building_subpixels_data: Dados dos edifícios
        tree_subpixels_data: Dados das árvores
        all_subpixels: Lista completa de todos os subpixels para obter geometrias
        lat, lon: Coordenadas centrais
        radius_meters: Raio em metros
        raster_crs: Sistema de coordenadas do raster
        pasta_saida: Pasta para salvar a imagem
        sector_index: Índice do setor (para nomeação)
        generate_image: Se True, gera a imagem; se False, apenas processa os dados
        
    Returns:
        dict: Estatísticas das árvores/edifícios processados neste setor
    """
    if not sector_subpixels_data:
        return
    
    # Converter geometrias para Web Mercator (só se necessário para imagem)
    sector_geometry = sector_info['geometry']
    
    if generate_image:
        # Criar GeoDataFrame do setor
        gdf_sector = gpd.GeoDataFrame(geometry=[sector_geometry], crs=raster_crs)
        gdf_sector_web = gdf_sector.to_crs(epsg=3857) if raster_crs != "EPSG:3857" else gdf_sector
        
        # Criar subpixels do setor
        subpixels_geom = [sp['geometry'] for sp in sector_subpixels_data]
        gdf_subpixels = gpd.GeoDataFrame(geometry=subpixels_geom, crs=raster_crs)
        gdf_subpixels_web = gdf_subpixels.to_crs(epsg=3857) if raster_crs != "EPSG:3857" else gdf_subpixels
    
    # Cores dos subpixels baseadas em Z0 (não categóricas) para land cover
    subpixel_colors = []
    landcover_detalhes = []  # Lista para armazenar detalhes de Z0 de cada subpixel
    
    for sp in sector_subpixels_data:
        category = sp['category']
        
        # CALCULAR Z0 PARA ESTE SUBPIXEL DE LAND COVER
        codigo_clc = sp.get('value', 0)  # Obter código CLC original
        z0_landcover = calcular_z0_landcover(category, codigo_clc)
        
        # USAR COR BASEADA NO VALOR Z0 (não categórica)
        cor_z0 = get_z0_color_by_value(z0_landcover)
        subpixel_colors.append(cor_z0)
        
        # Armazenar detalhes do subpixel
        landcover_detalhes.append({
            'index': sp.get('index', -1),  # Usar índice correto dos dados
            'codigo_clc': codigo_clc,
            'category': category,
            'z0': z0_landcover,
            'geometry': sp['geometry']
        })
    
    # Parâmetros Z0 calculados silenciosamente
    
    # Inicializar variáveis para visualização (só se necessário)
    if generate_image:
        # Criar ponto central
        transformer_to_web = Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
        center_x_web, center_y_web = transformer_to_web.transform(lon, lat)
        gdf_center = gpd.GeoDataFrame(geometry=[Point(center_x_web, center_y_web)], crs="EPSG:3857")
        
        # Criar figura (mesmo figsize dos outros mapas -- ver nota em
        # mapas_circulares.desenhar_mapa_circular)
        fig, ax = plt.subplots(figsize=(15, 15))

        # 1º Plotar subpixels de cobertura do solo
        patches = []
        unique_colors = []
        unique_pixels_for_plot = {}  # Para deduplicate na visualização do setor
        
        for poly, color in zip(gdf_subpixels_web.geometry, subpixel_colors):
            # Usar bounds como chave única para deduplicação visual
            bounds_key = tuple(poly.bounds)
            
            # Se já temos este pixel, pular a visualização
            if bounds_key not in unique_pixels_for_plot:
                unique_pixels_for_plot[bounds_key] = True
                mpl_poly = MplPolygon(list(poly.exterior.coords), closed=True)
                patches.append(mpl_poly)
                unique_colors.append(color)
        
        collection = PatchCollection(patches, facecolor=unique_colors, edgecolor='white', linewidth=0.1, alpha=0.8)
        ax.add_collection(collection)
        
        # 2º Plotar borda do setor
        gdf_sector_web.boundary.plot(ax=ax, color='black', linewidth=3, alpha=1.0)
        
        # Centro não é mais plotado
    
        # Definir limites baseados no setor
        minx_sector, miny_sector, maxx_sector, maxy_sector = gdf_sector_web.total_bounds
        buffer = min((maxx_sector - minx_sector), (maxy_sector - miny_sector)) * 0.1
        ax.set_xlim(minx_sector - buffer, maxx_sector + buffer)
        ax.set_ylim(miny_sector - buffer, maxy_sector + buffer)

        _adicionar_mapa_base(ax)

    # 6º Adicionar árvores do setor (ETH data) - contar apenas as efetivamente renderizadas
    sector_trees_count = 0
    sector_trees_by_height = {'0-2m': 0, '2-3m': 0, '3-5m': 0, '5-10m': 0, '10-15m': 0, '15-25m': 0, '>25m': 0}
    arvores_setor_detalhes = []  # Inicializar sempre, mesmo que não haja árvores
    
    if tree_subpixels_data:
        tree_patches_sector = []
        tree_colors_sector = []
        tree_heights_sector = []
        
        # Obter índices dos subpixels deste setor
        sector_subpixel_indices = set(sp_data.get('original_index') for sp_data in sector_subpixels_data)
        
        # Obter building_indices para verificar conflitos
        building_indices = set()
        if building_subpixels_data:
            for building_data in building_subpixels_data:
                idx_global = building_data['index']
                if idx_global in sector_subpixel_indices:
                    building_indices.add(idx_global)
        
        # NOVA LÓGICA: Eliminar sobreposições visuais - uma árvore por posição visual única
        pixels_arvores_por_posicao = {}
        arvores_filtradas = 0
        arvores_sobrepostas = 0
        
        # Primeiro passo: coletar árvores e agrupar por posição visual
        for tree_data in tree_subpixels_data:
            idx_global = tree_data['index']
            altura = tree_data['altura']
            
            # VERIFICAR SE A ÁRVORE PERTENCE A ESTE SETOR
            if idx_global in sector_subpixel_indices:
                # APLICAR FILTRO DE CONFLITO: não incluir se há building no mesmo local
                if idx_global in building_indices:
                    arvores_filtradas += 1
                    continue  # Pular esta árvore
                
                if idx_global < len(all_subpixels):
                    tree_geom = all_subpixels[idx_global]
                    centroid = tree_geom.centroid
                    
                    # Criar chave de posição visual arredondada para 10m (elimina sobreposições)
                    pos_visual = (round(centroid.x, -1), round(centroid.y, -1))
                    
                    # Se já existe árvore nesta posição visual, manter apenas a de maior altura
                    if pos_visual in pixels_arvores_por_posicao:
                        if altura > pixels_arvores_por_posicao[pos_visual]['altura']:
                            # Substituir pela árvore mais alta
                            pixels_arvores_por_posicao[pos_visual] = {
                                'idx_global': idx_global,
                                'altura': altura,
                                'geom': tree_geom
                            }
                        arvores_sobrepostas += 1
                    else:
                        # Adicionar nova árvore em posição visual única
                        pixels_arvores_por_posicao[pos_visual] = {
                            'idx_global': idx_global,
                            'altura': altura,
                            'geom': tree_geom
                        }
        
        # Segundo passo: renderizar apenas as árvores sem sobreposição visual
        patches_adicionados = 0
        
        for pos_visual, arvore_info in pixels_arvores_por_posicao.items():
            tree_geom = arvore_info['geom']
            altura = arvore_info['altura']
            idx_global = arvore_info['idx_global']
            
            # Buscar informações do land cover original para esta árvore
            original_landcover = None
            if tree_subpixels_data and sector_subpixels_data:
                for tree_data in tree_subpixels_data:
                    if tree_data['index'] == idx_global:
                        # Buscar o subpixel correspondente no sector_subpixels_data pelo índice
                        for subpixel_data in sector_subpixels_data:
                            if subpixel_data.get('original_index') == idx_global:
                                original_landcover = {
                                    'codigo_clc': subpixel_data.get('value'),
                                    'category': subpixel_data.get('category'),
                                    'z0_landcover': subpixel_data.get('z0_landcover'),
                                    'd_landcover': subpixel_data.get('d_landcover')
                                }
                                break
                        break
            
            # CALCULAR Z0 e d PARA ESTA ÁRVORE
            landcover_code = original_landcover.get('codigo_clc') if original_landcover else None
            parametros_arvore = calcular_z0_e_d_arvore(altura, landcover_code)
            
            # Armazenar detalhes da árvore do setor
            centroid = tree_geom.centroid
            arvores_setor_detalhes.append({
                'index': idx_global,
                'altura_m': round(altura, 1),
                'z0': parametros_arvore['z0'],
                'd': parametros_arvore['d'],
                'coordenadas': {
                    'x': round(centroid.x, 2),
                    'y': round(centroid.y, 2)
                },
                'posicao_visual': pos_visual,
                # INFORMAÇÕES DO LAND COVER ORIGINAL
                'original_landcover': original_landcover
            })
            
            # Converter geometria para Web Mercator (só se necessário para imagem)
            if generate_image:
                gdf_tree = gpd.GeoDataFrame(geometry=[tree_geom], crs=raster_crs)
                gdf_tree_web = gdf_tree.to_crs(epsg=3857) if raster_crs != "EPSG:3857" else gdf_tree
                geom_web = gdf_tree_web.geometry.iloc[0]
                
                # ADICIONAR PATCH À LISTA DE RENDERIZAÇÃO
                mpl_poly = MplPolygon(list(geom_web.exterior.coords), closed=True)
                tree_patches_sector.append(mpl_poly)
                
                # Cor baseada na altura
                cor = get_tree_height_color(altura)
                tree_colors_sector.append(cor)
            
            tree_heights_sector.append(altura)
            patches_adicionados += 1
            
        # Parâmetros Z0 e d calculados para árvores silenciosamente
        
        # RENDERIZAR OS PATCHES (só se gerar imagem)
        if generate_image and tree_patches_sector:
            tree_collection_sector = PatchCollection(tree_patches_sector, 
                                                   facecolor=tree_colors_sector,
                                                   edgecolor='darkgreen',
                                                   linewidth=0.2,
                                                   alpha=0.7)
            ax.add_collection(tree_collection_sector)
            
        # CONTAR BASEADO EXATAMENTE NO QUE FOI RENDERIZADO (SEM SOBREPOSIÇÕES)
        sector_trees_count = len(pixels_arvores_por_posicao)  # Conte apenas posições visuais únicas
        
        # Distribuir por altura baseado nos patches efetivamente renderizados
        for altura in tree_heights_sector:
                if altura >= 25:
                    sector_trees_by_height['>25m'] += 1
                elif altura >= 15:
                    sector_trees_by_height['15-25m'] += 1
                elif altura >= 10:
                    sector_trees_by_height['10-15m'] += 1
                elif altura >= 5:
                    sector_trees_by_height['5-10m'] += 1
                elif altura >= 3:
                    sector_trees_by_height['3-5m'] += 1
                elif altura >= 2:
                    sector_trees_by_height['2-3m'] += 1
                else:
                    sector_trees_by_height['0-2m'] += 1
        
        # Árvores processadas

    # 7º Adicionar edifícios do setor (se existirem) COM ELIMINAÇÃO DE SOBREPOSIÇÕES
    sector_buildings_count = 0
    edificios_setor_detalhes = []  # Lista para armazenar detalhes de cada edifício do setor
    
    if building_subpixels_data:
        building_patches_sector = []
        building_colors_sector = []
        
        # Obter índices dos subpixels deste setor
        sector_subpixel_indices = set(sp_data.get('original_index') for sp_data in sector_subpixels_data)
        
        # SISTEMA DE ELIMINAÇÃO DE SOBREPOSIÇÕES PARA EDIFÍCIOS
        pixels_edificios_por_posicao = {}  # Chave: (coord_x, coord_y), Valor: dados do edifício mais alto
        edificios_sobrepostos = 0
        
        buildings_adicionados = 0
        for building_data in building_subpixels_data:
            idx_global = building_data['index']
            altura = building_data['altura']
            
            # VERIFICAR SE O EDIFÍCIO PERTENCE A ESTE SETOR
            if idx_global in sector_subpixel_indices:
                # Encontrar geometria correspondente no setor
                building_geom = None
                for sp_data in sector_subpixels_data:
                    if sp_data.get('original_index') == idx_global:
                        building_geom = sp_data['geometry']
                        break
                
                if building_geom:
                    # Calcular posição visual (grid 10m) do edifício
                    centroid = building_geom.centroid
                    pos_visual = (round(centroid.x, -1), round(centroid.y, -1))  # Arredonda para múltiplos de 10
                    
                    # Verificar se já existe um edifício nesta posição visual
                    if pos_visual in pixels_edificios_por_posicao:
                        # Manter apenas o edifício mais alto
                        if altura > pixels_edificios_por_posicao[pos_visual]['altura']:
                            pixels_edificios_por_posicao[pos_visual] = {
                                'altura': altura,
                                'geometry': building_geom,
                                'index': idx_global
                            }
                        edificios_sobrepostos += 1
                    else:
                        # Primeiro edifício nesta posição visual
                        pixels_edificios_por_posicao[pos_visual] = {
                            'altura': altura,
                            'geometry': building_geom,
                            'index': idx_global
                        }
        
        # Renderizar apenas os edifícios únicos por posição visual
        
        for pos_visual, edificio_info in pixels_edificios_por_posicao.items():
            building_geom = edificio_info['geometry']
            altura = edificio_info['altura']
            idx_global = edificio_info['index']
            
            # Buscar informações do land cover original para este edifício
            original_landcover = None
            if building_subpixels_data and sector_subpixels_data:
                for building_data in building_subpixels_data:
                    if building_data['index'] == idx_global:
                        # Buscar o subpixel correspondente no sector_subpixels_data pelo índice
                        for subpixel_data in sector_subpixels_data:
                            if subpixel_data.get('original_index') == idx_global:
                                original_landcover = {
                                    'codigo_clc': subpixel_data.get('value'),
                                    'category': subpixel_data.get('category'),
                                    'z0_landcover': subpixel_data.get('z0_landcover'),
                                    'd_landcover': subpixel_data.get('d_landcover')
                                }
                                break
                        break
            
            # CALCULAR Z0 e d PARA ESTE EDIFÍCIO (considerando land cover)
            landcover_code = original_landcover.get('codigo_clc') if original_landcover else None
            parametros_edificio = calcular_z0_e_d_edificio(altura, landcover_code)
            
            # Armazenar detalhes do edifício do setor
            centroid = building_geom.centroid
            edificios_setor_detalhes.append({
                'index': idx_global,
                'altura_m': round(altura, 1),
                'z0': parametros_edificio['z0'],
                'd': parametros_edificio['d'],
                'coordenadas': {
                    'x': round(centroid.x, 2),
                    'y': round(centroid.y, 2)
                },
                'posicao_visual': pos_visual,
                # INFORMAÇÕES DO LAND COVER ORIGINAL
                'original_landcover': original_landcover
            })
            
            # Converter geometria para Web Mercator (só se necessário para imagem)
            if generate_image:
                gdf_building = gpd.GeoDataFrame(geometry=[building_geom], crs=raster_crs)
                gdf_building_web = gdf_building.to_crs(epsg=3857) if raster_crs != "EPSG:3857" else gdf_building
                geom_web = gdf_building_web.geometry.iloc[0]
                
                # ADICIONAR PATCH À LISTA DE RENDERIZAÇÃO
                mpl_poly = MplPolygon(list(geom_web.exterior.coords), closed=True)
                building_patches_sector.append(mpl_poly)
                
                # Cor baseada na altura
                if altura < 3:
                    cor = '#2196f3'
                elif altura < 5:
                    cor = '#3f51b5'
                elif altura < 10:
                    cor = '#673ab7'
                elif altura < 15:
                    cor = '#9c27b0'
                else:
                    cor = '#f44336'
                
                building_colors_sector.append(cor)
            
            buildings_adicionados += 1
            
        # Parâmetros Z0 e d calculados para edifícios silenciosamente
        
        # RENDERIZAR OS PATCHES (só se gerar imagem)
        if generate_image and building_patches_sector:
            building_collection_sector = PatchCollection(building_patches_sector, 
                                                       facecolor=building_colors_sector,
                                                       edgecolor='navy',
                                                       linewidth=0.3,
                                                       alpha=0.7)
            ax.add_collection(building_collection_sector)
            
        # CONTAR BASEADO EXATAMENTE NO QUE FOI PROCESSADO
        if generate_image:
            sector_buildings_count = len(building_patches_sector) if building_patches_sector else len(pixels_edificios_por_posicao)
        else:
            sector_buildings_count = len(pixels_edificios_por_posicao)
        
        # Edifícios processados

    # Legenda e salvamento (só se gerar imagem)
    if generate_image:
        # Para mapas Z0, não usar legenda categórica de landcover
        # A informação de Z0 será mostrada através do colorbar
        handles = []
        
        if sector_trees_count > 0:
            handles.append(Patch(color='white', label='--- Trees ---'))
            handles.append(Patch(color='#90EE90', label='Trees 2-3m'))
            handles.append(Patch(color='#32CD32', label='Trees 5-10m'))
            handles.append(Patch(color='#006400', label='Trees 15-25m'))
        
        if sector_buildings_count > 0:
            handles.append(Patch(color='white', label='--- Buildings ---'))
            handles.append(Patch(color='#2196f3', label='Buildings 2-3m'))
            handles.append(Patch(color='#673ab7', label='Buildings 5-7m'))
            handles.append(Patch(color='#f44336', label='Buildings >15m'))
        
        # Só adicionar legenda se houver itens
        if handles:
            ax.legend(handles=handles, bbox_to_anchor=(1.05, 1), loc="upper left")
        
        # Title
        title = f"SECTOR {sector_info['sector_id']} - Roughness Z₀"
        if sector_trees_count > 0:
            title += f" + {sector_trees_count} Trees"
        if sector_buildings_count > 0:
            title += f" + {sector_buildings_count} Buildings"

        # Colorbar -- a UNICA da solucao, partilhada por todos os mapas
        # circulares (mapas_circulares.adicionar_colorbar_padrao).
        import matplotlib.colors as mcolors
        try:
            colormap = plt.colormaps.get_cmap('viridis')
        except (AttributeError, KeyError):
            from matplotlib import cm
            colormap = cm.get_cmap('viridis')
        norm = mcolors.Normalize(vmin=0, vmax=2)
        adicionar_colorbar_padrao(ax, colormap, norm, orientation='horizontal',
                                   posicao="bottom", pad=0.1, rotulo='Roughness Z₀ (m)',
                                   fmt="{:.2f}")
        ax.set_aspect("equal")
        ax.set_axis_off()
        plt.tight_layout()

        # Salvar imagem na pasta de imagens
        filename = f"setor_{sector_info['sector_id']}_individual.jpg"
        pasta_imagens = os.path.join(pasta_saida, "imagens")
        os.makedirs(pasta_imagens, exist_ok=True)
        caminho_completo = os.path.join(pasta_imagens, filename)
        plt.savefig(caminho_completo, dpi=300, bbox_inches='tight', format='jpeg')
        plt.close()

        # Imagem salva silenciosamente
    
    # Calcular percentagens de árvores por altura (baseado nas árvores realmente renderizadas)
    sector_trees_percentages = {}
    if sector_trees_count > 0:
        for height_class, count in sector_trees_by_height.items():
            percentage = round(count / sector_trees_count * 100, 2)
            sector_trees_percentages[height_class] = percentage
    else:
        for height_class in sector_trees_by_height.keys():
            sector_trees_percentages[height_class] = 0.0
    
    # Calcular percentagens de edifícios por altura (baseado nos edifícios realmente renderizados)
    sector_buildings_by_height = {'0-2m': 0, '2-3m': 0, '3-5m': 0, '5-7m': 0, '7-10m': 0, '>10m': 0}
    sector_buildings_percentages = {}
    
    # Se houve edifícios renderizados, calcular estatísticas por altura
    if sector_buildings_count > 0 and building_subpixels_data:
        # Obter índices dos subpixels deste setor
        sector_subpixel_indices = set(sp_data.get('original_index') for sp_data in sector_subpixels_data)
        
        # Contar edifícios renderizados por altura usando os dados únicos (sem sobreposições)
        for pos_visual, edificio_info in pixels_edificios_por_posicao.items():
            altura = edificio_info['altura']
            if altura >= 10:
                sector_buildings_by_height['>10m'] += 1
            elif altura >= 7:
                sector_buildings_by_height['7-10m'] += 1
            elif altura >= 5:
                sector_buildings_by_height['5-7m'] += 1
            elif altura >= 3:
                sector_buildings_by_height['3-5m'] += 1
            elif altura >= 2:
                sector_buildings_by_height['2-3m'] += 1
            else:
                sector_buildings_by_height['0-2m'] += 1
        
        # Calcular percentagens
        for height_class, count in sector_buildings_by_height.items():
            percentage = round(count / sector_buildings_count * 100, 2)
            sector_buildings_percentages[height_class] = percentage
    else:
        # Se não há edifícios, todas as percentagens são 0
        for height_class in sector_buildings_by_height.keys():
            sector_buildings_percentages[height_class] = 0.0
    
    # Calcular estatísticas agregadas de Z0 e d para árvores do setor
    z0_stats_arvores = {'min': 0, 'max': 0, 'media': 0}
    d_stats_arvores = {'min': 0, 'max': 0, 'media': 0}
    
    if arvores_setor_detalhes:
        z0_valores = [arvore['z0'] for arvore in arvores_setor_detalhes]
        d_valores = [arvore['d'] for arvore in arvores_setor_detalhes]
        
        z0_stats_arvores = {
            'min': round(min(z0_valores), 3),
            'max': round(max(z0_valores), 3),
            'media': round(sum(z0_valores) / len(z0_valores), 3)
        }
        
        d_stats_arvores = {
            'min': round(min(d_valores), 3),
            'max': round(max(d_valores), 3),
            'media': round(sum(d_valores) / len(d_valores), 3)
        }
    
    # Calcular estatísticas agregadas de Z0 e d para edifícios do setor
    z0_stats_edificios = {'min': 0, 'max': 0, 'media': 0}
    d_stats_edificios = {'min': 0, 'max': 0, 'media': 0}
    
    if edificios_setor_detalhes:
        z0_valores_edificios = [edificio['z0'] for edificio in edificios_setor_detalhes]
        d_valores_edificios = [edificio['d'] for edificio in edificios_setor_detalhes]
        
        z0_stats_edificios = {
            'min': round(min(z0_valores_edificios), 3),
            'max': round(max(z0_valores_edificios), 3),
            'media': round(sum(z0_valores_edificios) / len(z0_valores_edificios), 3)
        }
        
        d_stats_edificios = {
            'min': round(min(d_valores_edificios), 3),
            'max': round(max(d_valores_edificios), 3),
            'media': round(sum(d_valores_edificios) / len(d_valores_edificios), 3)
        }
    
    # Calcular estatísticas agregadas de Z0 para land cover do setor
    z0_stats_landcover = {'min': 0, 'max': 0, 'media': 0}
    
    if landcover_detalhes:
        z0_valores_landcover = [lc['z0'] for lc in landcover_detalhes]
        
        z0_stats_landcover = {
            'min': round(min(z0_valores_landcover), 3),
            'max': round(max(z0_valores_landcover), 3),
            'media': round(sum(z0_valores_landcover) / len(z0_valores_landcover), 3)
        }

    # Retornar estatísticas de árvores, edifícios e land cover realmente renderizados
    return {
        'trees': {
            'total_count': sector_trees_count,
            'by_height': {
                'counts': sector_trees_by_height,
                'percentages': sector_trees_percentages
            },
            'parametros_aerodinamicos': {
                'z0_stats': z0_stats_arvores,
                'd_stats': d_stats_arvores,
                'arvores_individuais': arvores_setor_detalhes  # Lista completa com detalhes de cada árvore
            }
        },
        'buildings': {
            'total_count': sector_buildings_count,
            'by_height': {
                'counts': sector_buildings_by_height,
                'percentages': sector_buildings_percentages
            },
            'parametros_aerodinamicos': {
                'z0_stats': z0_stats_edificios,
                'd_stats': d_stats_edificios,
                'edificios_individuais': edificios_setor_detalhes  # Lista completa com detalhes de cada edifício
            }
        },
        'landcover': {
            'total_subpixels': len(landcover_detalhes),
            'parametros_aerodinamicos': {
                'z0_stats': z0_stats_landcover,
                'subpixels_individuais': [{k: v for k, v in lc.items() if k != 'geometry'} for lc in landcover_detalhes]  # Lista sem geometrias
            }
        }
    }

def analyze_land_cover(lat, lon, radius_meters, n_sectors=2, altura_torre=25, raio_inicial=None, pais="Portugal", id_torre=None, regiao="N/A"):
    """
    Análise de cobertura do solo e edifícios baseada em pixels do raster com divisão por setores.
    Subdivide cada pixel 100x100 em subpixels 10x10 ALINHADOS com a grade do DHM.
    Visualização otimizada com PatchCollection.
    """
    # Garantir que os diretórios existam
    garantir_diretorios()
    
    # Verificar se o arquivo GeoTIFF existe
    verificar_geotiff()
    
    # Garantir raio mínimo de 300m
    if radius_meters < 300:
        radius_meters = 300
    
    # Definir raio inicial se não foi fornecido
    if raio_inicial is None:
        raio_inicial = radius_meters
    elif raio_inicial < 300:
        raio_inicial = 300
    
    # Iniciando análise silenciosa de cobertura do solo + edifícios + árvores

    # Inicializar variáveis globais
    building_subpixels_data = []
    tree_subpixels_data = []
    deviation_subpixels_data = []

    # ==============================
    # GARANTIR DADOS DE ÁRVORES
    # ==============================
    caminho_tif_arvores, caminho_tif_desvio = garantir_tif_arvores(lat, lon, radius_meters)

    # Carregar transform do arquivo de building para alinhamento
    dhm_transform = None
    building_file_path = os.path.join(WORK_DIR, 'TIF_Building', f'{pais}.tif')
    try:
        with rasterio.open(building_file_path) as building_file:
            dhm_transform = building_file.transform
    except:
        dhm_transform = None

    # Verificar se é um território ultramarino francês para usar TIF específico
    territorios_ultramarinos_franceses = ["Martinique", "Mayotte", "Réunion", "Guadeloupe", "French Guiana"]
    if regiao in territorios_ultramarinos_franceses:
        # Usar TIF específico do território ultramarino
        geotiff_path = os.path.join(BASE_PATH, f"LandCover_{regiao}.tif")
    else:
        # Usar TIF do continente
        geotiff_path = GEOTIFF_PATH_CONTINENTE

    with rasterio.open(geotiff_path) as src:
        raster_crs = src.crs

    # Calcular os raios dinâmicos uma única vez
    ring_radii, radius_meters, raio_medio_list = calculate_dynamic_ring_radii(radius_meters)
    
    # Capturar dados dos anéis para o logger
    ring_data = {
        "ring_radii": ring_radii,
        "raio_medio": raio_medio_list,
        "growth_factor": 1.05,
        "radius_ajustado": radius_meters
    }

    L = radius_meters / 3

    original_sectors = split_circle_into_sectors(lat, lon, radius_meters, n_sectors, raster_crs)
    sectors = divide_sectors_concentrically(original_sectors, lat, lon, radius_meters, raster_crs, ring_radii, raio_medio_list)

    # Criar círculo completo para obter todos os pixels da área
    # Usando mais segmentos para círculos mais precisos
    if raster_crs != "EPSG:4326":
        transformer = Transformer.from_crs("EPSG:4326", raster_crs, always_xy=True)
        center_x, center_y = transformer.transform(lon, lat)
        # Usar 64 segmentos por quadrante para círculo mais suave (total 256 pontos)
        circle_geometry = Point(center_x, center_y).buffer(radius_meters, quad_segs=64)
    else:
        radius_deg_lat = radius_meters / 111320
        radius_deg_lon = radius_meters / (111320 * math.cos(math.radians(lat)))
        from shapely.affinity import scale
        center_point = Point(lon, lat)
        # Usar 64 segmentos por quadrante para círculo mais suave (total 256 pontos)
        circle_geometry = center_point.buffer(radius_deg_lat, quad_segs=64)
        circle_geometry = scale(circle_geometry, xfact=radius_deg_lon/radius_deg_lat, yfact=1.0)

    # Obter todos os pixels do círculo completo uma só vez
    all_circle_pixels, _ = get_raster_pixels_in_geometry(geotiff_path, circle_geometry, lat, lon)

    results = []
    all_subpixels = []
    all_colors = []
    sector_colors = []
    legend_entries = {}
    
    # Lista para armazenar dados completos de cada subpixel com ID único
    all_subpixels_data = []
    
    # Dicionário para estatísticas de edifícios por setor
    sector_buildings_stats = {}
    
    # Contador global de IDs de pixels - cada pixel terá um ID único sequencial
    global_pixel_id = 1
    
    # Definir ID da torre se não foi fornecido
    if id_torre is None:
        id_torre = f"torre_{lat}_{lon}".replace('.', '_').replace('-', '_')
    
    # Criar pasta de saída com nova estrutura: ./resultados/id_torre/
    #   C0Z0_OUTDIR (definido pelo run_site quando orquestra .exe separados)
    #   tem prioridade sobre ./resultados do diretorio de trabalho.
    pasta_resultados = os.environ.get("C0Z0_OUTDIR") or os.path.join(os.getcwd(), "resultados")
    pasta_saida = os.path.join(pasta_resultados, id_torre)
    
    # Verificar e deletar pasta existente se já houver resultados anteriores
    if os.path.exists(pasta_saida):
        import shutil
        print(f"Deletando resultados anteriores: {pasta_saida}")
        try:
            shutil.rmtree(pasta_saida)
            print(f"Pasta anterior deletada com sucesso")
        except Exception as e:
            print(f"Aviso ao deletar pasta anterior: {e}")
    
    # Criar pasta de saída
    os.makedirs(pasta_saida, exist_ok=True)
    print(f"Pasta de resultados criada: {pasta_saida}")
    
    # ==============================
    # OTIMIZAÇÃO: PRÉ-CALCULAR TODOS OS SUBPIXELS UMA ÚNICA VEZ
    # ==============================
    
    # Pré-calcular todos os subpixels de todos os pixels uma única vez
    all_precomputed_subpixels = []
    
    for pixel_idx, pixel in enumerate(all_circle_pixels):
        category = LANDCOVER_CLASSES.get(pixel['value'], f"Classe_{pixel['value']}")
        
        # Criar subpixels alinhados com a grade do DHM (se disponível)
        if dhm_transform is not None:
            aligned_subpixels = create_dhm_aligned_subpixels(pixel, dhm_transform)
        else:
            # Método original como fallback
            from shapely.geometry import Polygon
            
            geom_pixel = pixel['geometry']
            minx, miny, maxx, maxy = geom_pixel.bounds
            
            pixel_transform = Affine(
                (maxx - minx)/100, 0, minx,
                0, (maxy - miny)/100, miny
            )
            
            aligned_subpixels = []
            for si in range(10):
                for sj in range(10):
                    dx0, dy0 = si*10, sj*10
                    dx1, dy1 = (si+1)*10, sj*10
                    dx2, dy2 = (si+1)*10, (sj+1)*10
                    dx3, dy3 = si*10, (sj+1)*10

                    x0, y0 = pixel_transform * (dx0, dy0)
                    x1, y1 = pixel_transform * (dx1, dy1)
                    x2, y2 = pixel_transform * (dx2, dy2)
                    x3, y3 = pixel_transform * (dx3, dy3)

                    subpixel_poly = Polygon([(x0, y0), (x1, y1), (x2, y2), (x3, y3)])
                    aligned_subpixels.append(subpixel_poly)
        
        # Armazenar todos os subpixels com metadados
        for idx, subpixel_poly in enumerate(aligned_subpixels):
            all_precomputed_subpixels.append({
                'value': pixel['value'],
                'geometry': subpixel_poly,
                'category': category,
                'pixel_idx': pixel_idx,
                'subpixel_idx': idx,
                'pixel_id': global_pixel_id
            })
            global_pixel_id += 1
    
    # ==============================
    # OTIMIZAÇÃO AVANÇADA: CRIAR ÍNDICE ESPACIAL PARA INTERSECÇÕES RÁPIDAS
    # ==============================
    
    try:
        from shapely.strtree import STRtree
        
        # Criar lista de geometrias e índice espacial
        subpixel_geometries = [sp['geometry'] for sp in all_precomputed_subpixels]
        spatial_index = STRtree(subpixel_geometries)
        
        use_spatial_index = True
    except ImportError:
        use_spatial_index = False
    
    # ==============================
    # PRÉ-CALCULAR TRANSFORMAÇÕES PARA CÁLCULOS DE ÁREA
    # ==============================
    
    # Determinar zona UTM apropriada uma única vez
    utm_zone = int((lon + 180) / 6) + 1
    hemisphere = 'north' if lat >= 0 else 'south'
    utm_crs = f"EPSG:326{utm_zone:02d}" if hemisphere == 'north' else f"EPSG:327{utm_zone:02d}"
    
    # Criar transformer para conversão de coordenadas uma única vez
    transformer_back = Transformer.from_crs(raster_crs, "EPSG:4326", always_xy=True)
    
    # ==============================
    # OTIMIZAÇÃO: PROCESSAR SETORES COM SUBPIXELS PRÉ-CALCULADOS  
    # ==============================
    
    total_sectors = len(sectors)
    processed_sectors = 0
    
    for i, sector_info in enumerate(sectors):
        sector_geometry = sector_info['geometry']
        sector_type = sector_info['type']
        sector_id = sector_info['sector_id']
        
        # Filtrar subpixels pré-calculados que intersectam com este setor
        sector_subpixels_data = []
        
        if use_spatial_index:
            # OTIMIZAÇÃO: Usar índice espacial para encontrar candidatos rapidamente
            candidate_indices = spatial_index.query(sector_geometry)
            
            for idx in candidate_indices:
                subpixel_data = all_precomputed_subpixels[idx]
                # Verificação precisa de intersecção apenas nos candidatos
                if subpixel_data['geometry'].intersects(sector_geometry):
                    sector_subpixels_data.append({
                        'value': subpixel_data['value'],
                        'geometry': subpixel_data['geometry'],
                        'category': subpixel_data['category'],
                        'index': len(sector_subpixels_data),  # Índice sequencial local do setor
                        'pixel_id': subpixel_data['pixel_id']  # ID único global
                    })
        else:
            # Método tradicional (fallback)
            for subpixel_data in all_precomputed_subpixels:
                if subpixel_data['geometry'].intersects(sector_geometry):
                    sector_subpixels_data.append({
                        'value': subpixel_data['value'],
                        'geometry': subpixel_data['geometry'],
                        'category': subpixel_data['category'],
                        'index': len(sector_subpixels_data),  # Índice sequencial local do setor
                        'pixel_id': subpixel_data['pixel_id']  # ID único global
                    })
        
        if not sector_subpixels_data:
            # Apenas registrar setores vazios
            results.append({
                "sector": i,
                "percentages": {},
                "coordinates": f"{lat:.4f}, {lon:.4f}",
                "data_source": "GeoTIFF (CLC2018)",
                "confidence": "Baixa"
            })
            continue
        
        # Separar subpixels válidos e NoData
        valid_subpixels = [sp for sp in sector_subpixels_data if sp['value'] > 0]
        nodata_subpixels = [sp for sp in sector_subpixels_data if sp['value'] == 0]
        
        if not valid_subpixels:
            # Apenas registrar setores sem dados válidos
            results.append({
                "sector": sector_id,
                "percentages": {},
                "coordinates": f"{lat:.4f}, {lon:.4f}",
                "data_source": "GeoTIFF (CLC2018)",
                "confidence": "Baixa"
            })
            continue
        
        # Calcular percentagens e contagens por categoria (apenas pixels válidos)
        categories = [sp['category'] for sp in valid_subpixels]
        unique_cats, counts = np.unique(categories, return_counts=True)
        total_subpixels = len(valid_subpixels)
        
        percentages = {}
        subpixel_counts = {}
        
        # Processar dados sem verbose logging
        for cat, count in zip(unique_cats, counts):
            percentage = round(count / total_subpixels * 100, 2)
            percentages[cat] = percentage
            subpixel_counts[cat] = int(count)
            
        if not percentages:
            results.append({
                "sector": sector_id,
                "percentages": {},
                "coordinates": f"{lat:.4f}, {lon:.4f}",
                "data_source": "GeoTIFF (CLC2018)",
                "confidence": "Baixa"
            })
            continue
        
        # Descobrir classe dominante do setor e adicionar TODAS as categorias à legenda
        if percentages:
            dominant_class = max(percentages, key=percentages.get)
            
            # Adicionar TODAS as categorias encontradas no setor à legenda
            for category in percentages.keys():
                if category not in legend_entries:
                    try:
                        color_index = list(LANDCOVER_CLASSES.values()).index(category) % len(COLORS)
                    except ValueError:
                        color_index = hash(category) % len(COLORS)
                    legend_entries[category] = COLORS[color_index]
            
            # Cor do setor é baseada na classe dominante
            sector_color = legend_entries[dominant_class]
            sector_colors.append(sector_color)
        else:
            dominant_class = "Sem dados"
            sector_colors.append((0.9, 0.9, 0.9))
        
        # Armazenar resultados do setor (usando transformer pré-calculado)
        cx, cy = transformer_back.transform(sector_geometry.centroid.x, sector_geometry.centroid.y)
        
        # Calcular área total do setor em metros quadrados (usando UTM pré-calculado)
        try:
            # Converter geometria para UTM para cálculo preciso da área
            gdf_sector_utm = gpd.GeoDataFrame(geometry=[sector_geometry], crs=raster_crs).to_crs(utm_crs)
            area_m2 = gdf_sector_utm.geometry.iloc[0].area
        except Exception as e:
            # Fallback: usar aproximação baseada na geometria original
            area_m2 = sector_geometry.area * (111320 ** 2) if "EPSG:4326" in str(raster_crs) else sector_geometry.area
        
        # Obter raio médio já calculado do setor
        raio_medio_equivalente = sector_info.get('raio_medio', 0.0)
        
        # Calcular Wk usando a fórmula: W(k) = area_m2 * exp(-raio_medio_equivalente/L)
        Wk = area_m2 * math.exp(-raio_medio_equivalente / L) if L > 0 else 0.0
        
        # Armazenar dados do setor para cálculo posterior (quando todos os dados estiverem prontos)
        # Os cálculos de Wk, z0 e valor_final serão feitos na função dedicada calculate_final_aerodynamic_parameters()
        
        # Cálculos sem logging detalhado

        # Calcular percentagens totais do setor
        total_elements = total_subpixels  # Edifícios serão adicionados depois
        
        land_percentage = round(total_subpixels / total_elements * 100, 2) if total_elements > 0 else 0.0
        
        results.append({
            "sector_id": sector_id,
            "coordinates": f"{cy:.4f}, {cx:.4f}",
            "area_info": {
                "area_m2": round(area_m2, 2),
                "radius_range": sector_info.get('radius_range', 'N/A'),
                "raio_medio_equivalente": round(raio_medio_equivalente, 2),
                "Wk": round(Wk, 6)
            },
            "summary": {
                "land_percentage": land_percentage,
                "buildings_percentage": 0.0,  # Será atualizado depois com os edifícios
                "total_elements": total_subpixels,
                "data_source": "GeoTIFF (CLC2018)",
                "confidence": "Alta" if percentages else "Baixa"
            },
            "land_cover": {
                "total_subpixels": total_subpixels,
                "categories": subpixel_counts,
                "percentages": percentages
            }
        })

        # Agrupar Wk por setor principal e anel
        main_sector = sector_id.split('_anel_')[0] if '_anel_' in sector_id else sector_id
        anel_id = sector_id.split('_anel_')[1] if '_anel_' in sector_id else '1'
        
        if 'wk_by_main_sector' not in locals():
            wk_by_main_sector = {}
        
        # Inicializar estrutura do setor se não existir
        if main_sector not in wk_by_main_sector:
            wk_by_main_sector[main_sector] = {}
        
        # Adicionar valor do anel
        wk_by_main_sector[main_sector][f"Anel_{anel_id}"] = round(Wk, 6)
        
        # Os cálculos de Wk * ln(z0) serão feitos posteriormente na função dedicada
        
        # Adicionar subpixels válidos do setor aos arrays finais
        for subpixel_data in valid_subpixels:
            category = subpixel_data['category']
            if category not in legend_entries:
                # Adicionar categoria à legenda se não existir
                try:
                    color_index = list(LANDCOVER_CLASSES.values()).index(category) % len(COLORS)
                except ValueError:
                    color_index = hash(category) % len(COLORS)
                legend_entries[category] = COLORS[color_index]
            
            pixel_color = legend_entries[category]
            all_subpixels.append(subpixel_data['geometry'])
            all_colors.append(pixel_color)
            
            # Adicionar dados completos do subpixel à lista de dados
            all_subpixels_data.append({
                'pixel_id': subpixel_data['pixel_id'],
                'geometry': subpixel_data['geometry'],
                'category': category,
                'value': subpixel_data['value'],
                'color': pixel_color,
                'sector_id': sector_id,
                'type': 'land_cover'
            })
        
        # Adicionar subpixels NoData com cor específica para identificação
        if nodata_subpixels:
            nodata_color = (0.8, 0.8, 0.8)  # Cinza claro para NoData
            legend_entries["NoData"] = nodata_color
            for subpixel_data in nodata_subpixels:
                all_subpixels.append(subpixel_data['geometry'])
                all_colors.append(nodata_color)
                
                # Adicionar dados completos do subpixel NoData à lista de dados
                all_subpixels_data.append({
                    'pixel_id': subpixel_data['pixel_id'],
                    'geometry': subpixel_data['geometry'],
                    'category': 'NoData',
                    'value': subpixel_data['value'],
                    'color': nodata_color,
                    'sector_id': sector_id,
                    'type': 'land_cover'
                })
        
        # Contabilizar setor processado
        processed_sectors += 1

    # Processamento de subpixels concluído
    
    # Salvar wk_by_main_sector no JSON (após processar todos os setores)
    if 'wk_by_main_sector' in locals() and wk_by_main_sector:
        # Calcular totais por setor e valor_final usando a fórmula: ln(z0_setor) = Σ(Wk * ln(z0,k)) / Σ(Wk)
        wk_final_structure = {}
        for main_sector, aneis_data in wk_by_main_sector.items():
            sector_name = f"Setor_{main_sector}"
            wk_final_structure[sector_name] = aneis_data.copy()
            
            # Calcular total do setor (Σ Wk)
            total_setor = sum(aneis_data.values())
            wk_final_structure[sector_name]["Total"] = round(total_setor, 6)
            
            # Os valores finais serão calculados posteriormente pela função dedicada
            wk_final_structure[sector_name]["Valor_Final_Preliminar"] = "A_CALCULAR"
            wk_final_structure[sector_name]["ln_z0_setor_Preliminar"] = "A_CALCULAR"
        
        wk_by_main_sector_file = os.path.join(pasta_saida, "wk_by_main_sector.json")
        with open(wk_by_main_sector_file, 'w', encoding='utf-8') as f:
            json.dump(wk_final_structure, f, indent=2, ensure_ascii=False)
    
    # Calcular totais gerais por categoria
    total_counts_global = {}
    for result in results:
        if 'subpixel_counts' in result:
            for category, count in result['subpixel_counts'].items():
                total_counts_global[category] = total_counts_global.get(category, 0) + count
    
    # Verificar cores padrão cinza (sem logging)

    # ==============================
    # ANÁLISE DE DADOS DE ÁRVORES
    # ==============================    
    gdf_desvios = None  # Inicializar dados de desvio
    
    # Carregar dados de desvio padrão primeiro (se disponível) para calcular confiança
    if caminho_tif_desvio:
        region_desvio = carregar_desvio_arvores_region(lat, lon, radius_meters, caminho_tif_desvio, pais, regiao)
        if region_desvio:
            gdf_desvios = detectar_desvio_arvores(region_desvio, desvio_minimo=0.0)  # Pegar todos os desvios

    if caminho_tif_arvores:
        # Carregar região de árvores
        region_arvores = carregar_arvores_region(lat, lon, radius_meters, caminho_tif_arvores, pais, regiao)
        
        if region_arvores is not None:
            # Detectar pixels com árvores
            gdf_arvores = detectar_arvores_canopy(region_arvores, altura_minima=0.0)  # Alterado para pegar todas as árvores
            
            if not gdf_arvores.empty:
                
                # Primeiro: coletar TODAS as árvores (sem filtros) para mapa comparativo
                unfiltered_tree_subpixels_data = detect_all_tree_subpixels_unfiltered(gdf_arvores, all_subpixels, raster_crs, gdf_desvios)
                
                # Depois: detectar quais subpixels contêm árvores (com cálculo de confiança)
                tree_subpixels_data = detect_tree_subpixels(gdf_arvores, all_subpixels, raster_crs, gdf_desvios, all_subpixels_data)
                
                # Gerar mapas separados de árvores
                if all_subpixels:
                    gdf_pixels = gpd.GeoDataFrame(geometry=all_subpixels, crs=raster_crs)
                    gdf_pixels_web = gdf_pixels.to_crs(epsg=3857) if raster_crs != "EPSG:3857" else gdf_pixels
                    
                    # Mapa com todas as árvores (não filtradas)
                    if unfiltered_tree_subpixels_data:
                        create_unfiltered_trees_map(unfiltered_tree_subpixels_data, all_subpixels, gdf_pixels_web, 
                                                   lat, lon, radius_meters, pasta_saida)
                    
                    # Mapa com árvores filtradas (original)
                    create_trees_map(tree_subpixels_data, all_subpixels, gdf_pixels_web, 
                                   lat, lon, radius_meters, pasta_saida)
                    
                    # Mapa de confiança (usando árvores não filtradas para mostrar toda a gama de confiança)
                    if unfiltered_tree_subpixels_data:
                        create_confidence_map(unfiltered_tree_subpixels_data, all_subpixels, gdf_pixels_web, 
                                            lat, lon, radius_meters, pasta_saida)

    # ==============================
    # ANÁLISE DE DESVIO PADRÃO DAS ÁRVORES
    # ==============================
    if caminho_tif_desvio:
        
        # Carregar dados de desvio padrão para a região
        region_desvio = carregar_desvio_arvores_region(lat, lon, radius_meters, caminho_tif_desvio, pais, regiao)
        
        if region_desvio:
            # Detectar pixels com desvio significativo
            gdf_desvios = detectar_desvio_arvores(region_desvio, desvio_minimo=0.5)
            
            if not gdf_desvios.empty:
                # Detectar subpixels que intersectam com pixels de desvio
                deviation_subpixels_data = detect_deviation_subpixels(gdf_desvios, all_subpixels, raster_crs)
                                
                # Gerar mapa separado de desvio padrão
                if all_subpixels and deviation_subpixels_data:
                    gdf_pixels = gpd.GeoDataFrame(geometry=all_subpixels, crs=raster_crs)
                    gdf_pixels_web = gdf_pixels.to_crs(epsg=3857) if raster_crs != "EPSG:3857" else gdf_pixels
                    
                    create_deviation_map(deviation_subpixels_data, all_subpixels, gdf_pixels_web,
                                        lat, lon, radius_meters, pasta_saida)

    # ==============================
    # DETECÇÃO DE EDIFÍCIOS COM DHM
    # ==============================
    
    # Usar arquivo TIF de building baseado no país
    building_file = os.path.join(WORK_DIR, 'TIF_Building', f'{pais}.tif')
    region_dhm = carregar_dhm_region(lat, lon, radius_meters, building_file)
    
    if region_dhm is not None:
        # Detectar pixels com edifícios no DHM
        gdf_edificios_dhm = detectar_edificios_dhm(region_dhm)
        
        if not gdf_edificios_dhm.empty:
            
            # Detectar quais subpixels de cobertura do solo contêm edifícios
            building_subpixels_data = detect_building_subpixels_dhm(gdf_edificios_dhm, all_subpixels, raster_crs, all_subpixels_data)
            
            # NÃO alterar all_colors aqui - edifícios serão renderizados como camada separada
            # Manter cores originais da cobertura do solo por baixo dos edifícios
            
            # As estatísticas de edifícios agora são calculadas corretamente na função 
        # create_individual_sector_map com eliminação de sobreposições
        # e são atualizadas automaticamente no JSON durante a renderização
            
            # Inicializar resultados com edifícios zerados (serão atualizados durante renderização)
            for result in results:
                result['buildings'] = {
                    'total_count': 0,
                    'by_height': {
                        'counts': {'0-2m': 0, '2-3m': 0, '3-5m': 0, '5-7m': 0, '7-10m': 0, '>10m': 0},
                        'percentages': {'0-2m': 0.0, '2-3m': 0.0, '3-5m': 0.0, '5-7m': 0.0, '7-10m': 0.0, '>10m': 0.0}
                    }
                }
                
                # Inicializar percentagens totais (serão atualizadas depois)
                result['summary']['land_percentage'] = 100.0
                result['summary']['buildings_percentage'] = 0.0
                result['summary']['total_elements'] = result['land_cover']['total_subpixels']
        else:
            # Adicionar zeros para edifícios e recalcular percentagens totais
            for result in results:
                result['buildings'] = {
                    'total_count': 0,
                    'by_height': {
                        'counts': {'0-2m': 0, '2-3m': 0, '3-5m': 0, '5-7m': 0, '7-10m': 0, '>10m': 0},
                        'percentages': {'0-2m': 0.0, '2-3m': 0.0, '3-5m': 0.0, '5-7m': 0.0, '7-10m': 0.0, '>10m': 0.0}
                    }
                }
                
                # Recalcular percentagens totais sem edifícios
                total_elements = result['land_cover']['total_subpixels']
                
                if total_elements > 0:
                    result['summary']['land_percentage'] = round(result['land_cover']['total_subpixels'] / total_elements * 100, 2)
                    result['summary']['buildings_percentage'] = 0.0
                    result['summary']['total_elements'] = total_elements
                else:
                    result['summary']['land_percentage'] = 0.0
                    result['summary']['buildings_percentage'] = 0.0
                    result['summary']['total_elements'] = 0
    else:
        # Adicionar zeros para edifícios e recalcular percentagens totais
        for result in results:
            result['buildings'] = {
                'total_count': 0,
                'by_height': {
                    'counts': {'0-2m': 0, '2-3m': 0, '3-5m': 0, '5-7m': 0, '7-10m': 0, '>10m': 0},
                    'percentages': {'0-2m': 0.0, '2-3m': 0.0, '3-5m': 0.0, '5-7m': 0.0, '7-10m': 0.0, '>10m': 0.0}
                }
            }
            
            # Recalcular percentagens totais sem edifícios
            total_elements = result['land_cover']['total_subpixels']
            
            if total_elements > 0:
                result['summary']['land_percentage'] = round(result['land_cover']['total_subpixels'] / total_elements * 100, 2)
                result['summary']['buildings_percentage'] = 0.0
                result['summary']['total_elements'] = total_elements
            else:
                result['summary']['land_percentage'] = 0.0
                result['summary']['buildings_percentage'] = 0.0
                result['summary']['total_elements'] = 0

    # ==============================
    # DETECÇÃO DE ÁRVORES COM ETH GLOBAL CANOPY HEIGHT
    # ==============================
    
    tree_subpixels_data = []  # Inicializar variável
    gdf_desvios = None  # Inicializar dados de desvio
    
    # Carregar dados de desvio padrão primeiro (se disponível) para calcular confiança
    if caminho_tif_desvio:
        region_desvio = carregar_desvio_arvores_region(lat, lon, radius_meters, caminho_tif_desvio, pais, regiao)
        if region_desvio:
            gdf_desvios = detectar_desvio_arvores(region_desvio, desvio_minimo=0.0)  # Pegar todos os desvios para confiança
    
    if caminho_tif_arvores:
        # Carregar dados de árvores para a região
        region_trees = carregar_arvores_region(lat, lon, radius_meters, caminho_tif_arvores, pais, regiao)
        
        if region_trees is not None:
            # Detectar pixels com árvores
            gdf_arvores = detectar_arvores_canopy(region_trees, altura_minima=0.0)  # Alterado para pegar todas as árvores
            
            if not gdf_arvores.empty:
                
                # Detectar quais subpixels contêm árvores (com cálculo de confiança)
                tree_subpixels_data_initial = detect_tree_subpixels(gdf_arvores, all_subpixels, raster_crs, gdf_desvios, all_subpixels_data)
                
                # APLICAR REGRA DE CONFLITO: Remover árvores onde há edifícios
                if building_subpixels_data:
                    
                    # Criar conjunto de índices onde há edifícios
                    building_indices = set(building_data['index'] for building_data in building_subpixels_data)
                    
                    # Filtrar árvores, removendo conflitos
                    tree_subpixels_data = []
                    arvores_removidas = 0
                    
                    for tree_data in tree_subpixels_data_initial:
                        tree_index = tree_data['index']
                        
                        # Se NÃO há edifício neste índice, manter a árvore
                        if tree_index not in building_indices:
                            tree_subpixels_data.append(tree_data)
                        else:
                            arvores_removidas += 1
                    
                else:
                    # Se não há dados de edifícios, manter todas as árvores
                    tree_subpixels_data = tree_subpixels_data_initial
                
                # IMPORTANTE: As estatísticas de árvores serão calculadas durante a geração das imagens individuais
                # para garantir consistência com a renderização visual (baseada em sector_subpixels_data)
                
                # Inicializar estruturas vazias nos resultados - serão preenchidas depois
                for result in results:
                    result['trees'] = {
                        'total_count': 0,
                        'by_height': {
                            'counts': {'0-2m': 0, '2-3m': 0, '3-5m': 0, '5-10m': 0, '10-15m': 0, '15-25m': 0, '>25m': 0},
                            'percentages': {'0-2m': 0.0, '2-3m': 0.0, '3-5m': 0.0, '5-10m': 0.0, '10-15m': 0.0, '15-25m': 0.0, '>25m': 0.0}
                        },
                        'parametros_aerodinamicos': {
                            'z0_stats': {'min': 0, 'max': 0, 'media': 0},
                            'd_stats': {'min': 0, 'max': 0, 'media': 0},
                            'arvores_individuais': []
                        }
                    }
                    # Atualizar estrutura de edifícios para incluir parâmetros aerodinâmicos
                    if 'buildings' in result:
                        result['buildings']['parametros_aerodinamicos'] = {
                            'z0_stats': {'min': 0, 'max': 0, 'media': 0},
                            'd_stats': {'min': 0, 'max': 0, 'media': 0},
                            'edificios_individuais': []
                        }
            else:
                # Adicionar zeros para árvores
                for result in results:
                    result['trees'] = {
                        'total_count': 0,
                        'by_height': {
                            'counts': {'0-2m': 0, '2-3m': 0, '3-5m': 0, '5-10m': 0, '10-15m': 0, '15-25m': 0, '>25m': 0},
                            'percentages': {'0-2m': 0.0, '2-3m': 0.0, '3-5m': 0.0, '5-10m': 0.0, '10-15m': 0.0, '15-25m': 0.0, '>25m': 0.0}
                        },
                        'parametros_aerodinamicos': {
                            'z0_stats': {'min': 0, 'max': 0, 'media': 0},
                            'd_stats': {'min': 0, 'max': 0, 'media': 0},
                            'arvores_individuais': []
                        }
                    }
                    # Garantir que edifícios também tenham parâmetros aerodinâmicos inicializados
                    if 'buildings' in result:
                        result['buildings']['parametros_aerodinamicos'] = {
                            'z0_stats': {'min': 0, 'max': 0, 'media': 0},
                            'd_stats': {'min': 0, 'max': 0, 'media': 0},
                            'edificios_individuais': []
                        }
        else:
            # Adicionar zeros para árvores
            for result in results:
                result['trees'] = {
                    'total_count': 0,
                    'by_height': {
                        'counts': {'0-2m': 0, '2-3m': 0, '3-5m': 0, '5-10m': 0, '10-15m': 0, '15-25m': 0, '>25m': 0},
                        'percentages': {'0-2m': 0.0, '2-3m': 0.0, '3-5m': 0.0, '5-10m': 0.0, '10-15m': 0.0, '15-25m': 0.0, '>25m': 0.0}
                    },
                    'parametros_aerodinamicos': {
                        'z0_stats': {'min': 0, 'max': 0, 'media': 0},
                        'd_stats': {'min': 0, 'max': 0, 'media': 0},
                        'arvores_individuais': []
                    }
                }
                # Garantir que edifícios também tenham parâmetros aerodinâmicos inicializados
                if 'buildings' in result:
                    result['buildings']['parametros_aerodinamicos'] = {
                        'z0_stats': {'min': 0, 'max': 0, 'media': 0},
                        'd_stats': {'min': 0, 'max': 0, 'media': 0},
                        'edificios_individuais': []
                    }
    else:
        # Adicionar zeros para árvores
        for result in results:
            result['trees'] = {
                'total_count': 0,
                'by_height': {
                    'counts': {'0-2m': 0, '2-3m': 0, '3-5m': 0, '5-10m': 0, '10-15m': 0, '15-25m': 0, '>25m': 0},
                    'percentages': {'0-2m': 0.0, '2-3m': 0.0, '3-5m': 0.0, '5-10m': 0.0, '10-15m': 0.0, '15-25m': 0.0, '>25m': 0.0}
                },
                'parametros_aerodinamicos': {
                    'z0_stats': {'min': 0, 'max': 0, 'media': 0},
                    'd_stats': {'min': 0, 'max': 0, 'media': 0},
                    'arvores_individuais': []
                }
            }
            # Garantir que edifícios também tenham parâmetros aerodinâmicos inicializados
            if 'buildings' in result:
                result['buildings']['parametros_aerodinamicos'] = {
                    'z0_stats': {'min': 0, 'max': 0, 'media': 0},
                    'd_stats': {'min': 0, 'max': 0, 'media': 0},
                    'edificios_individuais': []
                }

    # ==============================
    # MAPAS SEPARADOS ADICIONAIS
    # ==============================
    
    # Gerar mapa separado de edifícios (sempre gerar, mesmo sem dados)
    
    if all_subpixels:
        gdf_pixels = gpd.GeoDataFrame(geometry=all_subpixels, crs=raster_crs)
        gdf_pixels_web = gdf_pixels.to_crs(epsg=3857) if raster_crs != "EPSG:3857" else gdf_pixels
        
        create_buildings_map(building_subpixels_data, all_subpixels, gdf_pixels_web,
                           lat, lon, radius_meters, pasta_saida)
    
    # Gerar mapa separado de cobertura do solo
    # Usar dados já existentes no sistema de legendas
    if all_subpixels and len(all_colors) > 0:
        
        # Criar estrutura de dados compatível usando informações já disponíveis
        all_landcover_subpixels = []
        for i, (subpixel, color) in enumerate(zip(all_subpixels, all_colors)):
            # Determinar categoria baseada na cor usando o sistema de legendas existente
            category = "Unknown"
            
            # Buscar categoria correspondente na legenda existente (se houver)
            if 'legend_entries' in locals():
                for cat_name, cat_color in legend_entries.items():
                    if color == cat_color:
                        category = cat_name
                        break
            
            # Se não encontrou na legenda, usar categoria padrão baseada no índice
            if category == "Unknown":
                # Usar uma categoria padrão baseada nas classes conhecidas
                class_keys = list(LANDCOVER_CLASSES.keys())
                if class_keys:
                    class_code = class_keys[i % len(class_keys)]
                    category = LANDCOVER_CLASSES[class_code]
            
            all_landcover_subpixels.append({
                'index': i,
                'category': category,
                'geometry': subpixel,
                'color': color
            })
        
        if all_landcover_subpixels:
            gdf_pixels = gpd.GeoDataFrame(geometry=all_subpixels, crs=raster_crs)
            gdf_pixels_web = gdf_pixels.to_crs(epsg=3857) if raster_crs != "EPSG:3857" else gdf_pixels
            
            create_landcover_map(all_landcover_subpixels, all_subpixels, gdf_pixels_web,
                                lat, lon, radius_meters, pasta_saida)
    # Gerar mapa separado de rugosidade aerodinâmica (Z0)
    
    if all_subpixels_data and len(all_subpixels_data) > 0:
        # NOVA ABORDAGEM: Usar diretamente all_subpixels_data que tem os valores CLC corretos
        
        # Criar GeoDataFrame a partir dos dados reais
        geometries = [item['geometry'] for item in all_subpixels_data]
        gdf_pixels = gpd.GeoDataFrame(geometry=geometries, crs=raster_crs)
        gdf_pixels_web = gdf_pixels.to_crs(epsg=3857) if raster_crs != "EPSG:3857" else gdf_pixels
        
        # Converter all_subpixels_data para formato esperado pelo create_z0_map
        all_landcover_subpixels_z0 = []
        valores_clc_encontrados = set()
        
        for i, item in enumerate(all_subpixels_data):
            clc_value = item.get('value', 0)
            category = item.get('category', 'Unknown')
            valores_clc_encontrados.add(clc_value)
            
            all_landcover_subpixels_z0.append({
                'index': i,
                'original_index': i, 
                'category': category,
                'geometry': item['geometry'],
                'value': clc_value,  # VALOR CLC REAL DO RASTER!
                'pixel_id': item.get('pixel_id', i),
                'sector_id': item.get('sector_id', 'unknown'),
                'color': item.get('color', (0.5, 0.5, 0.5))
            })
        
        # Chamar função de criação do mapa Z0
        z0_map_result = create_z0_map(
            landcover_subpixels_data=all_landcover_subpixels_z0,
            building_subpixels_data=building_subpixels_data,
            tree_subpixels_data=tree_subpixels_data,
            all_subpixels=all_subpixels,
            gdf_pixels_web=gdf_pixels_web,
            lat=lat,
            lon=lon,
            radius_meters=radius_meters,
            pasta_saida=pasta_saida
        )
        
    # Criar pasta de imagens dentro da pasta de saída
    pasta_imagens = os.path.join(pasta_saida, "imagens")
    os.makedirs(pasta_imagens, exist_ok=True)
    
    # Salvar JSON será feito após geração das imagens para incluir estatísticas corretas
    
    # GERAR IMAGENS INDIVIDUAIS PARA CADA SETOR
    
    # Coletar dados de subpixels por setor para processamento
    sector_subpixels_map = {}
    current_subpixel_index = 0
    
    for i, sector_info in enumerate(sectors):
        sector_id = sector_info['sector_id']
        sector_geometry = sector_info['geometry']
        
        # Encontrar subpixels que pertencem a este setor
        sector_subpixels_list = []
        
        for j in range(current_subpixel_index, len(all_subpixels)):
            subpixel_geom = all_subpixels[j]

            # Verificar se este subpixel intersecta com o setor
            if subpixel_geom.intersects(sector_geometry):
                # Determinar a categoria do subpixel
                pixel_color = all_colors[j]

                # Encontrar categoria baseada na cor
                category_found = "Desconhecida"
                for cat, color in legend_entries.items():
                    if color == pixel_color:
                        category_found = cat
                        break

                sector_subpixels_list.append({
                    'geometry': subpixel_geom,
                    'color': pixel_color,
                    'category': category_found,
                    'original_index': j
                })
        
        sector_subpixels_map[sector_id] = sector_subpixels_list
        
        # Processar dados para este setor e capturar estatísticas de árvores/edifícios
        if sector_subpixels_list:  # Só processar se houver subpixels
            sector_tree_stats = create_individual_sector_map(
                sector_info=sector_info,
                sector_subpixels_data=sector_subpixels_list,
                building_subpixels_data=building_subpixels_data,
                tree_subpixels_data=tree_subpixels_data,
                all_subpixels=all_subpixels,
                lat=lat,
                lon=lon,
                radius_meters=radius_meters,
                raster_crs=raster_crs,
                pasta_saida=pasta_saida,
                sector_index=i,
                generate_image=False  # Gerar imagens individuais por setor
            )
            
            # Atualizar estatísticas de árvores, edifícios E land cover no JSON com dados reais do processamento
            for result in results:
                if result['sector_id'] == sector_id:
                    result['trees'] = sector_tree_stats['trees']
                    result['buildings'] = sector_tree_stats['buildings']
                    result['landcover'] = sector_tree_stats['landcover']
                    break
    
    # RECALCULAR PERCENTAGENS COM AS ESTATÍSTICAS CORRETAS (após eliminação de sobreposições)
    
    for result in results:
        buildings_count = result['buildings']['total_count']
        land_count = result['land_cover']['total_subpixels']
        total_elements = land_count + buildings_count
        
        if total_elements > 0:
            result['summary']['land_percentage'] = round(land_count / total_elements * 100, 2)
            result['summary']['buildings_percentage'] = round(buildings_count / total_elements * 100, 2)
            result['summary']['total_elements'] = total_elements
        else:
            result['summary']['land_percentage'] = 0.0
            result['summary']['buildings_percentage'] = 0.0
            result['summary']['total_elements'] = 0
    
    # SALVAR RESULTADOS JSON COM ESTATÍSTICAS ATUALIZADAS
    
    # Calcular totais gerais com base nas estatísticas atualizadas
    total_buildings_all = sum(r['buildings']['total_count'] for r in results)
    total_trees_all = sum(r.get('trees', {}).get('total_count', 0) for r in results)
    
    buildings_height_totals = {'0-2m': 0, '2-3m': 0, '3-5m': 0, '5-7m': 0, '7-10m': 0, '>10m': 0}
    trees_height_totals = {'0-2m': 0, '2-3m': 0, '3-5m': 0, '5-10m': 0, '10-15m': 0, '15-25m': 0, '>25m': 0}
    
    for r in results:
        for height_class, count in r['buildings']['by_height']['counts'].items():
            buildings_height_totals[height_class] += count
        
        if 'trees' in r:
            for height_class, count in r['trees']['by_height']['counts'].items():
                trees_height_totals[height_class] += count
    
    # ==============================
    # SALVAR DADOS COMPLETOS DE PIXELS COM IDs ÚNICOS
    # ==============================
    
    # Criar lista completa de pixels com todas as informações
    all_pixels_complete = []
    
    # Adicionar dados de land cover
    for pixel_data in all_subpixels_data:
        # Calcular z0 e d para land cover
        z0_value = calcular_z0_landcover(pixel_data['category'], pixel_data['value'])
        d_value = calcular_d_landcover(pixel_data['category'], pixel_data['value'])
        
        pixel_complete = {
            'pixel_id': pixel_data['pixel_id'],
            'type': pixel_data['type'],
            'category': pixel_data['category'],
            'value': pixel_data['value'],
            'sector_id': pixel_data['sector_id'],
            'geometry_bounds': list(pixel_data['geometry'].bounds),  # [minx, miny, maxx, maxy]
            'center_coordinates': [pixel_data['geometry'].centroid.x, pixel_data['geometry'].centroid.y],
            'z0': round(z0_value, 3),
            'd': round(d_value, 3)
        }
        all_pixels_complete.append(pixel_complete)
    
    # Adicionar dados de edifícios
    if building_subpixels_data:
        for building in building_subpixels_data:
            if building.get('pixel_id'):
                # Encontrar o pixel original pelos dados de posição
                original_pixel = None
                building_index = building['index']
                if building_index < len(all_subpixels_data):
                    original_pixel = all_subpixels_data[building_index]
                
                # Calcular z0 e d para edifício (considerando land cover)
                altura_edificio = building['altura']
                landcover_code = building.get('landcover_code')
                z0_d_edificio = calcular_z0_e_d_edificio(altura_edificio, landcover_code)
                
                # Obter informações do land cover original que estava nesta posição
                original_landcover = None
                if original_pixel:
                    original_landcover = {
                        'codigo_clc': original_pixel.get('value'),
                        'category': original_pixel.get('category'),
                        'z0_landcover': original_pixel.get('z0_landcover'),
                        'd_landcover': original_pixel.get('d_landcover')
                    }
                
                pixel_complete = {
                    'pixel_id': building['pixel_id'],
                    'type': 'building',
                    'category': 'Edifício',
                    'height': altura_edificio,
                    'sector_id': original_pixel['sector_id'] if original_pixel else None,
                    'geometry_bounds': list(all_subpixels[building_index].bounds) if building_index < len(all_subpixels) else None,
                    'center_coordinates': [all_subpixels[building_index].centroid.x, all_subpixels[building_index].centroid.y] if building_index < len(all_subpixels) else None,
                    'z0': z0_d_edificio['z0'],
                    'd': z0_d_edificio['d'],
                    # INFORMAÇÕES DO LAND COVER ORIGINAL
                    'original_landcover': original_landcover
                }
                all_pixels_complete.append(pixel_complete)
    
    # Adicionar dados de árvores
    if tree_subpixels_data:
        for tree in tree_subpixels_data:
            if tree.get('pixel_id'):
                # Encontrar o pixel original pelos dados de posição
                original_pixel = None
                tree_index = tree['index']
                if tree_index < len(all_subpixels_data):
                    original_pixel = all_subpixels_data[tree_index]
                
                # Calcular z0 e d para árvore
                altura_arvore = tree['altura']
                landcover_code = original_pixel.get('value') if original_pixel else None
                z0_d_arvore = calcular_z0_e_d_arvore(altura_arvore, landcover_code)
                
                # Obter informações do land cover original que estava nesta posição
                original_landcover = None
                if original_pixel:
                    original_landcover = {
                        'codigo_clc': original_pixel.get('value'),
                        'category': original_pixel.get('category'),
                        'z0_landcover': original_pixel.get('z0_landcover'),
                        'd_landcover': original_pixel.get('d_landcover')
                    }
                
                pixel_complete = {
                    'pixel_id': tree['pixel_id'],
                    'type': 'tree',
                    'category': 'Árvore',
                    'height': altura_arvore,
                    'confidence': tree.get('confidence', 0.0),
                    'deviation': tree.get('desvio', 0.0),
                    'sector_id': original_pixel['sector_id'] if original_pixel else None,
                    'geometry_bounds': list(all_subpixels[tree_index].bounds) if tree_index < len(all_subpixels) else None,
                    'center_coordinates': [all_subpixels[tree_index].centroid.x, all_subpixels[tree_index].centroid.y] if tree_index < len(all_subpixels) else None,
                    'z0': z0_d_arvore['z0'],
                    'd': z0_d_arvore['d'],
                    # INFORMAÇÕES DO LAND COVER ORIGINAL
                    'original_landcover': original_landcover
                }
                all_pixels_complete.append(pixel_complete)
    
    # ==============================
    # RESOLVER CONFLITOS DE PIXELS DUPLICADOS
    # ==============================
    
    # Agrupar pixels por pixel_id
    pixels_by_id = {}
    for pixel in all_pixels_complete:
        pixel_id = pixel['pixel_id']
        if pixel_id not in pixels_by_id:
            pixels_by_id[pixel_id] = []
        pixels_by_id[pixel_id].append(pixel)
    
    # Resolver conflitos
    resolved_pixels = []
    conflicts_resolved = 0
    
    for pixel_id, pixel_list in pixels_by_id.items():
        if len(pixel_list) == 1:
            # Sem conflito, adicionar diretamente
            resolved_pixels.append(pixel_list[0])
        else:
            # Há conflito - aplicar regras de prioridade
            has_tree = any(p['type'] == 'tree' for p in pixel_list)
            has_building = any(p['type'] == 'building' for p in pixel_list)
            has_land_cover = any(p['type'] == 'land_cover' for p in pixel_list)
            
            # Filtrar pixels mantendo apenas os prioritários
            kept_pixels = []
            
            for pixel in pixel_list:
                # Manter trees e buildings sempre
                if pixel['type'] in ['tree', 'building']:
                    kept_pixels.append(pixel)
                # Manter land_cover apenas se não há tree nem building
                elif pixel['type'] == 'land_cover' and not has_tree and not has_building:
                    kept_pixels.append(pixel)
            
            # Se removemos algum pixel land_cover, contar como conflito resolvido
            if has_land_cover and (has_tree or has_building):
                conflicts_resolved += 1
            
            resolved_pixels.extend(kept_pixels)
    
    # Ordenar por pixel_id para facilitar consultas
    resolved_pixels.sort(key=lambda x: x['pixel_id'])
    
    # Salvar arquivo com dados completos dos pixels (já resolvidos)
    pixels_output_file = os.path.join(pasta_saida, "all_pixels_with_ids.json")
    with open(pixels_output_file, 'w', encoding='utf-8') as f:
        json.dump({
            'metadata': {
                'total_pixels': len(resolved_pixels),
                'conflicts_resolved': conflicts_resolved,
                'resolution_rules': {
                    'rule_1': 'land_cover + tree → keep only tree',
                    'rule_2': 'land_cover + building → keep only building', 
                    'rule_3': 'tree + building → keep both'
                },
                'pixel_types': {
                    'land_cover': len([p for p in resolved_pixels if p['type'] == 'land_cover']),
                    'buildings': len([p for p in resolved_pixels if p['type'] == 'building']),
                    'trees': len([p for p in resolved_pixels if p['type'] == 'tree'])
                },
                'analysis_info': {
                    'center_coordinates': [lat, lon],
                    'radius_meters': radius_meters,
                    'sectors': n_sectors,
                    'analysis_date': '2025-10-01'
                }
            },
            'pixels': resolved_pixels
        }, f, indent=2, ensure_ascii=False)
    
    # ==============================
    # CRIAR ARQUIVOS JSON SEPARADOS POR SETOR_ANEL
    # ==============================
    
    # Agrupar pixels por sector_id
    pixels_by_sector = {}
    for pixel in resolved_pixels:
        sector_id = pixel.get('sector_id', 'unknown')
        if sector_id not in pixels_by_sector:
            pixels_by_sector[sector_id] = []
        pixels_by_sector[sector_id].append(pixel)
    
    # Criar pasta para arquivos de setores
    setores_folder = os.path.join(pasta_saida, "setores")
    os.makedirs(setores_folder, exist_ok=True)
    
    # Salvar arquivo JSON para cada setor
    for sector_id, sector_pixels in pixels_by_sector.items():
        # Calcular estatísticas do setor
        sector_stats = {
            'land_cover': len([p for p in sector_pixels if p['type'] == 'land_cover']),
            'buildings': len([p for p in sector_pixels if p['type'] == 'building']),
            'trees': len([p for p in sector_pixels if p['type'] == 'tree'])
        }
        
        # Calcular estatísticas por categoria
        categories_stats = {}
        for pixel in sector_pixels:
            category = pixel.get('category', 'Unknown')
            if category not in categories_stats:
                categories_stats[category] = 0
            categories_stats[category] += 1
        
        # Calcular estatísticas de altura para edifícios e árvores
        building_heights = [p.get('height', 0) for p in sector_pixels if p['type'] == 'building' and p.get('height')]
        tree_heights = [p.get('height', 0) for p in sector_pixels if p['type'] == 'tree' and p.get('height')]
        
        # Calcular estatísticas de z0 e d
        z0_values = [p.get('z0', 0) for p in sector_pixels if p.get('z0') is not None]
        d_values = [p.get('d', 0) for p in sector_pixels if p.get('d') is not None]
        
        # Calcular estatísticas descritivas completas para z0 e d
        z0_stats = calculate_descriptive_stats(z0_values)
        d_stats = calculate_descriptive_stats(d_values)
        
        # Calcular estatísticas separadas por tipo de pixel
        land_cover_z0 = [p.get('z0', 0) for p in sector_pixels if p['type'] == 'land_cover' and p.get('z0') is not None]
        trees_z0 = [p.get('z0', 0) for p in sector_pixels if p['type'] == 'tree' and p.get('z0') is not None]
        buildings_z0 = [p.get('z0', 0) for p in sector_pixels if p['type'] == 'building' and p.get('z0') is not None]
        
        land_cover_d = [p.get('d', 0) for p in sector_pixels if p['type'] == 'land_cover' and p.get('d') is not None]
        trees_d = [p.get('d', 0) for p in sector_pixels if p['type'] == 'tree' and p.get('d') is not None]
        buildings_d = [p.get('d', 0) for p in sector_pixels if p['type'] == 'building' and p.get('d') is not None]
        
        # Criar arquivo JSON do setor
        sector_filename = f"setor_{sector_id}.json"
        sector_filepath = os.path.join(setores_folder, sector_filename)
        
        sector_data = {
            'metadata': {
                'sector_id': sector_id,
                'total_pixels': len(sector_pixels),
                'pixel_types': sector_stats,
                'categories': categories_stats,
                'statistics': {
                    'buildings': {
                        'count': len(building_heights),
                        'height_stats': {
                            'min': min(building_heights) if building_heights else 0,
                            'max': max(building_heights) if building_heights else 0,
                            'avg': round(sum(building_heights) / len(building_heights), 2) if building_heights else 0
                        }
                    },
                    'trees': {
                        'count': len(tree_heights),
                        'height_stats': {
                            'min': min(tree_heights) if tree_heights else 0,
                            'max': max(tree_heights) if tree_heights else 0,
                            'avg': round(sum(tree_heights) / len(tree_heights), 2) if tree_heights else 0
                        }
                    },
                    'aerodynamic_parameters': {

                        'overall': {
                            'z0_roughness_length': z0_stats,
                            'd_displacement_height': d_stats
                        },
                        'by_pixel_type': {
                            'land_cover': {
                                'z0': calculate_descriptive_stats(land_cover_z0),
                                'd': calculate_descriptive_stats(land_cover_d)
                            },
                            'trees': {
                                'z0': calculate_descriptive_stats(trees_z0),
                                'd': calculate_descriptive_stats(trees_d)
                            },
                            'buildings': {
                                'z0': calculate_descriptive_stats(buildings_z0),
                                'd': calculate_descriptive_stats(buildings_d)
                            }
                        },
                        'summary': {
                            'z0_description': 'Rugosidade aerodinâmica (m) - Controla o perfil de vento próximo ao solo',
                            'd_description': 'Altura de deslocamento (m) - Nível efetivo de origem do vento',
                            'calculation_method': {
                                'trees': 'z0 = min(alfaArvores * height, 2.0) ou z0 = min(0.15 * height, 2.0), d = 0.67 * height',
                                'buildings': 'z0 = min(0.123 * height, 2.0), d = 0.67 * height',
                                'land_cover': 'z0 = fixed_value_by_category, d = 0.0'
                            }
                        }
                    }
                },
                'analysis_info': {
                    'center_coordinates': [lat, lon],
                    'radius_meters': radius_meters,
                    'analysis_date': '2025-10-01'
                }
            },
            'pixels': sector_pixels
        }
        
        # Salvar arquivo JSON do setor
        with open(sector_filepath, 'w', encoding='utf-8') as f:
            json.dump(sector_data, f, indent=2, ensure_ascii=False)

    # ==============================
    # CRIAR ARQUIVOS JSON CONSOLIDADOS POR SETOR COM ESTATÍSTICAS POR ANEL
    # ==============================
    
    # Agrupar pixels por setor (extrair setor do sector_id)
    pixels_by_main_sector = {}
    
    for pixel in resolved_pixels:
        sector_id = pixel.get('sector_id', 'unknown')
        # Extrair o número do setor (antes do "_anel_")
        main_sector = sector_id.split('_anel_')[0] if '_anel_' in sector_id else sector_id
        
        if main_sector not in pixels_by_main_sector:
            pixels_by_main_sector[main_sector] = {}
        
        # Agrupar por anel dentro do setor
        anel_id = sector_id.split('_anel_')[1] if '_anel_' in sector_id else '1'
        if anel_id not in pixels_by_main_sector[main_sector]:
            pixels_by_main_sector[main_sector][anel_id] = []
        
        pixels_by_main_sector[main_sector][anel_id].append(pixel)
    
    # Criar arquivo JSON consolidado para cada setor
    for main_sector, aneis_data in pixels_by_main_sector.items():
        sector_consolidated_filename = f"setor_{main_sector}_consolidado.json"
        sector_consolidated_filepath = os.path.join(setores_folder, sector_consolidated_filename)
        
        # Estrutura do JSON consolidado
        consolidated_data = {
            'metadata': {
                'sector_id': main_sector,
                'total_aneis': len(aneis_data),
                'analysis_info': {
                    'center_coordinates': [lat, lon],
                    'radius_meters': radius_meters,
                    'analysis_date': '2025-10-01'
                }
            },
            'aneis_statistics': {},
            'sector_summary': {
                'total_pixels': 0,
                'total_land_cover': 0,
                'total_buildings': 0,
                'total_trees': 0
            }
        }
        
        # Processar cada anel
        for anel_id, anel_pixels in aneis_data.items():
            # Calcular estatísticas básicas do anel
            anel_stats = {
                'land_cover': len([p for p in anel_pixels if p['type'] == 'land_cover']),
                'buildings': len([p for p in anel_pixels if p['type'] == 'building']),
                'trees': len([p for p in anel_pixels if p['type'] == 'tree'])
            }
            
            # Calcular estatísticas de z0 e d para todo o anel
            anel_z0_values = [p.get('z0', 0) for p in anel_pixels if p.get('z0') is not None]
            anel_d_values = [p.get('d', 0) for p in anel_pixels if p.get('d') is not None]
            
            # Calcular estatísticas descritivas para o anel
            anel_z0_stats = calculate_descriptive_stats(anel_z0_values)
            anel_d_stats = calculate_descriptive_stats(anel_d_values)
            
            # Adicionar dados do anel ao JSON consolidado
            consolidated_data['aneis_statistics'][f'anel_{anel_id}'] = {
                'total_pixels': len(anel_pixels),
                'pixel_types': anel_stats,
                'aerodynamic_parameters': {
                    'z0_roughness_length': anel_z0_stats,
                    'd_displacement_height': anel_d_stats
                }
            }
            
            # Somar ao resumo geral do setor
            consolidated_data['sector_summary']['total_pixels'] += len(anel_pixels)
            consolidated_data['sector_summary']['total_land_cover'] += anel_stats['land_cover']
            consolidated_data['sector_summary']['total_buildings'] += anel_stats['buildings']
            consolidated_data['sector_summary']['total_trees'] += anel_stats['trees']
        
        anel_z0_means = []  # Nome mantido para compatibilidade, mas agora contém medianas
        anel_d_means = []
        
        for anel_id in sorted(aneis_data.keys(), key=int):
            anel_data = consolidated_data['aneis_statistics'][f'anel_{anel_id}']
            
            # Coletar medianas de z0 e d de cada anel
            z0_mean = anel_data['aerodynamic_parameters']['z0_roughness_length']['median']
            d_mean = anel_data['aerodynamic_parameters']['d_displacement_height']['median']
            
            if z0_mean > 0:  # Só incluir se tem valor válido
                anel_z0_means.append(z0_mean)
            if d_mean > 0:  # Só incluir se tem valor válido
                anel_d_means.append(d_mean)
        
        # Calcular estatísticas simples baseadas nas medianas dos anéis
        sector_z0_stats = calculate_descriptive_stats(anel_z0_means)
        sector_d_stats = calculate_descriptive_stats(anel_d_means)
        
        consolidated_data['sector_summary']['aerodynamic_parameters'] = {
            'z0_roughness_length': sector_z0_stats,
            'd_displacement_height': sector_d_stats,
            'summary': {
                'z0_description': 'Rugosidade aerodinâmica (m) - Controla o perfil de vento próximo ao solo',
                'd_description': 'Altura de deslocamento (m) - Nível efetivo de origem do vento',
                'calculation_method': {
                    'trees': 'z0 = min(alfaArvores * height, 2.0) ou z0 = min(0.15 * height, 2.0), d = 0.67 * height',
                    'buildings': 'z0 = min(0.123 * height, 2.0), d = 0.67 * height',
                    'land_cover': 'z0 = fixed_value_by_category, d = 0.0'
                }
            }
        }
        
        # Salvar arquivo JSON consolidado do setor
        with open(sector_consolidated_filepath, 'w', encoding='utf-8') as f:
            json.dump(consolidated_data, f, indent=2, ensure_ascii=False)

    # Visualização com PatchCollection (MAPA GERAL)
    if all_subpixels:
        gdf_pixels = gpd.GeoDataFrame(geometry=all_subpixels, crs=raster_crs)
        if raster_crs != "EPSG:3857":
            gdf_pixels_web = gdf_pixels.to_crs(epsg=3857)
        else:
            gdf_pixels_web = gdf_pixels

        # Converter setores para Web Mercator para visualização
        sector_geometries = [s['geometry'] for s in sectors]
        sector_ids = [s['sector_id'] for s in sectors]
        sector_types = [s['type'] for s in sectors]
        
        gdf_sectors = gpd.GeoDataFrame({
            'geometry': sector_geometries,
            'sector_id': sector_ids,
            'type': sector_types
        }, crs=raster_crs)
        gdf_sectors_web = gdf_sectors.to_crs(epsg=3857) if raster_crs != "EPSG:3857" else gdf_sectors

        # Criar ponto central em Web Mercator
        transformer_to_web = Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
        center_x_web, center_y_web = transformer_to_web.transform(lon, lat)
        gdf_center = gpd.GeoDataFrame(geometry=[Point(center_x_web, center_y_web)], crs="EPSG:3857")

        fig, ax = plt.subplots(figsize=(15, 15))

        patches = []
        unique_colors = []
        unique_pixels_for_plot = {}  # Para deduplicate na visualização principal
        
        for poly, color in zip(gdf_pixels_web.geometry, all_colors):
            # Usar bounds como chave única para deduplicação visual
            bounds_key = tuple(poly.bounds)
            
            # Se já temos este pixel, pular a visualização
            if bounds_key not in unique_pixels_for_plot:
                unique_pixels_for_plot[bounds_key] = True
                mpl_poly = MplPolygon(list(poly.exterior.coords), closed=True)
                patches.append(mpl_poly)
                unique_colors.append(color)

        collection = PatchCollection(patches, facecolor=unique_colors, edgecolor='white', linewidth=0.1, alpha=0.8)
        ax.add_collection(collection)

        # Plotar bordas dos setores
        for i, sector_geom in enumerate(gdf_sectors_web.geometry):
            gdf_single = gpd.GeoDataFrame(geometry=[sector_geom], crs="EPSG:3857")
            gdf_single.boundary.plot(ax=ax, color='black', linewidth=2, alpha=0.8)

        # Centro não é mais plotado

        # Limites do mapa (usar bounds em Web Mercator)
        minx_map, miny_map, maxx_map, maxy_map = gdf_pixels_web.total_bounds
        ax.set_xlim(minx_map, maxx_map)
        ax.set_ylim(miny_map, maxy_map)

        _adicionar_mapa_base(ax)

        # 2ª CAMADA: Adicionar árvores (por cima da cobertura do solo, por baixo dos edifícios)
        if tree_subpixels_data:

            # Criar patches para árvores com cores baseadas na altura
            tree_patches = []
            tree_colors = []
            tree_height_stats = {}
            unique_pixels_for_plot = {}  # Para deduplicate na visualização

            for tree_data in tree_subpixels_data:
                idx = tree_data['index']
                altura = tree_data['altura']

                # Converter para Web Mercator se necessário
                if raster_crs != "EPSG:3857":
                    geom_web = gdf_pixels_web.geometry.iloc[idx]
                else:
                    geom_web = all_subpixels[idx]
                
                # Usar bounds como chave única para deduplicação visual
                bounds_key = tuple(geom_web.bounds)
                
                # Se já temos este pixel, pular a visualização mas manter estatísticas
                if bounds_key not in unique_pixels_for_plot:
                    unique_pixels_for_plot[bounds_key] = True
                    mpl_poly = MplPolygon(list(geom_web.exterior.coords), closed=True)
                    tree_patches.append(mpl_poly)
                    
                    # Obter cor baseada na altura
                    cor = get_tree_height_color(altura)
                    tree_colors.append(cor)
                
                # Estatísticas por faixa de altura
                categoria = get_extended_height_category(altura)
                tree_height_stats[categoria] = tree_height_stats.get(categoria, 0) + 1

            # Adicionar coleção de árvores 
            tree_collection = PatchCollection(tree_patches, 
                                            facecolor=tree_colors, 
                                            edgecolor='darkgreen', 
                                            linewidth=0.2, 
                                            alpha=0.7)
            ax.add_collection(tree_collection)


        
        # 3ª CAMADA: Adicionar edifícios (por cima de tudo)
        if building_subpixels_data:
            
            # Criar patches para edifícios com cores baseadas na altura
            building_patches = []
            building_colors = []
            building_height_stats = {}
            unique_pixels_for_plot_buildings = {}  # Para deduplicate na visualização de edifícios
            
            for building_data in building_subpixels_data:
                idx = building_data['index']
                altura = building_data['altura']
                
                geom = all_subpixels[idx]
                # Converter para Web Mercator se necessário
                if raster_crs != "EPSG:3857":
                    # Usar o GeoDataFrame já convertido
                    geom_web = gdf_pixels_web.geometry.iloc[idx]
                else:
                    geom_web = geom
                
                # Usar bounds como chave única para deduplicação visual
                bounds_key = tuple(geom_web.bounds)
                
                # Se já temos este pixel, pular a visualização mas manter estatísticas
                if bounds_key not in unique_pixels_for_plot_buildings:
                    unique_pixels_for_plot_buildings[bounds_key] = True
                    mpl_poly = MplPolygon(list(geom_web.exterior.coords), closed=True)
                    building_patches.append(mpl_poly)
                    
                    # Obter cor baseada na altura
                    cor = get_building_height_color(altura)
                    building_colors.append(cor)
                
                # Estatísticas por faixa de altura
                categoria = get_building_height_category(altura)
                building_height_stats[categoria] = building_height_stats.get(categoria, 0) + 1

            # Adicionar coleção de edifícios por cima (maior transparência para mostrar árvores por baixo)
            building_collection = PatchCollection(building_patches, 
                                                facecolor=building_colors, 
                                                edgecolor='navy', 
                                                linewidth=0.3, 
                                                alpha=0.8)  # Ligeiramente mais opaco que as árvores
            ax.add_collection(building_collection)



        # Legenda (cobertura do solo + árvores + edifícios)
        handles = [Patch(color=c, label=label) for label, c in legend_entries.items()]
        
        # Adicionar legenda das árvores se existirem
        if tree_subpixels_data:
            handles.append(Patch(color='white', label='--- Trees ---'))
            # Tree color legend by height
            arvores_legenda = get_tree_extended_colors()
            for altura, cor in arvores_legenda.items():
                handles.append(Patch(color=cor, label=f'Trees {altura}'))
        
        # Adicionar legenda dos edifícios se existirem
        if building_subpixels_data:
            handles.append(Patch(color='white', label='--- Buildings ---'))
            # Building color legend by height
            edificios_legenda = get_building_extended_colors()
            for altura, cor in edificios_legenda.items():
                handles.append(Patch(color=cor, label=f'Buildings {altura}'))
        
        ax.legend(handles=handles, bbox_to_anchor=(1.05, 1), loc="upper left")

        # Dynamic title
        title_parts = ["Land Cover Analysis"]
        
        # Adicionar componentes baseado no que está disponível
        if tree_subpixels_data:
            title_parts.append("+ Trees")
        if building_subpixels_data:
            title_parts.append("+ Buildings")
            
        title_parts.append("by Concentric Rings")

        ax.set_aspect("equal")
        ax.set_axis_off()
        plt.tight_layout()

        # Filename based on included components
        filename_parts = ["land_cover_raster_map"]
        if tree_subpixels_data:
            filename_parts.append("with_trees")
        if building_subpixels_data:
            filename_parts.append("with_buildings")
        filename = "_".join(filename_parts) + ".jpg"
        
        pasta_imagens = os.path.join(pasta_saida, "imagens")
        os.makedirs(pasta_imagens, exist_ok=True)
        caminho_completo = os.path.join(pasta_imagens, filename)
        plt.savefig(caminho_completo, dpi=300, bbox_inches='tight', format='jpeg')
        plt.close()
        
        # Mensagem final
        components = ["cobertura do solo"]
        if tree_subpixels_data:
            components.append("árvores")
        if building_subpixels_data:
            components.append("edifícios")
        
    # Gerar relatório de análise aerodinâmica
    generate_analysis_report(pasta_saida)
    
    # CALCULAR TODOS OS PARÂMETROS AERODINÂMICOS FINAIS
    final_wk_data = calculate_final_aerodynamic_parameters(pasta_saida, sectors, lat, lon, radius_meters, altura_torre, n_sectors, raio_inicial, ring_data)
    
    # Verificar se a pasta de saída existe e tem dados
    if not os.path.exists(pasta_saida):
        return None
        
    # Verificar se há arquivos de setores
    setores_folder = os.path.join(pasta_saida, "setores")
    if not os.path.exists(setores_folder):
        return None
        
    # Contar arquivos de setores consolidados
    arquivos_consolidados = [f for f in os.listdir(setores_folder) if f.endswith('_consolidado.json')]
    if not arquivos_consolidados:
        return None
    
    # Gerar relatório de análise aerodinâmica
    relatorio_path = generate_analysis_report(pasta_saida)
    
    if relatorio_path is None:
        return None
    
    # GERAR MAPA DE MEDIANAS Z0 POR ANEL
    try:
        # Carregar dados do relatório para o mapa
        with open(relatorio_path, 'r', encoding='utf-8') as f:
            relatorio_data = json.load(f)
        
        # Criar mapa de medianas usando os setores e relatório
        median_map_result = create_median_values_map(
            sectors=sectors,
            relatorio_data=relatorio_data,
            lat=lat,
            lon=lon,
            radius_meters=radius_meters,
            pasta_saida=pasta_saida,
            raster_crs=raster_crs
        )
            
    except Exception as e:
        print(f"Erro ao gerar mapa de medianas: {e}")
    
    # CALCULAR TODOS OS PARÂMETROS AERODINÂMICOS FINAIS
    final_wk_data = calculate_final_aerodynamic_parameters(pasta_saida, sectors, lat, lon, radius_meters, altura_torre, n_sectors, raio_inicial, ring_data)
    
    if final_wk_data is not None:
        # GERAR MAPA DE Z0_SETOR_FINAL POR SETOR
        try:
            # Caminho para o arquivo wk_by_main_sector.json
            wk_file_path = os.path.join(pasta_saida, "wk_by_main_sector.json")
            
            if os.path.exists(wk_file_path):
                # Criar mapa de setores usando z0_setor_final
                sector_map_result = create_sector_final_z0_map(
                    sectors=sectors,
                    wk_by_main_sector_path=wk_file_path,
                    lat=lat,
                    lon=lon,
                    radius_meters=radius_meters,
                    pasta_saida=pasta_saida,
                    n_sectors=n_sectors,
                    raster_crs=raster_crs
                )
                
                if sector_map_result:
                    # SEPARADO: a parte de vento saiu para  Vento/WindAnalysis.py
                    # Aqui so escrevemos o "contrato" (site_info.json) que esse
                    # modulo le, junto com o wk_by_main_sector.json.
                    _site_info = {
                        "id": id_torre, "pais": pais, "regiao": regiao,
                        "lat": lat, "lon": lon, "altura_torre": altura_torre,
                        "n_sectors": n_sectors, "radius_meters": radius_meters,
                        "raio_inicial": raio_inicial,
                        "gerado_em": datetime.now().isoformat(timespec="seconds"),
                    }
                    with open(os.path.join(pasta_saida, "site_info.json"), "w", encoding="utf-8") as _f:
                        json.dump(_site_info, _f, ensure_ascii=False, indent=2)
                    print("site_info.json escrito -> corre  Vento/WindAnalysis.py  para vb/mapa/pressao")


        except Exception as e:
            print(f"Erro ao gerar mapa de setores: {e}")
    
    if final_wk_data is None:
        return None        

    return final_wk_data

def calculate_final_aerodynamic_parameters(pasta_saida, sectors, lat, lon, radius_meters, altura_torre, n_sectors_original, raio_inicial, ring_data=None):
    """
    Função dedicada para calcular todos os parâmetros aerodinâmicos finais:
    - Wk (weight factors)
    - z0 correto (usando dados completos do relatório)
    - ln(z0_setor) usando fórmula: Σ(Wk * ln(z0,k)) / Σ(Wk)
    - Prints informativos
    - Salvamento global dos dados
    
    Esta função é chamada APENAS quando todos os dados estão prontos
    (land cover + árvores + edifícios + relatório gerado)
    """
    
    # Inicializar logger detalhado
    logger = AerodynamicCalculationLogger(pasta_saida)
    logger.log_step("initialization", "Iniciando cálculos aerodinâmicos finais", {
        "lat": lat,
        "lon": lon,
        "radius_meters": radius_meters,
        "total_sectors": len(sectors)
    })
    
    # ==============================
    # REGISTRAR PARÂMETROS INICIAIS DOS CÁLCULOS
    # ==============================
    # Calcular raio dinâmico baseado na altura da torre (fórmula do main)
    raio_calculado = 23 * (altura_torre ** 1.2)
    print(f"Raio calculado pela fórmula: {raio_calculado:.2f}m (23 * ({altura_torre} ** 1.2))")
    if raio_calculado < 300:
        raio_calculado = 300
    raio_final = radius_meters  # Após ajustes dinâmicos
    
    # Preparar dados dos anéis se disponíveis
    ring_info = {}
    if ring_data:
        ring_info = {
            "numero_aneis": len(ring_data["ring_radii"]),
            "fator_crescimento": ring_data.get("growth_factor", 1.05),
            "aneis_detalhado": []
        }
        
        # Calcular larguras individuais dos anéis
        ring_widths = []
        for i, radius in enumerate(ring_data["ring_radii"]):
            if i == 0:
                width = radius
            else:
                width = radius - ring_data["ring_radii"][i-1]
            ring_widths.append(width)
        
        # Adicionar detalhes de cada anel
        for i, (width, radius_acum, radius_medio) in enumerate(zip(ring_widths, ring_data["ring_radii"], ring_data["raio_medio"]), 1):
            ring_info["aneis_detalhado"].append({
                "anel_numero": i,
                "largura_m": round(width, 2),
                "raio_acumulativo_m": round(radius_acum, 2),
                "raio_medio_m": round(radius_medio, 2),
                "formula": "0.1 * raio_total" if i == 1 else f"F{i-1} * {ring_data.get('growth_factor', 1.05)}"
            })
    
    logger.log_step("initial_parameters", "Parâmetros iniciais dos cálculos aerodinâmicos", {
        "altura_torre_m": altura_torre,
        "coordenadas": {
            "latitude": lat,
            "longitude": lon
        },
        "raio_inicial_m": raio_inicial,
        "raio_calculado_formula": f"23 * ({altura_torre} ** 1.2) = {raio_calculado:.2f}m",
        "raio_final_m": raio_final,
        "numero_setores_original": n_sectors_original,
        "numero_divisoes_concentricas": len(ring_data["ring_radii"]) if ring_data else 3,
        "aneis_concentricos": ring_info,
        "parametros_formula": {
            "coeficiente_raio": 23,
            "expoente_altura": 1.2,
            "divisor_parametro_L": 3
        },
        "observacoes": [
            "Altura da torre utilizada para cálculo do raio de influência",
            "Raio calculado usando fórmula: 23 * (altura_torre ** 1.2)",
            f"Divisões concêntricas: cada setor é dividido em {len(ring_data['ring_radii']) if ring_data else 3} anéis",
            "Parâmetro L calculado como: raio_final / 3",
            "Anéis calculados dinamicamente com fator de crescimento 1.05",
            "Primeiro anel = 0.1 * raio_total, seguintes = anel_anterior * 1.05"
        ]
    })
    
    # Carregar arquivo do relatório de análise aerodinâmica
    relatorio_file = os.path.join(pasta_saida, "relatorio_analise_aerodinamica.json")
    if not os.path.exists(relatorio_file):
        return
    
    try:
        with open(relatorio_file, 'r', encoding='utf-8') as f:
            relatorio_data = json.load(f)

    except Exception as e:
        return
    
    # Carregar arquivo wk_by_main_sector.json se já existe
    wk_file = os.path.join(pasta_saida, "wk_by_main_sector.json")
    wk_data = {}
    if os.path.exists(wk_file):
        try:
            with open(wk_file, 'r', encoding='utf-8') as f:
                wk_data = json.load(f)
        except Exception as e:
            print(f"Erro ao carregar dados Wk existentes: {e}")
    
    # Calcular L (parâmetro de escala)
    L = radius_meters / 3
    
    # Log do cálculo de L
    logger.log_calculation("L_parameter", "L = radius_meters / 3", {
        "radius_meters": radius_meters,
        "divisor": 3
    }, L, "Cálculo do parâmetro de escala L")
    
    # Estruturas para armazenar cálculos
    wk_by_main_sector = {}
    wk_ln_z0_by_main_sector = {}
    wk_d_by_main_sector = {}  # Nova estrutura para armazenar Wk * d
    sector_details = {}
        
    # Processar cada setor
    for i, sector_info in enumerate(sectors):
        sector_id = sector_info['sector_id']
        sector_geometry = sector_info['geometry']
        
        # Calcular área do setor em metros quadrados
        utm_zone = int((lon + 180) / 6) + 1
        hemisphere = 'north' if lat >= 0 else 'south'
        utm_crs = f"EPSG:326{utm_zone:02d}" if hemisphere == 'north' else f"EPSG:327{utm_zone:02d}"
        
        # Variáveis de CRS (não logadas para simplificar)
        
        try:
            import geopandas as gpd
            from pyproj import CRS
            # Assumir que raster_crs é LAEA (do contexto do código)
            raster_crs = "EPSG:3035"  # LAEA Europe
            gdf_sector_utm = gpd.GeoDataFrame(geometry=[sector_geometry], crs=raster_crs).to_crs(utm_crs)
            area_m2 = gdf_sector_utm.geometry.iloc[0].area
            
            # Log do cálculo da área
            logger.log_step(f"area_{sector_id}", f"Setor {sector_id} - Cálculo da área em metros quadrados via reprojeção UTM", {
                "calculation_name": "area_calculation",
                "formula": "Reprojeção LAEA -> UTM",
                "inputs": {
                    "original_crs": raster_crs,
                    "target_crs": utm_crs
                },
                "result": area_m2,
                "description": "Cálculo da área em metros quadrados via reprojeção UTM"
            })
            
        except Exception as e:
            # Fallback aproximado
            area_m2 = sector_geometry.area
            
            # Log do fallback
            logger.log_step(f"area_fallback_{sector_id}", f"Setor {sector_id} - Cálculo da área usando método fallback", {
                "calculation_name": "area_fallback",
                "formula": "Fallback area calculation",
                "inputs": {
                    "error": str(e),
                    "fallback_method": "sector_geometry.area"
                },
                "result": area_m2,
                "description": "Cálculo da área usando método fallback devido a erro na reprojeção"
            })
        
        # Obter raio médio do setor
        raio_medio_equivalente = sector_info.get('raio_medio', 0.0)
        
        # Calcular Wk usando a fórmula: W(k) = area_m2 * exp(-raio_medio_equivalente/L)
        Wk = area_m2 * math.exp(-raio_medio_equivalente / L) if L > 0 else 0.0
        
        # Log detalhado do cálculo de Wk
        wk_log_data = logger.log_wk_calculation(sector_id, area_m2, raio_medio_equivalente, L, Wk)
        
        # Separar setor principal e anel
        main_sector = sector_id.split('_anel_')[0] if '_anel_' in sector_id else sector_id
        anel_id = sector_id.split('_anel_')[1] if '_anel_' in sector_id else '1'
        
        # Inicializar estruturas se necessário
        if main_sector not in wk_by_main_sector:
            wk_by_main_sector[main_sector] = {}
            wk_ln_z0_by_main_sector[main_sector] = {}
            wk_d_by_main_sector[main_sector] = {}  # Nova estrutura para Wk * d
            sector_details[main_sector] = {}
        
        # Armazenar Wk
        wk_by_main_sector[main_sector][f"Anel_{anel_id}"] = round(Wk, 6)
        
        # Buscar z0 e d específicos deste anel no relatório
        relatorio_setor_name = f"Setor_{main_sector}"
        z0_anel = 0.001  # Valor padrão
        d_anel = 0.0     # Valor padrão
        
        # Variáveis Z0 e D (não logadas para simplificar)
        
        if relatorio_setor_name in relatorio_data.get("sectors_analysis", {}):
            try:
                # Buscar dados detalhados do anel específico
                aneis_analysis = relatorio_data["sectors_analysis"][relatorio_setor_name]["aneis_detailed_analysis"]
                anel_name = f"Anel_{anel_id}"
                
                # Nome do anel (não logado para simplificar)
                
                if anel_name in aneis_analysis:
                    # Pegar z0 mediana específico deste anel
                    z0_anel_str = aneis_analysis[anel_name]["z0_statistics"]["Median"]
                    z0_anel = float(z0_anel_str)
                    
                    # Pegar d mediana específico deste anel
                    d_anel_str = aneis_analysis[anel_name]["d_statistics"]["Median"]
                    d_anel = float(d_anel_str)
                    
                else:
                    z0_anel = 0.001
                    d_anel = 0.0
                    
            except (KeyError, ValueError) as e:
                z0_anel = 0.001
                d_anel = 0.0
        
        # Calcular ln(z0) e Wk * ln(z0)
        z0_anel_adjusted = max(z0_anel, 0.001)  # Evitar log(0)
        ln_z0_anel = math.log(z0_anel_adjusted)
        wk_ln_z0 = Wk * ln_z0_anel
        
        # Calcular Wk * d (usa mesmo Wk, mas sem logaritmo)
        wk_d = Wk * d_anel
        
        # Log dos cálculos logarítmicos
        logger.log_step(f"ln_z0_{sector_id}", f"Setor {sector_id} - Cálculo do logaritmo natural de z0", {
            "formula": "ln(z0_anel)",
            "inputs": {
                "z0_anel_original": z0_anel,
                "z0_anel_adjusted": z0_anel_adjusted,
                "adjustment_reason": "max(z0_anel, 0.001) para evitar log(0)",
                "ln_result": ln_z0_anel
            },
            "result": ln_z0_anel,
            "description": "Cálculo do logaritmo natural de z0"
        })
        
        logger.log_step(f"wk_ln_z0_{sector_id}", f"Setor {sector_id} - Cálculo do produto Wk × ln(z0)", {
            "formula": "Wk * ln(z0)",
            "inputs": {
                "Wk": Wk,
                "ln_z0_anel": ln_z0_anel,
                "multiplication_result": wk_ln_z0
            },
            "result": wk_ln_z0,
            "description": "Cálculo do produto Wk × ln(z0)"
        })
        
        logger.log_step(f"wk_d_{sector_id}", f"Setor {sector_id} - Cálculo do produto Wk × d", {
            "formula": "Wk * d",
            "inputs": {
                "Wk": Wk,
                "d_anel": d_anel,
                "multiplication_result": wk_d
            },
            "result": wk_d,
            "description": "Cálculo do produto Wk × d (mesmo Wk do z0, sem logaritmo)"
        })
        
        # Armazenar valores
        wk_ln_z0_by_main_sector[main_sector][f"Anel_{anel_id}"] = round(wk_ln_z0, 6)
        wk_d_by_main_sector[main_sector][f"Anel_{anel_id}"] = round(wk_d, 6)
        
        # Armazenar detalhes para print
        sector_details[main_sector][f"Anel_{anel_id}"] = {
            'area_m2': area_m2,
            'raio_medio': raio_medio_equivalente,
            'Wk': Wk,
            'z0_anel': z0_anel,
            'ln_z0': ln_z0_anel,
            'wk_ln_z0': wk_ln_z0,
            'd_anel': d_anel,
            'wk_d': wk_d
        }
    
    wk_final_structure = {}
    
    for main_sector, aneis_wk in wk_by_main_sector.items():
        sector_name = f"Setor_{main_sector}"
        wk_final_structure[sector_name] = aneis_wk.copy()
        
        # Calcular Σ Wk (total do setor)
        total_wk = sum(aneis_wk.values())
        wk_final_structure[sector_name]["Total"] = round(total_wk, 6)
        
        # Log do cálculo de Σ Wk
        logger.log_step(f"sum_wk_{sector_name}", f"Soma Wk para {sector_name}", {
            "aneis_wk_values": aneis_wk,
            "sum_calculation": f"sum({list(aneis_wk.values())})",
            "total_wk": total_wk
        })
        
        # Calcular Σ(Wk * ln(z0))
        if main_sector in wk_ln_z0_by_main_sector:
            soma_wk_ln_z0 = sum(wk_ln_z0_by_main_sector[main_sector].values())
            
            # Log do cálculo de Σ(Wk * ln(z0))
            logger.log_step(f"sum_wk_ln_z0_{sector_name}", f"Soma Wk*ln(z0) para {sector_name}", {
                "wk_ln_z0_values": wk_ln_z0_by_main_sector[main_sector],
                "sum_calculation": f"sum({list(wk_ln_z0_by_main_sector[main_sector].values())})",
                "soma_wk_ln_z0": soma_wk_ln_z0
            })
            
            # Aplicar fórmula final: ln(z0_setor) = Σ(Wk * ln(z0,k)) / Σ(Wk)
            if total_wk > 0:
                ln_z0_setor_final = soma_wk_ln_z0 / total_wk
                # Calcular z0_setor final aplicando exponencial: z0_setor = exp(ln(z0_setor))
                z0_setor_final = math.exp(ln_z0_setor_final)
                valor_final = z0_setor_final
            else:
                ln_z0_setor_final = 0.0
                z0_setor_final = 1.0  # exp(0) = 1
                valor_final = z0_setor_final
            
            # Log do cálculo final do setor usando a função específica do logger
            logger.log_final_sector_calculation(sector_name, total_wk, soma_wk_ln_z0, ln_z0_setor_final, z0_setor_final)
            
            # Calcular d_setor baseado no valor de z0_setor usando fórmula em cascata
            # Fórmula: IF(z0<=0.01, 1, IF(z0<=0.05, 25*(z0-0.01)+1, IF(z0<=0.3, 12*(z0-0.05)+2, IF(z0<=1, 7.142857*(z0-0.3)+5, 10))))
            if z0_setor_final <= 0.01:
                d_setor_final = 1.0
            elif z0_setor_final <= 0.05:
                d_setor_final = 25 * (z0_setor_final - 0.01) + 1
            elif z0_setor_final <= 0.3:
                d_setor_final = 12 * (z0_setor_final - 0.05) + 2
            elif z0_setor_final <= 1.0:
                d_setor_final = 7.142857142857 * (z0_setor_final - 0.3) + 5
            else:
                d_setor_final = 10.0
            
            # Arredondar para 2 casas decimais
            d_setor_final = round(d_setor_final, 2)
            
            # Log do cálculo de d_setor baseado em z0_setor
            logger.log_step(f"d_setor_{sector_name}", f"Cálculo de dSetor baseado em z0_setor para {sector_name}", {
                "formula": "IF(z0<=0.01, 1, IF(z0<=0.05, 25*(z0-0.01)+1, IF(z0<=0.3, 12*(z0-0.05)+2, IF(z0<=1, 7.142857*(z0-0.3)+5, 10))))",
                "z0_setor_final": z0_setor_final,
                "d_setor_final": d_setor_final,
                "description": "d calculado baseado no valor de z0_setor usando fórmula em cascata"
            })
            
            # Armazenar resultados finais
            wk_final_structure[sector_name]["Valor_Final"] = round(valor_final, 6)
            wk_final_structure[sector_name]["z0_setor_final"] = round(z0_setor_final, 6)
            wk_final_structure[sector_name]["ln_z0_setor"] = round(ln_z0_setor_final, 6)
            wk_final_structure[sector_name]["soma_wk_ln_z0"] = round(soma_wk_ln_z0, 6)
            wk_final_structure[sector_name]["d_setor_final"] = d_setor_final  # Já arredondado para 2 casas
            
            # # EXIBIÇÃO DAS MEDIANAS E CÁLCULOS
            # print(f"\n{'='*80}")
            # print(f"{sector_name} - CÁLCULO DE d_setor BASEADO EM z0_setor")
            # print(f"{'='*80}")
            
            # print(f"\nValor de z0_setor calculado:")
            # print(f"   z0_setor = {z0_setor_final:.6f} m")
            
            # print(f"\nCálculo de d_setor baseado em z0_setor:")
            # print(f"   Fórmula em cascata:")
            # print(f"   • Se z0 ≤ 0.01:           d = 1")
            # print(f"   • Se 0.01 < z0 ≤ 0.05:    d = 25 × (z0 - 0.01) + 1")
            # print(f"   • Se 0.05 < z0 ≤ 0.3:     d = 12 × (z0 - 0.05) + 2")
            # print(f"   • Se 0.3 < z0 ≤ 1.0:      d = 7.142857 × (z0 - 0.3) + 5")
            # print(f"   • Se z0 > 1.0:            d = 10")
            
            # Determinar qual faixa foi usada
            if z0_setor_final <= 0.01:
                faixa_usada = "z0 ≤ 0.01"
                calculo_mostrado = "d = 1"
            elif z0_setor_final <= 0.05:
                faixa_usada = "0.01 < z0 ≤ 0.05"
                calculo_mostrado = f"d = 25 × ({z0_setor_final:.6f} - 0.01) + 1 = {d_setor_final:.2f}"
            elif z0_setor_final <= 0.3:
                faixa_usada = "0.05 < z0 ≤ 0.3"
                calculo_mostrado = f"d = 12 × ({z0_setor_final:.6f} - 0.05) + 2 = {d_setor_final:.2f}"
            elif z0_setor_final <= 1.0:
                faixa_usada = "0.3 < z0 ≤ 1.0"
                calculo_mostrado = f"d = 7.142857 × ({z0_setor_final:.6f} - 0.3) + 5 = {d_setor_final:.2f}"
            else:
                faixa_usada = "z0 > 1.0"
                calculo_mostrado = "d = 10"
            
            # print(f"\n   Faixa aplicada: {faixa_usada}")
            # print(f"   Cálculo: {calculo_mostrado}")
            # print(f"\n   d_setor = {d_setor_final:.2f} m")
            
            # print(f"{'='*80}\n")
            
        else:
            wk_final_structure[sector_name]["Valor_Final"] = 1.0
            wk_final_structure[sector_name]["z0_setor_final"] = 1.0
            wk_final_structure[sector_name]["ln_z0_setor"] = 0.0
            wk_final_structure[sector_name]["d_setor_final"] = 0.0
            
            # Log do caso onde não há dados de Wk×ln(z0)
            logger.log_step(f"no_data_{sector_name}", f"Sem dados Wk*ln(z0) para {sector_name}", {
                "sector_name": sector_name,
                "main_sector": main_sector,
                "available_sectors": list(wk_ln_z0_by_main_sector.keys()),
                "fallback_values": {
                    "Valor_Final": 1.0,
                    "z0_setor_final": 1.0,
                    "ln_z0_setor": 0.0
                }
            })
    
    # Salvar arquivo final
    try:
        wk_final_file = os.path.join(pasta_saida, "wk_by_main_sector.json")
        with open(wk_final_file, 'w', encoding='utf-8') as f:
            json.dump(wk_final_structure, f, indent=2, ensure_ascii=False)
        
        # EXIBIR RESUMO CONSOLIDADO DE TODOS OS SETORES
        # print(f"\n{'='*80}")
        # print(f"RESUMO CONSOLIDADO - d_setor E z0_setor DE TODOS OS SETORES")
        # print(f"{'='*80}")
        # print(f"{'Setor':<15} {'z0_setor (m)':<15} {'d_setor (m)':<15} {'Σ(Wk)':<15}")
        # print(f"{'-'*80}")
        
        for sector_name in sorted(wk_final_structure.keys()):
            if sector_name.startswith("Setor_"):
                z0_val = wk_final_structure[sector_name].get("z0_setor_final", 0.0)
                d_val = wk_final_structure[sector_name].get("d_setor_final", 0.0)
                total_wk = wk_final_structure[sector_name].get("Total", 0.0)
                
                # print(f"{sector_name:<15} {z0_val:<15.6f} {d_val:<15.2f} {total_wk:<15.6f}")
        
        # print(f"{'='*80}")
        # print(f"z0_setor calculado com: exp(Σ(Wk × ln(z0)) / Σ(Wk))")
        # print(f"d_setor calculado baseado em z0_setor usando fórmula em cascata:")
        # print(f"     IF(z0≤0.01, 1, IF(z0≤0.05, 25*(z0-0.01)+1, IF(z0≤0.3, 12*(z0-0.05)+2,")
        # print(f"        IF(z0≤1, 7.142857*(z0-0.3)+5, 10))))")
        # print(f"{'='*80}\n")
        
        # Log do salvamento final
        logger.log_step("save_final_results", "Salvamento dos resultados finais", {
            "file_path": wk_final_file,
            "sectors_processed": len(wk_final_structure),
            "final_structure_keys": list(wk_final_structure.keys())
        })
        
        # Salvar log detalhado
        log_path = logger.save_log("aerodynamic_calculations_detailed_log.json")
        
        return wk_final_structure
        
    except Exception as e:
        print(f"Erro ao salvar arquivo final: {e}")
        logger.log_step("save_error", "Erro no salvamento final", {
            "error_type": type(e).__name__,
            "error_message": str(e)
        })
        
        # Mesmo com erro, salvar o log
        logger.save_log("aerodynamic_calculations_error_log.json")
        return None

def generate_analysis_report(pasta_saida):
    """
    Gera um relatório de análise estruturado para fácil interpretação
    Mostra os cálculos detalhados por setor e anel
    """    
    # Caminho dos arquivos consolidados
    pasta_setores = os.path.join(pasta_saida, "setores")
    
    if not os.path.exists(pasta_setores):
        print("Pasta de setores não encontrada!")
        return
    
    # Estrutura do relatório
    report = {
        "metadata": {
            "title": "Relatório de Análise Aerodinâmica por Setor e Anel",
            "description": "Análise detalhada dos parâmetros Z0 e D para cada setor e anel",
            "analysis_date": datetime.now().strftime('%Y-%m-%d'),
            "calculation_notes": {
                "z0_description": "Rugosidade aerodinâmica (m) - Controla o perfil de vento próximo ao solo",
                "d_description": "Altura de deslocamento (m) - Nível efetivo de origem do vento",
                "statistics_explanation": "Cada valor mostra a contribuição individual dos anéis para a estatística final do setor",
                "calculation_method": "Média aritmética simples dos valores dos anéis"
            }
        },
        "sectors_analysis": {}
    }
    
    # Descobrir setores disponíveis dinamicamente
    arquivos_setor = [f for f in os.listdir(pasta_setores) if f.endswith('_consolidado.json')]
    
    if not arquivos_setor:
        return
        
    # Processa cada setor dinamicamente
    for arquivo_setor in sorted(arquivos_setor):
        # Extrair sector_id do nome do arquivo (ex: setor_1_consolidado.json -> 1)
        sector_id = arquivo_setor.replace('setor_', '').replace('_consolidado.json', '')
        file_path = os.path.join(pasta_setores, arquivo_setor)
            
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                sector_data = json.load(f)
            
            sector_name = f"Setor_{sector_id}"
            
            # Estrutura do setor
            sector_analysis = {
                "sector_info": {
                    "total_pixels": sector_data["sector_summary"]["total_pixels"],
                    "total_aneis": sector_data["metadata"]["total_aneis"],
                    "pixel_distribution": {
                        "land_cover": sector_data["sector_summary"]["total_land_cover"],
                        "buildings": sector_data["sector_summary"]["total_buildings"],
                        "trees": sector_data["sector_summary"]["total_trees"]
                    }
                },
                "aneis_detailed_analysis": {},
                "sector_consolidated_calculations": {
                    "z0_roughness_length": {},
                    "d_displacement_height": {}
                }
            }
            
            # Coleta valores de cada anel para cálculos consolidados
            z0_values_by_anel = []
            d_values_by_anel = []
            anel_names = []
            
            # Análise detalhada por anel - processar dinamicamente
            aneis_disponiveis = list(sector_data.get("aneis_statistics", {}).keys())
            
            for anel_key in sorted(aneis_disponiveis):
                # Extrair ID do anel (ex: anel_1 -> Anel_1)
                anel_id = anel_key.replace('anel_', '')
                anel_name = f"Anel_{anel_id}"
                
                anel_data = sector_data["aneis_statistics"][anel_key]
                
                # Dados do anel
                z0_stats = anel_data["aerodynamic_parameters"]["z0_roughness_length"]
                d_stats = anel_data["aerodynamic_parameters"]["d_displacement_height"]
                
                # Armazena valores para consolidação
                z0_values_by_anel.append(z0_stats["mean"])
                d_values_by_anel.append(d_stats["mean"])
                anel_names.append(anel_name)
                
                # Análise detalhada do anel
                sector_analysis["aneis_detailed_analysis"][anel_name] = {
                    "summary": {
                        "total_pixels": anel_data["total_pixels"],
                        "land_cover": anel_data["pixel_types"]["land_cover"],
                        "buildings": anel_data["pixel_types"]["buildings"],
                        "trees": anel_data["pixel_types"]["trees"]
                    },
                    "z0_statistics": {
                        "Mean": f"{z0_stats['mean']:.4f}",
                        "Median": f"{z0_stats['median']:.4f}",
                        "Mode": f"{z0_stats['mode']:.4f}",
                        "Std_Dev": f"{z0_stats['std_dev']:.4f}",
                        "Range": f"{z0_stats['min']:.3f} - {z0_stats['max']:.3f}",
                        "Count": z0_stats["count"]
                    },
                    "d_statistics": {
                        "Mean": f"{d_stats['mean']:.4f}",
                        "Median": f"{d_stats['median']:.4f}",
                            "Mode": f"{d_stats['mode']:.4f}",
                            "Std_Dev": f"{d_stats['std_dev']:.4f}",
                            "Range": f"{d_stats['min']:.3f} - {d_stats['max']:.3f}",
                            "Count": d_stats["count"]
                        }
                    }
            
            # Cálculos consolidados do setor
            if z0_values_by_anel and d_values_by_anel:
                # Z0 Consolidado (mantém média aritmética simples para compatibilidade)
                z0_mean = sum(z0_values_by_anel) / len(z0_values_by_anel)
                z0_calculation_detail = " + ".join([f"{val:.4f}" for val in z0_values_by_anel])
                z0_calculation_formula = f"({z0_calculation_detail}) ÷ {len(z0_values_by_anel)} = {z0_mean:.4f}"
                
                sector_analysis["sector_consolidated_calculations"]["z0_roughness_length"] = {
                    "final_result": f"{z0_mean:.4f}",
                    "calculation_formula": z0_calculation_formula,
                    "detailed_breakdown": {
                        anel_names[i]: f"{z0_values_by_anel[i]:.4f}" 
                        for i in range(len(anel_names))
                    },
                    "sum_of_values": f"{sum(z0_values_by_anel):.4f}",
                    "number_of_aneis": len(z0_values_by_anel)
                }
                
                # D Consolidado - USAR FÓRMULA PONDERADA: d_setor = Σ(Wk * dk) / Σ(Wk)
                # Buscar d_setor_final do arquivo wk_by_main_sector.json
                wk_file = os.path.join(pasta_saida, "wk_by_main_sector.json")
                d_setor_calculated = None
                
                if os.path.exists(wk_file):
                    try:
                        with open(wk_file, 'r', encoding='utf-8') as f:
                            wk_data = json.load(f)
                            if sector_name in wk_data and "d_setor_final" in wk_data[sector_name]:
                                d_setor_calculated = wk_data[sector_name]["d_setor_final"]
                                soma_wk_d = wk_data[sector_name].get("soma_wk_d", 0.0)
                                total_wk = wk_data[sector_name].get("Total", 1.0)
                    except Exception as e:
                        print(f"Erro ao ler d_setor de wk_by_main_sector.json: {e}")
                
                # Usar valor calculado com fórmula ponderada ou fallback para média simples
                if d_setor_calculated is not None:
                    d_mean = d_setor_calculated
                    d_calculation_formula = f"Σ(Wk × dk) / Σ(Wk) = {soma_wk_d:.4f} / {total_wk:.4f} = {d_mean:.4f}"
                    calculation_method = "weighted_average_wk"
                else:
                    # Fallback: média aritmética simples
                    d_mean = sum(d_values_by_anel) / len(d_values_by_anel)
                    d_calculation_detail = " + ".join([f"{val:.4f}" for val in d_values_by_anel])
                    d_calculation_formula = f"({d_calculation_detail}) ÷ {len(d_values_by_anel)} = {d_mean:.4f} [FALLBACK - média simples]"
                    calculation_method = "simple_average_fallback"
                
                sector_analysis["sector_consolidated_calculations"]["d_displacement_height"] = {
                    "final_result": f"{d_mean:.4f}",
                    "calculation_formula": d_calculation_formula,
                    "calculation_method": calculation_method,
                    "detailed_breakdown": {
                        anel_names[i]: f"{d_values_by_anel[i]:.4f}" 
                        for i in range(len(anel_names))
                    },
                    "sum_of_values": f"{sum(d_values_by_anel):.4f}",
                    "number_of_aneis": len(d_values_by_anel)
                }
            
            report["sectors_analysis"][sector_name] = sector_analysis
            
        except Exception as e:
            print(f"Erro ao processar {sector_name}: {e}")
            continue
    
    # Salva o relatório
    report_path = os.path.join(pasta_saida, "relatorio_analise_aerodinamica.json")
    try:
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)            
        return report_path
        
    except Exception as e:
        return None

def create_median_values_map(sectors, relatorio_data, lat, lon, radius_meters, pasta_saida, raster_crs="IGNF:ETRS89LAEA"):
    """
    Cria um mapa onde todos os pixels dentro de cada anel têm o valor da mediana Z0 resultante daquele anel.
    Segue exatamente as mesmas regras dos outros mapas: divisões de anel, pixels, rotação, tamanho de cada anel, etc.
    
    Args:
        sectors: Lista de setores/anéis divididos com suas geometrias
        relatorio_data: Dados do relatório com medianas calculadas por anel
        lat, lon: Coordenadas do centro
        radius_meters: Raio em metros
        pasta_saida: Pasta onde salvar o mapa
        raster_crs: Sistema de coordenadas do raster
    """
    # Gerando mapa silencioso de valores de mediana por anel
    
    # Criar ponto central em Web Mercator para visualização
    transformer_to_web = Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
    center_x_web, center_y_web = transformer_to_web.transform(lon, lat)
    gdf_center = gpd.GeoDataFrame(geometry=[Point(center_x_web, center_y_web)], crs="EPSG:3857")
    
    # Preparar estruturas para o mapa
    anel_patches = []
    anel_colors = []
    anel_values = []
    anel_legends = {}
    value_stats = {
        'min_value': float('inf'),
        'max_value': float('-inf'),
        'total_aneis': 0,
        'aneis_com_dados': 0
    }
    
    # Processar cada setor/anel
    for i, sector_info in enumerate(sectors):
        sector_id = sector_info['sector_id']
        sector_geometry = sector_info['geometry']
        ring_number = sector_info.get('ring_number', 1)
        original_sector = sector_info.get('original_sector', 1)
        
        # Extrair mediana Z0 do relatório para este anel específico
        z0_median = 0.001  # Valor padrão
        setor_name = f"Setor_{original_sector}"
        anel_name = f"Anel_{ring_number}"
        
        try:
            if setor_name in relatorio_data.get("sectors_analysis", {}):
                aneis_analysis = relatorio_data["sectors_analysis"][setor_name]["aneis_detailed_analysis"]
                if anel_name in aneis_analysis:
                    z0_median_str = aneis_analysis[anel_name]["z0_statistics"]["Median"]
                    z0_median = float(z0_median_str)
                    value_stats['aneis_com_dados'] += 1
        except (KeyError, ValueError) as e:
            print(f"   Erro ao extrair mediana para {setor_name}-{anel_name}: {e}")

        # Atualizar estatísticas de valores
        if z0_median > 0:
            value_stats['min_value'] = min(value_stats['min_value'], z0_median)
            value_stats['max_value'] = max(value_stats['max_value'], z0_median)

        value_stats['total_aneis'] += 1

        # Converter geometria para Web Mercator para visualização
        if raster_crs != "EPSG:3857":
            transformer_to_web_geom = Transformer.from_crs(raster_crs, "EPSG:3857", always_xy=True)
            
            # Converter polígono para Web Mercator
            if hasattr(sector_geometry, 'exterior'):
                # É um polígono
                coords = list(sector_geometry.exterior.coords)
                web_coords = [transformer_to_web_geom.transform(x, y) for x, y in coords]
                sector_geom_web = geom.Polygon(web_coords)
            else:
                # Outros tipos de geometria - tentar conversão direta
                from shapely.ops import transform
                sector_geom_web = transform(transformer_to_web_geom.transform, sector_geometry)
        else:
            sector_geom_web = sector_geometry
        
        # Verificar se a geometria é válida e tem área
        if sector_geom_web.is_valid and sector_geom_web.area > 0:
            # Criar patch para matplotlib
            if hasattr(sector_geom_web, 'exterior'):
                mpl_poly = MplPolygon(list(sector_geom_web.exterior.coords), closed=True)
                anel_patches.append(mpl_poly)
                
                # Obter cor baseada no valor da mediana Z0
                cor = get_z0_color_by_value(z0_median)
                anel_colors.append(cor)
                anel_values.append(z0_median)
                
                # Adicionar à legenda
                valor_categoria = get_z0_value_category(z0_median)
                if valor_categoria not in anel_legends:
                    anel_legends[valor_categoria] = {
                        'color': cor,
                        'count': 0,
                        'value_range': get_z0_range_for_category(valor_categoria)
                    }
                anel_legends[valor_categoria]['count'] += 1
    
    # Finalizar estatísticas
    if value_stats['min_value'] == float('inf'):
        value_stats['min_value'] = 0.001
    if value_stats['max_value'] == float('-inf'):
        value_stats['max_value'] = 0.001

    if not anel_patches:
        return None
    
    # Criar figura
    fig, ax = plt.subplots(figsize=(15, 15))
    
    # Adicionar coleção de anéis com valores de mediana
    anel_collection = PatchCollection(anel_patches, 
                                    facecolor=anel_colors, 
                                    edgecolor='black', 
                                    linewidth=0.3, 
                                    alpha=0.85)
    ax.add_collection(anel_collection)
        
    # Centro não é mais plotado
    
    # Calcular limites do mapa baseados nos patches
    if anel_patches:
        all_coords = []
        for patch in anel_patches:
            coords = patch.get_path().vertices
            all_coords.extend(coords)
        
        if all_coords:
            xs, ys = zip(*all_coords)
            minx_patches, maxx_patches = min(xs), max(xs)
            miny_patches, maxy_patches = min(ys), max(ys)
            
            # Adicionar buffer de 5%
            buffer_x = (maxx_patches - minx_patches) * 0.05
            buffer_y = (maxy_patches - miny_patches) * 0.05
            
            ax.set_xlim(minx_patches - buffer_x, maxx_patches + buffer_x)
            ax.set_ylim(miny_patches - buffer_y, maxy_patches + buffer_y)
    
    # Adicionar mapa base
    _adicionar_mapa_base(ax)
    
    # Colorbar -- a UNICA da solucao, partilhada por todos os mapas
    # circulares (mapas_circulares.adicionar_colorbar_padrao).
    import matplotlib.colors as mcolors
    try:
        colormap = plt.colormaps.get_cmap('viridis')
    except (AttributeError, KeyError):
        from matplotlib import cm
        colormap = cm.get_cmap('viridis')
    norm = mcolors.Normalize(vmin=0, vmax=2)  # escala fixa 0-2, igual aos outros mapas z0
    adicionar_colorbar_padrao(ax, colormap, norm, fmt="{:.2f}")

    ax.set_aspect("equal")
    ax.set_axis_off()
    plt.tight_layout(pad=0.5)
    
    # Save map
    filename = "z0_median_map_by_ring.jpg"
    pasta_imagens = os.path.join(pasta_saida, "imagens")
    os.makedirs(pasta_imagens, exist_ok=True)
    caminho_completo = os.path.join(pasta_imagens, filename)
    
    try:
        plt.savefig(caminho_completo, dpi=300, bbox_inches='tight', pad_inches=0.1, format='jpeg')
        plt.close()
        
        return {
            'filename': caminho_completo,
            'total_aneis': value_stats['total_aneis'],
            'aneis_com_dados': value_stats['aneis_com_dados'],
            'z0_range': {
                'min': value_stats['min_value'],
                'max': value_stats['max_value']
            },
            'patches_created': len(anel_patches),
            'legend_categories': len(anel_legends)
        }
        
    except Exception as e:
        plt.close()
        return None

def create_sector_final_z0_map(sectors, wk_by_main_sector_path, lat, lon, radius_meters, pasta_saida, n_sectors, raster_crs="IGNF:ETRS89LAEA"):
    """
    Cria um mapa onde cada setor inteiro é pintado com uma cor uniforme baseada no valor z0_setor_final 
    do arquivo wk_by_main_sector.json. Cada setor é uma fatia completa do círculo, sem divisões de anéis.
    
    Args:
        sectors: Lista de setores/anéis divididos com suas geometrias
        wk_by_main_sector_path: Caminho para o arquivo wk_by_main_sector.json
        lat, lon: Coordenadas do centro
        radius_meters: Raio em metros
        n_sectors: Número de setores
        pasta_saida: Pasta onde salvar o mapa
        raster_crs: Sistema de coordenadas do raster
    """
    # Gerando mapa silencioso de z0_setor_final por setor
    
    # Carregar dados
    try:
        with open(wk_by_main_sector_path, 'r', encoding='utf-8') as f:
            wk_data = json.load(f)
    except Exception as e:
        return None
    
    # Extrair valores z0_setor_final e d_setor_final (zmin) de cada setor
    setores_z0_values = {}
    setores_zmin_values = {}

    for setor_name, setor_data in wk_data.items():
        if 'z0_setor_final' in setor_data:
            setor_id = int(setor_name.split('_')[1])
            setores_z0_values[setor_id] = setor_data['z0_setor_final']
            setores_zmin_values[setor_id] = setor_data.get('d_setor_final', 0)

    # Estatisticas (para o dict devolvido -- o desenho em si fica todo a
    # cargo de desenhar_mapa_circular, a mesma funcao dos outros mapas
    # circulares da solucao: mesma tela, mesmo circulo, mesma colorbar).
    min_z0, max_z0 = float('inf'), float('-inf')
    valores = []
    rotulos = []
    for setor_id in range(1, n_sectors + 1):
        z0_value = setores_z0_values.get(setor_id)
        if z0_value is None:
            valores.append(None)
            rotulos.append("")
            continue
        min_z0 = min(min_z0, z0_value)
        max_z0 = max(max_z0, z0_value)
        zmin_value = setores_zmin_values.get(setor_id, 0)
        valores.append(z0_value)
        rotulos.append(f"Z0 = {z0_value:.3f} m\nZmin = {zmin_value:.2f} m")

    pasta_imagens = os.path.join(pasta_saida, "imagens")
    caminho_completo = os.path.join(pasta_imagens, "final_z0_map_by_sector.jpg")
    desenhar_mapa_circular(
        valores, lat, lon, caminho_completo, radius_meters,
        cmap_name="viridis", vmin=0, vmax=2, rotulos=rotulos,
        alpha_fatia=0.85, fontsize_fatia=12)

    return {
        'filename': caminho_completo,
        'total_setores': n_sectors,
        'setores_com_dados': len(setores_z0_values),
        'z0_range': {
            'min': min_z0,
            'max': max_z0
        }
    }

# Para compatibilidade com execução direta
if __name__ == "__main__":
    # INICIAR CONTADOR DE TEMPO
    inicio_execucao = time.time()
    timestamp_inicio = datetime.now()
    print(f"  INICIANDO EXECUÇÃO - {timestamp_inicio.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # Verificar se argumentos foram passados via linha de comando
    if len(sys.argv) == 2:
        # Formato: python script.py ID_Torre,PAIS,LAT,LON,ALTURA_TORRE,N_SECTORS,REGIAO
        # Exemplo: python LTBDataCollectorPixel6.py 52,Portugal,42.215214,-3.252412,35,12,Porto
        try:
            argumentos = sys.argv[1].split(',')
            if len(argumentos) >= 6:
                ID_Torre = argumentos[0].strip()
                PAIS = argumentos[1].strip()
                LAT = float(argumentos[2].strip())
                LON = float(argumentos[3].strip())
                ALTURA_TORRE = float(argumentos[4].strip())
                N_SECTORS = int(argumentos[5].strip())
                REGIAO = argumentos[6].strip() if len(argumentos) > 6 else "N/A"

                # Validação do N_SECTORS
                if N_SECTORS < 1 or N_SECTORS > 36:
                    raise ValueError(f"Numero de setores deve ser maior que 1. Valor fornecido: {N_SECTORS}")

                print(f"  ARGUMENTOS RECEBIDOS:")
                print(f"   • ID Torre: {ID_Torre}")
                print(f"   • País: {PAIS}")
                print(f"   • Região: {REGIAO}")
                print(f"   • Latitude: {LAT}")
                print(f"   • Longitude: {LON}")
                print(f"   • Altura Torre: {ALTURA_TORRE}m")
                print(f"   • Número de Setores: {N_SECTORS}")
            else:
                raise ValueError("Número incorreto de argumentos")
        except (ValueError, IndexError) as e:
            print("ERRO: Formato de argumentos inválido!")
            print("USO CORRETO:")
            print("   LTBDataCollector.exe ID_Torre,PAIS,LAT,LON,ALTURA_TORRE,N_SECTORS,REGIAO")
            print("EXEMPLO:")
            print("   LTBDataCollector.exe 52,Portugal,42.215214,-3.252412,35,12,Porto")
            print("   LTBDataCollector.exe 52,Portugal,42.215214,-3.252412,35,12")
            sys.exit(1)
    else:
        # Sem argumentos = erro obrigatório
        print("ERRO: Argumentos obrigatórios não fornecidos!")
        print("USO CORRETO:")
        print("   LTBDataCollector.exe ID_Torre,PAIS,LAT,LON,ALTURA_TORRE,N_SECTORS,REGIAO")
        print("EXEMPLO:")
        print("   LTBDataCollector.exe 52,Portugal,42.215214,-3.252412,35,12,Porto")
        print("   LTBDataCollector.exe 52,Portugal,42.215214,-3.252412,35,12")
        sys.exit(1)

    # Configurações fixas
    RAIO_INICIAL = 23 * (ALTURA_TORRE ** 1.2)
    if RAIO_INICIAL < 300:
        RAIO_INICIAL = 300
    RADIUS_METERS = RAIO_INICIAL

    print("=" * 60)
    analyze_land_cover(LAT, LON, RADIUS_METERS, N_SECTORS, ALTURA_TORRE, RAIO_INICIAL, PAIS, ID_Torre, REGIAO)

    # FINALIZAR CONTADOR DE TEMPO
    fim_execucao = time.time()
    timestamp_fim = datetime.now()
    duracao_segundos = fim_execucao - inicio_execucao
    duracao_formatada = str(timedelta(seconds=int(duracao_segundos)))

    print("=" * 60)
    print(f"EXECUÇÃO FINALIZADA - {timestamp_fim.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"TEMPO TOTAL DE EXECUÇÃO: {duracao_formatada} ({duracao_segundos:.2f} segundos)")

    print(f"PERFORMANCE: {duracao_segundos/60:.2f} minutos")