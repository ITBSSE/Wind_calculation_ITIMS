r"""
config.py  --  configuracao partilhada do C0Z0_Solution
=======================================================

Todos os rasters/geojson grandes vivem na pasta  dados/  que fica AO LADO
do executavel (.exe) ou, em desenvolvimento, ao lado deste ficheiro.
Nao ha qualquer dependencia de pastas fora da solution.

Prioridade para achar a pasta dos dados:
  1. variavel de ambiente  C0Z0_DADOS  (se definida)
  2. pasta  dados/  ao lado do .exe (frozen) ou deste config.py (dev)
"""
import os
import sys


def _base_dir():
    """Pasta base: onde esta o .exe (PyInstaller) ou este config.py (dev)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


DADOS = os.environ.get("C0Z0_DADOS") or os.path.join(_base_dir(), "dados")


def dados(*partes):
    """Caminho para um ficheiro/pasta de dados dentro de DADOS."""
    return os.path.join(DADOS, *partes)
