r"""
mapas_circulares.py -- codigo PARTILHADO por todos os mapas circulares da
solucao (em RugosidadeZ0.py, WindAnalysis.py, co_wind_analysis.py):

  adicionar_colorbar_padrao(...)  -- a UNICA colorbar da solucao. Usada
      por TODOS os mapas circulares, sejam de fatias ou de pixels/aneis:
      final_z0_map_by_sector.jpg, qp_pressure.jpg, co_map.jpg (via
      desenhar_mapa_circular, abaixo) E TAMBEM z0_map.jpg,
      z0_median_map_by_ring.jpg, setor_N_individual.jpg (chamada
      diretamente do RugosidadeZ0.py). Antes cada mapa tinha a sua propria
      copia deste bloco de codigo -- agora e uma so funcao.

  desenhar_mapa_circular(...)      -- desenha os mapas de N FATIAS
      discretas (uma cor/valor por direcao): final_z0_map_by_sector.jpg,
      qp_pressure.jpg, co_map.jpg. Os mapas de pixel continuo
      (z0_map.jpg) ou de aneis concentricos (z0_median_map_by_ring.jpg)
      tem conteudo diferente demais para partilhar esta funcao -- mas
      partilham a colorbar acima.

Tamanho final: fica a cargo do padronizar_imagens do run_site (etapa 5),
tal como ja acontecia com z0_map.jpg/z0_median_map_by_ring.jpg -- nao e
um tamanho fixo aqui dentro.
"""

import math
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")   # servidor Linux sem display / .exe onefile
import matplotlib.pyplot as plt
from matplotlib.patches import Wedge
from matplotlib.colorbar import ColorbarBase
from mpl_toolkits.axes_grid1 import make_axes_locatable
from pyproj import Transformer

try:
    import contextily as ctx
except Exception:
    ctx = None


def _obter_colormap(nome):
    try:
        return plt.colormaps.get_cmap(nome)
    except Exception:
        from matplotlib import cm
        return cm.get_cmap(nome)


def adicionar_colorbar_padrao(ax, cmap, norm, orientation="vertical",
                                posicao=None, tamanho="5%", pad=0.01,
                                labelsize=16, tick_pad=5, rotulo=None,
                                fmt=None, n_ticks=7):
    """A UNICA colorbar da solucao -- usada por TODOS os mapas circulares,
    sejam de fatias (desenhar_mapa_circular) ou de pixels/aneis
    (create_z0_map, create_median_values_map, etc., em RugosidadeZ0.py):
    make_axes_locatable, colada ao eixo do mapa (5% da largura/altura,
    1% de padding), letras a 16px. Antes cada mapa tinha a sua propria
    copia deste bloco -- agora e uma so funcao, chamada de todos os
    sitios, para nunca mais desalinhar.

    SEMPRE exatamente n_ticks (default 7) numeros, igualmente espacados
    entre norm.vmin e norm.vmax -- em vez de deixar o matplotlib escolher
    automaticamente ("nice ticks"), que muda de quantidade e espacamento
    dependendo do intervalo de cada mapa (nalguns casos dava 6 numeros
    bem espacados, noutros mais de 10 numeros quase colados, com o do
    topo/fundo real "encavalado" no numero redondo mais proximo). Como o
    primeiro e o ultimo tick SAO norm.vmin/norm.vmax por construcao,
    ficam sempre exatamente nas pontas da barra tambem.
    fmt (opcional, ex. "{:.2f}") formata TODOS os numeros da barra com a
    mesma convencao usada no resto do mapa (fatias/pixels)."""
    divider = make_axes_locatable(ax)
    if posicao is None:
        posicao = "right" if orientation == "vertical" else "bottom"
    cax = divider.append_axes(posicao, size=tamanho, pad=pad)
    cb = ColorbarBase(cax, cmap=cmap, norm=norm, orientation=orientation)

    ticks = np.linspace(norm.vmin, norm.vmax, n_ticks)
    cb.set_ticks(ticks)
    if fmt:
        cb.set_ticklabels([fmt.format(t) for t in ticks])

    cb.ax.tick_params(labelsize=labelsize, pad=tick_pad)
    if rotulo:
        cb.set_label(rotulo, fontsize=10)
    return cb


def desenhar_mapa_circular(valores, lat, lon, caminho, radius_meters,
                            cmap_name="viridis", vmin=None, vmax=None,
                            rotulos=None, fmt="{:.2f}", titulo_legenda=None,
                            alpha_fatia=0.85, fontsize_fatia=15):
    """
    Desenha o mapa circular padrao da solucao -- a MESMA receita que
    z0_map.jpg / z0_median_map_by_ring.jpg ja usam: `len(valores)` fatias
    (sentido horario a partir do Norte), cada uma colorida por
    `valores[i]` num colormap continuo, com texto no meio da fatia, mapa
    de fundo, e a colorbar de sempre (make_axes_locatable, 5% de largura,
    letras a 16px). Grava em `caminho` -- o tamanho final e igualado aos
    outros mapas pelo padronizar_imagens do run_site (etapa 5), como ja
    acontecia com z0_map.jpg/z0_median_map_by_ring.jpg.

    valores        : lista de N numeros -- define a COR de cada fatia.
                      Uma fatia com valor None fica sem cor nem texto
                      (usada quando um setor nao tem dado).
    rotulos        : lista paralela de STRINGS ja formatadas para mostrar
                      dentro de cada fatia (aceita "\n" para varias
                      linhas). Se None, usa fmt.format(valores[i]).
    vmin, vmax     : escala fixa do colormap/colorbar. None (o padrao) =
                      automatico, a partir do min/max de `valores`.
    titulo_legenda : se dado, mostra uma caixa "titulo / min=.. / max=.."
                      no canto inferior direito do mapa.
    alpha_fatia    : transparencia das fatias (0 = invisivel, 1 = opaco).
    fontsize_fatia : tamanho da fonte do texto dentro de cada fatia.
    """
    if lat is None or lon is None:
        return None
    validos = [v for v in valores if v is not None]
    if not validos:
        return None

    vmin_f = vmin if vmin is not None else min(validos)
    vmax_f = vmax if vmax is not None else max(validos)
    if vmax_f <= vmin_f:
        vmax_f = vmin_f + 1e-6

    tr = Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
    cx, cy = tr.transform(lon, lat)
    radius_meters = max(300, radius_meters)
    r_wm = radius_meters / math.cos(math.radians(lat))

    cmap = _obter_colormap(cmap_name)
    norm = plt.Normalize(vmin=vmin_f, vmax=vmax_f)

    # figsize igual ao dos outros mapas (setup_map_base/create_median_values_map,
    # em RugosidadeZ0.py) -- se este canvas nativo fosse menor, o texto (que
    # tem tamanho fixo em pontos) precisaria de MENOS reducao para caber no
    # tamanho final padronizado (padronizar_imagens), ficando maior que nos
    # outros mapas.
    fig, ax = plt.subplots(figsize=(15, 15), dpi=100)

    n = len(valores)
    angulo_fatia = 360.0 / n
    for i, val in enumerate(valores):
        if val is None:
            continue
        centro = 90 - i * angulo_fatia   # Norte = 90 graus no matplotlib, sentido horario
        t1, t2 = centro - angulo_fatia / 2, centro + angulo_fatia / 2
        ax.add_patch(Wedge((cx, cy), r_wm, t1, t2, facecolor=cmap(norm(val)),
                           edgecolor="black", linewidth=1, alpha=alpha_fatia))
        mid = math.radians((t1 + t2) / 2.0)
        texto = rotulos[i] if rotulos is not None else fmt.format(val)
        ax.text(cx + r_wm * 0.7 * math.cos(mid), cy + r_wm * 0.7 * math.sin(mid),
                texto, fontsize=fontsize_fatia, fontweight="bold", ha="center", va="center",
                color="black",
                bbox=dict(boxstyle="round,pad=0.4", facecolor="white", alpha=0.9,
                          edgecolor="black", linewidth=1))

    if titulo_legenda:
        ax.text(0.98, 0.02, f"{titulo_legenda}\nmin = {fmt.format(vmin_f)}\nmax = {fmt.format(vmax_f)}",
                transform=ax.transAxes, fontsize=11, va="bottom", ha="right",
                family="monospace", fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.5", facecolor="white", alpha=0.92,
                          edgecolor="black", linewidth=1.5))

    # Buffer equilibrado para distancia adequada das bordas -- igual aos
    # outros mapas circulares da solucao.
    buffer = r_wm * 1.12
    ax.set_xlim(cx - buffer, cx + buffer)
    ax.set_ylim(cy - buffer, cy + buffer)
    ax.set_aspect("equal")

    if ctx is not None:
        try:
            ctx.add_basemap(ax, source=ctx.providers.Esri.WorldGrayCanvas,
                            alpha=0.6, attribution=False)
        except Exception as e:
            print(f"    [AVISO] mapa sem fundo (contextily): {e}")

    adicionar_colorbar_padrao(ax, cmap, norm, fmt=fmt)

    ax.set_axis_off()

    os.makedirs(os.path.dirname(caminho) or ".", exist_ok=True)
    plt.tight_layout(pad=0.5)
    fig.savefig(caminho, dpi=300, bbox_inches="tight", pad_inches=0.1, facecolor="white", edgecolor="none")
    plt.close(fig)
    return caminho
