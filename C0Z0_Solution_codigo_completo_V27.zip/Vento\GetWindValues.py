import json
from shapely.geometry import shape, Point


def get_wind_value(latitude, longitude, geojson_path="Wind_Map_Spain_EC.geojson"):

    try:
        # Ler o arquivo GeoJSON
        with open(geojson_path, 'r', encoding='utf-8') as f:
            geojson_data = json.load(f)
        
        point = Point(longitude, latitude)
        
        # Iterar sobre as features do GeoJSON
        for feature in geojson_data['features']:
            # Criar a geometria da feature
            polygon = shape(feature['geometry'])
            
            # Verificar se o ponto está dentro do polígono
            if polygon.contains(point):
                # Retornar as propriedades da feature
                return {
                    'vb': feature['properties']['vb'],
                    'zona': feature['properties']['Zona'],
                    'fid': feature['properties']['FID']
                }
        
        return None
        
    except FileNotFoundError:
        print(f"Erro: Arquivo '{geojson_path}' não encontrado.")
        return None
    except json.JSONDecodeError:
        print(f"Erro: Arquivo '{geojson_path}' não é um JSON válido.")
        return None
    except Exception as e:
        print(f"Erro ao processar o arquivo GeoJSON: {e}")
        return None


def get_wind_value_from_coordinates(latitude, longitude):

    result = get_wind_value(latitude, longitude)
    if result:
        return result['vb']
    return None


if __name__ == "__main__":
    lat = 40.4168  # Madrid
    lon = -3.7038
    
    print(f"Buscando valor de vento para coordenadas: ({lat}, {lon})")
    
    # Usando a função completa
    resultado = get_wind_value(lat, lon)
    if resultado:
        print(f"\nResultado encontrado:")
        print(f"  - Valor de vento (vb): {resultado['vb']} m/s")
        print(f"  - Zona: {resultado['zona']}")
        print(f"  - FID: {resultado['fid']}")
    else:
        print("\nCoordenada não encontrada no mapa de ventos.")
    
    # Usando a função simplificada
    vb = get_wind_value_from_coordinates(lat, lon)
    print(f"\nValor vb (simplificado): {vb}")