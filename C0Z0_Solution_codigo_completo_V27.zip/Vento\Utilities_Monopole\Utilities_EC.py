
import numpy as np
def ClasseFiabilidade(Pais,Classe_Fiabilidade):
    if Pais in ["Geral","Portugal","France","Spain"]:
        if Classe_Fiabilidade==3:
            Gamma_Perm_Des=1.2
            Gamma_Variable_Des=1.6
            Gamma_Perm_Fav=1
            Gamma_Variable_Fav=0
        elif Classe_Fiabilidade==2:
            Gamma_Perm_Des=1.1
            Gamma_Variable_Des=1.4
            Gamma_Perm_Fav=1
            Gamma_Variable_Fav=0
        elif Classe_Fiabilidade==1:
            Gamma_Perm_Des=1
            Gamma_Variable_Des=1.2
            Gamma_Perm_Fav=1
            Gamma_Variable_Fav=0
    elif Pais in ["Portugal-RSA"]:
        Gamma_Perm_Des=1.35
        Gamma_Variable_Des=1.5
        Gamma_Perm_Fav=1
        Gamma_Variable_Fav=0
    elif Pais in ["Italy"]:
        Gamma_Perm_Des=1.35
        Gamma_Variable_Des=1.5
        Gamma_Perm_Fav=1
        Gamma_Variable_Fav=0   
    elif Pais in ["Spain_NB_AE"]:
        Gamma_Perm_Des=1.0
        Gamma_Variable_Des=1.0
        Gamma_Perm_Fav=1.0
        Gamma_Variable_Fav=0.0            
    elif Pais in ["United Kingdom"]:
        if Classe_Fiabilidade==1:
            Gamma_Perm_Des=1
            Gamma_Variable_Des=1.2
            Gamma_Perm_Fav=0
            Gamma_Variable_Fav=0 
        elif Classe_Fiabilidade==2:
            Gamma_Perm_Des=1.1
            Gamma_Variable_Des=1.45
            Gamma_Perm_Fav=0
            Gamma_Variable_Fav=0 
        else:
            Gamma_Perm_Des=1.2
            Gamma_Variable_Des=1.6
            Gamma_Perm_Fav=0
            Gamma_Variable_Fav=0 
    elif Pais in ["Germany"]:
        if Classe_Fiabilidade==1:
            Gamma_Perm_Des=1.1
            Gamma_Variable_Des=1.3
            Gamma_Perm_Fav=0
            Gamma_Variable_Fav=0 
        elif Classe_Fiabilidade==2:
            Gamma_Perm_Des=1.3
            Gamma_Variable_Des=1.5
            Gamma_Perm_Fav=0
            Gamma_Variable_Fav=0 
        else:
            Gamma_Perm_Des=1.5
            Gamma_Variable_Des=1.9
            Gamma_Perm_Fav=0
            Gamma_Variable_Fav=0 
    return  Gamma_Perm_Des,Gamma_Variable_Des,Gamma_Perm_Fav,Gamma_Variable_Fav    
