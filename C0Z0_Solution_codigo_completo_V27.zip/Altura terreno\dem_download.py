r"""
Download sob demanda de elevacao (Copernicus GLO-30 DEM) para qualquer
coordenada do mundo, via bucket publico da AWS (sem API key):

  https://registry.opendata.aws/copernicus-dem/

Os tiles sao de 1 grau x 1 grau, nomeados pelo canto SW
(ex: lat 48.85, lon 2.35 -> tile N48_E002). Cada tile baixado fica
cacheado em dem_cache/tiles/ -- corridas futuras na mesma area reusam o
ficheiro em vez de baixar de novo. Quando uma area precisa de mais de um
tile (ponto perto de uma fronteira de grau), os tiles sao mesclados num
mosaico, tambem cacheado, em dem_cache/mosaicos/.
"""

import math
import os
import sys
import urllib.request

import rasterio
from rasterio.merge import merge

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# --- C0Z0_Solution: dem_cache/ vive em  dados/  ao lado do .exe / do codigo ---
try:
    _RAIZ = os.path.dirname(BASE_DIR)
    if _RAIZ not in sys.path:
        sys.path.insert(0, _RAIZ)
    from config import DADOS as _DADOS
except Exception:
    _b = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(BASE_DIR)
    _DADOS = os.environ.get("C0Z0_DADOS") or os.path.join(_b, "dados")

DEM_CACHE_DIR = os.path.join(_DADOS, "dem_cache")
DEM_TILES_DIR = os.path.join(DEM_CACHE_DIR, "tiles")
DEM_MOSAICS_DIR = os.path.join(DEM_CACHE_DIR, "mosaicos")

COPERNICUS_DEM_BASE_URL = "https://copernicus-dem-30m.s3.amazonaws.com"


def _nome_tile(lat_tile, lon_tile):
    lat_str = f"N{lat_tile:02d}" if lat_tile >= 0 else f"S{abs(lat_tile):02d}"
    lon_str = f"E{lon_tile:03d}" if lon_tile >= 0 else f"W{abs(lon_tile):03d}"
    return f"Copernicus_DSM_COG_10_{lat_str}_00_{lon_str}_00_DEM"


def _baixar_tile(nome_tile):
    caminho_local = os.path.join(DEM_TILES_DIR, f"{nome_tile}.tif")
    if os.path.isfile(caminho_local):
        return caminho_local

    os.makedirs(DEM_TILES_DIR, exist_ok=True)
    url = f"{COPERNICUS_DEM_BASE_URL}/{nome_tile}/{nome_tile}.tif"
    print(f"    Baixando tile GLO-30: {nome_tile} ...")
    try:
        urllib.request.urlretrieve(url, caminho_local)
    except Exception as e:
        if os.path.isfile(caminho_local):
            os.remove(caminho_local)
        raise RuntimeError(
            f"Falha ao baixar tile de elevacao '{nome_tile}' ({url}): {e}. "
            f"Pode ser falta de internet, ou o ponto cai em area sem "
            f"cobertura Copernicus DEM (ex: oceano aberto)."
        )
    return caminho_local


def obter_raster_para_ponto(lat, lon, raio_m, margem=1.3):
    """
    Devolve o caminho para um raster de elevacao GLO-30 cobrindo o ponto
    (lat, lon) num raio de raio_m metros, baixando (e cacheando) os tiles
    publicos da AWS Copernicus DEM conforme necessario. Se mais de um tile
    for necessario, mescla-os num mosaico cacheado.
    """
    dlat = (raio_m * margem) / 111320
    dlon = (raio_m * margem) / (111320 * math.cos(math.radians(lat)))

    lat_min, lat_max = lat - dlat, lat + dlat
    lon_min, lon_max = lon - dlon, lon + dlon

    lat_tiles = range(math.floor(lat_min), math.floor(lat_max) + 1)
    lon_tiles = range(math.floor(lon_min), math.floor(lon_max) + 1)

    nomes_tiles = sorted({_nome_tile(lt, ln) for lt in lat_tiles for ln in lon_tiles})
    caminhos_tiles = [_baixar_tile(nome) for nome in nomes_tiles]

    if len(caminhos_tiles) == 1:
        return caminhos_tiles[0]

    chave_mosaico = "_".join(nomes_tiles)
    os.makedirs(DEM_MOSAICS_DIR, exist_ok=True)
    caminho_mosaico = os.path.join(DEM_MOSAICS_DIR, f"mosaico_{chave_mosaico}.tif")
    if os.path.isfile(caminho_mosaico):
        return caminho_mosaico

    print(f"    Mesclando {len(caminhos_tiles)} tiles GLO-30: {', '.join(nomes_tiles)}")
    srcs = [rasterio.open(p) for p in caminhos_tiles]
    mosaico, transform = merge(srcs)
    meta = srcs[0].meta.copy()
    meta.update({'height': mosaico.shape[1], 'width': mosaico.shape[2], 'transform': transform})
    with rasterio.open(caminho_mosaico, 'w', **meta) as dst:
        dst.write(mosaico)
    for s in srcs:
        s.close()

    return caminho_mosaico
