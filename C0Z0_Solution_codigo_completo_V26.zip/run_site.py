r"""
Orquestrador do pipeline completo (rugosidade + vento + perfil de terreno +
co / pressao de vento) para UM UNICO site, via linha de comando.

Uso:
  run_site "ID_Torre,PAIS,LAT,LON,ALTURA_TORRE,N_SECTORS,REGIAO[,COLINA_CADEIA[,OROGRAFIA]]"

Exemplo:
  run_site "52,Portugal,40.6405,-8.6538,35,8,Aveiro,No,Yes"

Campos opcionais (vem dos botoes da pagina):
  REGIAO        -- default "N/A"
  COLINA_CADEIA -- default "No"; "Yes"/"No"; so afeta o calculo de co em Franca
  OROGRAFIA     -- default "Yes"; "No" ignora a analise do perfil do terreno
                   (salta a etapa 3) e forca co = 1

Este programa NAO faz calculo: chama, pela ordem certa, os outros 4
executaveis (que vivem NA MESMA PASTA que este) e junta os resultados:

  [1/5] RugosidadeZ0            -> wk_by_main_sector.json, setores/, mapas z0, site_info.json
  [2/5] WindAnalysis           -> resultado_final.json, cdir.json, Wind_Map.jpg
   |    (junta z0/zmin/cdir/vb no resultado_site.json)
  [3/5] LandHeightDataCollector -> perfis de terreno + resultado_site.json
  [4/5] LandHeightDataCollector --xlsx  -> output_geral_reconhecimento_terreno_<ID>.xlsx
        co_wind_analysis        -> wind_config .txt, resultados_*.csv, qp_pressure.jpg, co_map.jpg
  [5/5] padroniza as dimensoes de todas as imagens

Em desenvolvimento (sem .exe) chama  "python <subpasta>/<script>.py"  em vez
do binario irmao -- o fluxo e identico.

RECALCULO INTELIGENTE: cada corrida bem sucedida guarda os inputs usados em
resultados/<ID>/_inputs_anteriores.json. Na corrida seguinte para o MESMO ID,
compara com os novos inputs e salta as etapas cujo resultado nao pode ter
mudado:
  - PAIS/LAT/LON/ALTURA/N_SECTORS/REGIAO iguais -> salta as etapas 1 e 2
    (as mais lentas) e reaproveita wk_by_main_sector.json/resultado_final.json.
  - OROGRAFIA continua "Yes" e o perfil de terreno ja existe -> salta tambem
    a etapa 3 e reaproveita o resultado_site.json anterior.
  - So mudou COLINA_CADEIA, ou so a OROGRAFIA passou para "No" -> corre so a
    etapa 4 (co_wind_analysis), em segundos.
Qualquer duvida (sem historico, ficheiros em falta, ID novo) refaz tudo --
isto so poupa trabalho quando tem a certeza de que nada relevante mudou.

Para forcar tudo de novo NUMA corrida, sem apagar nenhum ficheiro:
  C0Z0_FORCAR=1 ./run_site "ID,PAIS,LAT,LON,ALTURA,N_SECTORS,REGIAO,..."

NOTA: a junta assume N_SECTORS=8 (8 pontos cardeais N/NE/E/SE/S/SW/W/NW).
"""

import os
import sys
import json
import subprocess
import traceback

sys.stdout.reconfigure(line_buffering=True)

_FROZEN = getattr(sys, "frozen", False)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BIN_DIR = os.path.dirname(sys.executable) if _FROZEN else BASE_DIR

RESULTADOS_DIR = os.environ.get("C0Z0_OUTDIR") or os.path.join(BIN_DIR, "resultados")
RAIO_M = 1500

# Nome do executavel irmao -> (subpasta do .py em dev, nome do .py em dev)
_MODULOS = {
    "RugosidadeZ0":            ("Rugosidade",     "RugosidadeZ0.py"),
    "WindAnalysis":            ("Vento",          "WindAnalysis.py"),
    "LandHeightDataCollector": ("Altura terreno", "LandHeightDataCollector.py"),
    "co_wind_analysis":        ("Vento",          "co_wind_analysis.py"),
}


def _cmd(nome):
    """Prefixo de comando para chamar o modulo `nome`: o binario irmao (.exe)
    quando congelado, ou  python <subpasta>/<script>.py  em desenvolvimento."""
    if _FROZEN:
        exe = os.path.join(BIN_DIR, nome + (".exe" if os.name == "nt" else ""))
        return [exe]
    subpasta, script = _MODULOS[nome]
    return [sys.executable, os.path.join(BASE_DIR, subpasta, script)]


def _exec(nome, args, env_extra=None):
    """Corre o modulo irmao herdando stdout/stderr (o progresso aparece em
    tempo real). Levanta RuntimeError se o processo sair com codigo != 0."""
    env = os.environ.copy()
    env.setdefault("C0Z0_OUTDIR", RESULTADOS_DIR)
    if env_extra:
        env.update(env_extra)
    cmd = _cmd(nome) + [str(a) for a in args]
    print(f"    $ {nome} {' '.join(str(a) for a in args)}", flush=True)
    r = subprocess.run(cmd, cwd=BIN_DIR, env=env)
    if r.returncode != 0:
        raise RuntimeError(f"{nome} falhou (codigo {r.returncode})")
    return r


# ── Padronizacao das dimensoes das imagens ────────────────────────────────
#   perfis de terreno (perfil_*)  -> tela larga
#   todas as outras               -> tela "modelo" (= qp_pressure / co_map)
CANVAS_PADRAO = (3080, 2750)
CANVAS_PERFIL = (4000, 2000)


def _recanvas(caminho, alvo):
    from PIL import Image
    im = Image.open(caminho).convert("RGB")
    if im.size == alvo:
        return False
    esc = min(alvo[0] / im.width, alvo[1] / im.height)
    novo = (max(1, round(im.width * esc)), max(1, round(im.height * esc)))
    im = im.resize(novo, Image.LANCZOS)
    fundo = Image.new("RGB", alvo, "white")
    fundo.paste(im, ((alvo[0] - novo[0]) // 2, (alvo[1] - novo[1]) // 2))
    ext = os.path.splitext(caminho)[1].lower()
    if ext in (".jpg", ".jpeg"):
        fundo.save(caminho, quality=92)
    else:
        fundo.save(caminho)
    return True


def padronizar_imagens(pasta_torre):
    n = 0
    for root, _, files in os.walk(pasta_torre):
        for f in sorted(files):
            fl = f.lower()
            if not fl.endswith((".jpg", ".jpeg", ".png")):
                continue
            alvo = CANVAS_PERFIL if fl.startswith("perfil_") else CANVAS_PADRAO
            caminho = os.path.join(root, f)
            try:
                if _recanvas(caminho, alvo):
                    n += 1
            except Exception as e:
                print(f"    [AVISO] nao padronizou {f}: {e}")
    print(f"    {n} imagem(ns) re-enquadrada(s) "
          f"(perfis -> {CANVAS_PERFIL[0]}x{CANVAS_PERFIL[1]}, resto -> {CANVAS_PADRAO[0]}x{CANVAS_PADRAO[1]})")


# ── Junta rugosidade (etapa 1) + vento (etapa 2) no resultado_site ────────
# Setor 1..8 do wk_by_main_sector.json = N, NE, E, SE, S, SW, W, NW
_SETOR_TO_COMPASS = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
# Cada "Direcao" do perfil de terreno tem um lado esquerdo e um lado direito
_DIRECAO_ESQ_DIR = {0: ('S', 'N'), 45: ('SW', 'NE'), 90: ('W', 'E'), 135: ('SE', 'NW')}


def obter_z0_zmin_e_vb(pasta_resultado_torre):
    caminho = os.path.join(pasta_resultado_torre, "wk_by_main_sector.json")
    with open(caminho, 'r', encoding='utf-8') as f:
        wk_data = json.load(f)

    valores = {}
    for setor_name, setor_data in wk_data.items():
        if 'z0_setor_final' not in setor_data:
            continue
        setor_id = int(setor_name.split('_')[1])
        compass = _SETOR_TO_COMPASS[(setor_id - 1) % 8]
        valores[compass] = {
            'z0': setor_data['z0_setor_final'],
            'zmin': setor_data.get('d_setor_final', 0.0),
            'cdir': 1.0,
        }

    vb = None
    caminho_final = os.path.join(pasta_resultado_torre, "resultado_final.json")
    if os.path.isfile(caminho_final):
        with open(caminho_final, 'r', encoding='utf-8') as f:
            final_data = json.load(f)
        vb = final_data.get('vento', {}).get('vb')

    # cdir por rumo -- so existe quando o WindAnalysis o calcula (Franca).
    # Fonte: cdir.json -> "setores" na ordem N, NE, E, SE, S, SW, W, NW.
    # cdir (EN 1991-1-4) nunca e <= 0 -> ausente ou <= 0 -> 1.0.
    caminho_cdir = os.path.join(pasta_resultado_torre, "cdir.json")
    if os.path.isfile(caminho_cdir):
        with open(caminho_cdir, 'r', encoding='utf-8') as f:
            cdir_data = json.load(f)
        for i, setor in enumerate(cdir_data.get('setores', [])[:len(_SETOR_TO_COMPASS)]):
            compass = _SETOR_TO_COMPASS[i]
            c = setor.get('cdir')
            if compass in valores and c is not None and c > 0:
                valores[compass]['cdir'] = c

    return valores, vb


def preencher_z0_zmin_no_site(resultado_site, valores_por_compass):
    direcoes = resultado_site.setdefault('direcoes', {})
    for ang, (compass_esq, compass_dir) in _DIRECAO_ESQ_DIR.items():
        pontos = direcoes.setdefault(ang, {})
        d_esq = valores_por_compass.get(compass_esq, {})
        d_dir = valores_por_compass.get(compass_dir, {})
        pontos['z0_esq'] = d_esq.get('z0')
        pontos['z_min_esq'] = d_esq.get('zmin')
        pontos['cdir_esq'] = d_esq.get('cdir', 1.0)
        pontos['z0_dir'] = d_dir.get('z0')
        pontos['zmin_dir'] = d_dir.get('zmin')
        pontos['cdir_dir'] = d_dir.get('cdir', 1.0)


def _carregar_resultado_site(pasta_torre):
    """Le o resultado_site.json escrito pela etapa 3 e repoe as chaves int
    (0/45/90/135) de 'direcoes' (o JSON transforma-as em str)."""
    with open(os.path.join(pasta_torre, "resultado_site.json"), "r", encoding="utf-8") as f:
        rs = json.load(f)
    d = rs.get("direcoes") or {}
    rs["direcoes"] = {int(k): v for k, v in d.items()}
    return rs


# ── Recalculo inteligente: so refaz a etapa cujo input realmente mudou ────
_ARQUIVO_INPUTS = "_inputs_anteriores.json"
_CAMPOS_GEOMETRICOS = ("pais", "lat", "lon", "altura_torre", "n_sectors", "regiao")
# Ficheiros que tem de existir para reaproveitar as etapas 1+2 (rugosidade+vento)
_ARQUIVOS_ETAPA_1_2 = ("wk_by_main_sector.json", "site_info.json", "resultado_final.json")


def _ignora_orografia(valor):
    return str(valor or "Yes").strip().lower() in ("no", "nao", "não", "0", "false", "ignorar")


def _ler_inputs_anteriores(pasta_torre):
    caminho = os.path.join(pasta_torre, _ARQUIVO_INPUTS)
    if not os.path.isfile(caminho):
        return None
    try:
        with open(caminho, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _guardar_inputs_atuais(pasta_torre, inputs):
    with open(os.path.join(pasta_torre, _ARQUIVO_INPUTS), "w", encoding="utf-8") as f:
        json.dump(inputs, f, ensure_ascii=False, indent=2)


def _forcar_tudo():
    """C0Z0_FORCAR=1 (ou true/yes) -- ignora o historico e refaz tudo,
    sem precisar de apagar nenhum ficheiro. So para esta corrida; nao
    apaga nem desativa o recalculo inteligente das corridas seguintes."""
    return os.environ.get("C0Z0_FORCAR", "").strip().lower() in ("1", "true", "yes", "sim")


def _decidir_recalculo(pasta_torre, atuais):
    """Compara `atuais` com os inputs da ultima corrida bem sucedida para
    este ID e devolve (precisa_1_2, precisa_3). Por seguranca, qualquer
    duvida (sem historico, ficheiros em falta) devolve True -- isto so
    poupa trabalho quando ha a certeza de que nada relevante mudou."""
    if _forcar_tudo():
        return True, True

    anteriores = _ler_inputs_anteriores(pasta_torre)

    arquivos_ok = all(
        os.path.isfile(os.path.join(pasta_torre, f)) for f in _ARQUIVOS_ETAPA_1_2
    )
    precisa_1_2 = (
        anteriores is None
        or not arquivos_ok
        or any(anteriores.get(c) != atuais[c] for c in _CAMPOS_GEOMETRICOS)
    )

    if _ignora_orografia(atuais["orografia"]):
        precisa_3 = False  # co=1, perfil nem e usado
    elif precisa_1_2:
        precisa_3 = True   # a etapa 1 vai apagar a pasta -- o perfil antigo nao sobrevive
    else:
        tinha_perfil_valido = (
            anteriores is not None
            and not _ignora_orografia(anteriores.get("orografia"))
            and os.path.isfile(os.path.join(pasta_torre, "resultado_site.json"))
        )
        precisa_3 = not tinha_perfil_valido

    return precisa_1_2, precisa_3


def run(argumento):
    partes = argumento.split(',')
    if len(partes) < 6:
        print('Uso: run_site "ID_Torre,PAIS,LAT,LON,ALTURA_TORRE,N_SECTORS,REGIAO[,COLINA_CADEIA[,OROGRAFIA]]"')
        print('Exemplo: run_site "52,Portugal,40.6405,-8.6538,35,8,Aveiro,No,Yes"')
        sys.exit(1)

    id_torre = partes[0].strip()
    pais = partes[1].strip()
    lat = float(partes[2].strip())
    lon = float(partes[3].strip())
    altura_torre = float(partes[4].strip())
    n_sectors = int(partes[5].strip())
    regiao = partes[6].strip() if len(partes) > 6 and partes[6].strip() else "N/A"
    colina_cadeia = partes[7].strip() if len(partes) > 7 and partes[7].strip() else "No"
    orografia = partes[8].strip() if len(partes) > 8 and partes[8].strip() else "Yes"
    ignorar_oro = _ignora_orografia(orografia)

    atuais = {
        "pais": pais, "lat": lat, "lon": lon, "altura_torre": altura_torre,
        "n_sectors": n_sectors, "regiao": regiao,
        "colina_cadeia": colina_cadeia, "orografia": orografia,
    }

    print(f"ID_Torre={id_torre}  Pais={pais}  Lat={lat}  Lon={lon}  "
          f"Altura={altura_torre}  Setores={n_sectors}  Regiao={regiao}  "
          f"ColinaCadeia={colina_cadeia}  Orografia={orografia}")

    os.makedirs(RESULTADOS_DIR, exist_ok=True)
    pasta_torre = os.path.join(RESULTADOS_DIR, id_torre)
    os.makedirs(pasta_torre, exist_ok=True)

    if _forcar_tudo():
        print("C0Z0_FORCAR ativo -- a ignorar o historico, a refazer tudo.")
    precisa_1_2, precisa_3 = _decidir_recalculo(pasta_torre, atuais)

    if precisa_1_2:
        print("\n-> [1/5] Rugosidade (Z0/Zmin) ...")
        _exec("RugosidadeZ0",
              [f"{id_torre},{pais},{lat},{lon},{altura_torre},{n_sectors},{regiao}"])

        print("\n-> [2/5] Vento (vb, mapa, cdir/pressao) ...")
        _exec("WindAnalysis", [id_torre, "--outdir", RESULTADOS_DIR])
    else:
        print("\n-> [1/5] e [2/5] IGNORADOS -- Pais/Lat/Lon/Altura/Setores/Regiao "
              "iguais a ultima corrida; reaproveita a rugosidade e o vento ja calculados.")
    valores_por_compass, vb = obter_z0_zmin_e_vb(pasta_torre)

    if ignorar_oro:
        print("\n-> [3/5] Orografia IGNORADA (botao) -- salta a analise de perfil, co = 1.")
        resultado_site = {
            'codigo_site': id_torre, 'h_torre': altura_torre,
            'longitude': lon, 'latitude': lat, 'direcoes': {},
        }
    elif precisa_3:
        print("\n-> [3/5] Perfil de terreno ...")
        _exec("LandHeightDataCollector",
              [f"{id_torre},{lat},{lon},{altura_torre},{RAIO_M}", "--outdir", RESULTADOS_DIR])
        resultado_site = _carregar_resultado_site(pasta_torre)
    else:
        print("\n-> [3/5] IGNORADO -- reaproveita o perfil de terreno da corrida anterior.")
        resultado_site = _carregar_resultado_site(pasta_torre)

    resultado_site['codigo_site'] = id_torre
    resultado_site['vb'] = vb
    resultado_site['pais'] = pais
    resultado_site['colina_cadeia'] = colina_cadeia
    resultado_site['orografia'] = orografia
    preencher_z0_zmin_no_site(resultado_site, valores_por_compass)

    caminho_rs = os.path.join(pasta_torre, "resultado_site.json")
    with open(caminho_rs, "w", encoding="utf-8") as f:
        json.dump(resultado_site, f, ensure_ascii=False, indent=2)

    print("\n-> [4/5] Excel de output geral ...")
    caminho_xlsx = os.path.join(pasta_torre, f"output_geral_reconhecimento_terreno_{id_torre}.xlsx")
    _exec("LandHeightDataCollector", ["--xlsx", caminho_rs, caminho_xlsx])

    if pais in ("Portugal", "Portugal-RSA", "France", "Spain"):
        print("\n-> [4/5] Coeficiente orografico (co), pressao de vento e wind_config ...")
        _exec("co_wind_analysis", [id_torre, "--outdir", RESULTADOS_DIR])
    else:
        print(f"\n[AVISO] Calculo de co/pressao de vento nao implementado para o pais "
              f"'{pais}' -- etapa ignorada, wind_config nao gerado.")

    print("\n-> [5/5] Padronizar dimensoes das imagens...")
    padronizar_imagens(pasta_torre)

    _guardar_inputs_atuais(pasta_torre, atuais)

    print(f"\nCONCLUIDO: {id_torre}")
    print(f"Resultados em: {pasta_torre}")


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('Uso: run_site "ID_Torre,PAIS,LAT,LON,ALTURA_TORRE,N_SECTORS,REGIAO[,COLINA_CADEIA[,OROGRAFIA]]"')
        print('Exemplo: run_site "52,Portugal,40.6405,-8.6538,35,8,Aveiro,No,Yes"')
        sys.exit(1)
    try:
        run(sys.argv[1])
    except Exception as e:
        print(f"ERRO: {e}")
        traceback.print_exc()
        sys.exit(1)
